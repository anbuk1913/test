
require("dotenv").config();

const express = require("express");
const axios = require("axios");

const app = express();
const PORT = 3000;

app.use(express.static("public"));

app.get("/api/figma", async (req, res) => {
  try {
    const response = await axios.get(
      "https://api.figma.com/v1/files/TigRXVeilw06StJxyDaWu7",
      {
        headers: {
          "X-Figma-Token": process.env.FIGMA_TOKEN,
        },
        params: {
          depth: 2,
        },
      }
    );

    res.json(response.data);
  } catch (error) {
    console.error(
      "Figma API error:",
      error.response?.data || error.message
    );

    res.status(error.response?.status || 500).json({
      error: "Failed to fetch Figma design",
      details: error.response?.data || error.message,
    });
  }
});


app.get("/api/figma/preview", async (req, res) => {
  try {
    const response = await axios.get(
      "https://api.figma.com/v1/images/TigRXVeilw06StJxyDaWu7",
      {
        headers: {
          "X-Figma-Token": process.env.FIGMA_TOKEN,
        },
        params: {
          ids: "384:875",
          format: "png",
          scale: 2,
        },
      }
    );

    const imageUrl = response.data.images["384:875"];

    if (!imageUrl) {
      return res.status(404).json({
        error: "Frame image not found",
        response: response.data,
      });
    }

    res.json({ imageUrl });
  } catch (error) {
    res.status(error.response?.status || 500).json({
      error: error.response?.data || error.message,
    });
  }
});


app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
