# Shear Heaven Pet Spa - React Native (Expo)

This is the complete React Native (Expo + TypeScript + React Navigation) migration of the **Shear Heaven Pet Spa** Flutter codebase.

All original features, business workflows, UI design tokens, and backend API contracts have been preserved with 100% functional parity.

---

## 📱 Features Implemented

1. **Authentication & Session Management**
   - Customer Signup with full validation (`/api/auth/signup`)
   - OTP Verification with 60s countdown timer and resend (`/api/auth/send-otp`, `/api/auth/verify-otp`)
   - Customer & Groomer unified login (`/api/auth/login`)
   - Auto Token Refresh interceptor queue with mutex for seamless 401 handling (`/api/auth/refresh-token`, `/api/groomer-auth/refresh-token`)
   - Secure session storage & device registration

2. **Pet Management**
   - View all registered pets (`/api/pets`)
   - Add new pet with profile photo picker (`expo-image-picker`), weight classification, gender, vaccination status switch
   - Edit and delete pet profiles (`PUT /api/pets/:id`, `DELETE /api/pets/:id`)
   - Quick pet picker for appointment bookings

3. **Services & Packages**
   - Real-time catalog from `/api/service-packages` (Breeds, Packages, Add-ons, Walk-in)
   - Dynamic search and category filtering
   - Detailed treatment overviews with duration, pricing, and inclusions
   - High-resolution image resolution with fallback assets

4. **Multi-Step Booking Flow**
   - **Step 1 (Services & Add-ons)**: Select pet, choose primary service or luxury package, attach multiple add-on treatments with real-time price & duration estimation.
   - **Step 2 (Date & Time Slots)**: 14-day rolling booking calendar with store holiday/closure detection, groomer preference selection (Any Groomer or specific staff member), live slot availability check (`/api/groomer-availability`).
   - **Step 3 (Review & Notes)**: Summary card, promo code validation (`/api/offers/validate-promo`), care notes / behavioral instructions input, and appointment submission (`/api/bookings`).
   - **Step 4 (Confirmation)**: Appointment code, address info, calendar export trigger.

5. **Appointment Management (My Bookings)**
   - Tabs: **Upcoming**, **Past**, **Cancelled**
   - Live appointments from `/api/bookings/upcoming`, `/api/bookings/past`, `/api/bookings/cancelled`
   - Cancel appointment confirmation with instant refresh (`POST /api/bookings/:id/cancel`)
   - Detailed booking receipt and salon contact info

6. **Live Customer-Staff Chat**
   - Socket.IO real-time duplex chat connection
   - Conversation history retrieval (`/api/chat/history`)
   - One-tap canned responses
   - Online salon status indicator

7. **Salon Groomer Portal**
   - Dedicated Groomer login (`/api/groomer-auth/login`)
   - First-time setup / temporary password update (`/api/groomer-auth/setup-account`)
   - Groomer dashboard with queue statistics
   - Action controls: **Approve**, **Decline**, **Start Service**, **Mark Completed**

8. **Settings & Extras**
   - User profile management with avatar upload (`/api/auth/profile`)
   - In-app notification center with mark-all-read and deletion (`/api/notifications`)
   - Exclusive offers with promo code copy
   - Pet styling gallery with image preview modal
   - CMS Pages: About Us, Help & FAQ, Privacy Policy, Terms & Conditions

---

## 🛠 Tech Stack

- **Framework**: Expo SDK 52 / React Native 0.76+
- **Language**: TypeScript (strict mode)
- **Navigation**: React Navigation 7 (Native Stack & Bottom Tabs)
- **Networking**: Axios with request/response interceptors & token refresh mutex
- **Real-Time**: Socket.IO Client
- **Icons**: `@expo/vector-icons` (Ionicons)
- **Image Picker**: `expo-image-picker`
- **Storage**: `@react-native-async-storage/async-storage`

---

## 🚀 Getting Started

### 1. Install Dependencies
```bash
cd shear_heaven_react_native
npm install
```

### 2. Start the Development Server
```bash
npm start
```

### 3. Run on iOS Simulator or Android Emulator
- Press `i` to open in iOS Simulator
- Press `a` to open in Android Emulator
- Or scan the QR code with the **Expo Go** app on your physical device.

---

## 🌐 API Domain & Endpoints

- **Backend Base URL**: `https://devapi.shearheavenpetspa.com`
- **Socket URL**: `https://devapi.shearheavenpetspa.com`
- **Default Headers**:
  - `ClientId`: `SHEAR-001`
  - `RegionId`: `DWG-001`
  - `StoreId`: `SHEAR-001`
