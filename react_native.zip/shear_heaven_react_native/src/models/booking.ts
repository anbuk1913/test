import { Pet } from './pet';
import { ServiceItem } from './service';

export interface BookingSlot {
  time: string;
  startTime: string;
  endTime: string;
  available: boolean;
  groomerId?: number;
}

export interface BookingGroomer {
  id: number;
  name: string;
  experience?: string;
  avatar?: string;
  rating?: number;
}

export interface CreateBookingPayload {
  ClientId: string;
  RegionId: string;
  StoreId: string;
  petId: number | string;
  serviceId?: number;
  packageId?: number;
  addOnIds?: number[];
  groomerId?: number;
  bookingDate: string;
  startTime: string;
  endTime: string;
  notes?: string;
}

export interface Booking {
  id: number;
  bookingId?: number;
  bookingCode?: string;
  status: 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled' | 'rejected';
  bookingDate: string;
  startTime: string;
  endTime: string;
  totalPrice: number;
  totalDurationMinutes: number;
  pet?: Pet;
  petName?: string;
  petBreed?: string;
  service?: ServiceItem;
  serviceName?: string;
  packageName?: string;
  groomer?: BookingGroomer;
  groomerName?: string;
  addOns?: ServiceItem[];
  instructions?: string;
  cancellationReason?: string;
  createdAt?: string;
}
