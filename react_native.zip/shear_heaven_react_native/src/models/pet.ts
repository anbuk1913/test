export interface Pet {
  id: number | string;
  _id?: string;
  petName: string;
  name?: string;
  breed?: string;
  weight?: string;
  age?: string;
  gender?: 'male' | 'female' | string;
  dateOfBirth?: string;
  birthDate?: string;
  notesAllergies?: string;
  notes?: string;
  behaviorNotes?: string;
  allVaccinatedCurrent?: boolean | string;
  lastVaccinatedDate?: string;
  profilePictureUrl?: string;
  profilePicture?: string;
  photo_url?: string;
  image?: string;
}

export interface CreatePetDTO {
  petName: string;
  breed?: string;
  weight?: string;
  age?: string;
  gender?: 'male' | 'female' | string;
  dateOfBirth?: string;
  notesAllergies?: string;
  behaviorNotes?: string;
  allVaccinatedCurrent?: boolean | string;
  lastVaccinatedDate?: string;
  photoUri?: string;
}
