export interface User {
  id?: number | string;
  _id?: string;
  name: string;
  email: string;
  mobile?: string;
  phone?: string;
  profilePictureUrl?: string;
  profilePicture?: string;
  gender?: string;
  role?: string;
  userType?: 'customer' | 'groomer';
}

export interface GroomerUser {
  id?: number | string;
  groomerId?: number;
  name: string;
  email: string;
  mobile?: string;
  phone?: string;
  profilePictureUrl?: string;
  specialization?: string;
  experience?: string;
  status?: string;
  workingDays?: string[];
  mustChangePassword?: boolean;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

export interface AuthResponse {
  success: boolean;
  message?: string;
  data?: {
    accessToken?: string;
    refreshToken?: string;
    user?: User;
    groomer?: GroomerUser;
    userType?: 'customer' | 'groomer';
    mustChangePassword?: boolean;
    tempLoginId?: string;
    tempPassword?: string;
  };
  errors?: string[];
}
