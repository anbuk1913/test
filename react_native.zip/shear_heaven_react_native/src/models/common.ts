export interface ChatMessage {
  id: string | number;
  senderId?: string | number;
  receiverId?: string | number;
  message: string;
  isCustomer: boolean;
  createdAt: string;
  timestamp?: string;
  imageUrl?: string;
  isRead?: boolean;
}

export interface AppNotification {
  id: number | string;
  title: string;
  message: string;
  type?: string;
  isRead: boolean;
  createdAt: string;
  data?: Record<string, any>;
}

export interface OfferModel {
  id: number | string;
  title: string;
  description: string;
  code: string;
  discountPercentage?: number;
  discountAmount?: number;
  validUntil?: string;
  bannerUrl?: string;
  minimumAmount?: number;
}

export interface StoreHours {
  dayOfWeek: string;
  openTime: string;
  closeTime: string;
  isClosed: boolean;
}

export interface Holiday {
  id: number;
  date: string;
  name: string;
  description?: string;
}

export interface GroomerStaff {
  id: number;
  name: string;
  role?: string;
  specialization?: string;
  avatarUrl?: string;
  isAvailable?: boolean;
}
