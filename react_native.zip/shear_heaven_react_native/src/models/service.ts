export interface ServiceItem {
  id: number;
  isPackage: boolean;
  isAddOn: boolean;
  name: string;
  description: string;
  price: number;
  priceDisplay: string;
  durationMinutes: number;
  imageUrl?: string;
  includes?: string[];
  code?: string;
  category?: string;
}

export interface BookingServicesResult {
  breeds: ServiceItem[];
  packages: ServiceItem[];
  addOns: ServiceItem[];
  walkIn: ServiceItem[];
}
