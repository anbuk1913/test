export const AppConfig = {
  APP_NAME: 'Shear Heaven Pet Spa',
  APP_TITLE: 'Shear Heaven Pet Spa',
  APP_TAGLINE: "Arlington's #1 Pet Grooming Booking APP",

  // Official API Base URL (retaining exact existing domain & endpoints)
  BASE_URL: 'https://devapi.shearheavenpetspa.com',
  SOCKET_URL: 'https://devapi.shearheavenpetspa.com',

  // Store identifiers
  DEFAULT_CLIENT_ID: 'SHEAR-001',
  DEFAULT_REGION_ID: 'DWG-001',
  DEFAULT_STORE_ID: 'SHEAR-001',

  // Storage keys
  STORAGE_KEYS: {
    ACCESS_TOKEN: 'shear_heaven_access_token',
    REFRESH_TOKEN: 'shear_heaven_refresh_token',
    CUSTOMER_USER: 'shear_heaven_customer_user',
    GROOMER_USER: 'shear_heaven_groomer_user',
    IS_GROOMER: 'shear_heaven_is_groomer',
    DEVICE_ID: 'shear_heaven_device_id',
    PENDING_EMAIL: 'shear_heaven_pending_email',
    TEMP_GROOMER_LOGIN: 'shear_heaven_temp_groomer_login',
    CLIENT_ID: 'shear_heaven_client_id',
    REGION_ID: 'shear_heaven_region_id',
    STORE_ID: 'shear_heaven_store_id',
    ONBOARDING_SEEN: 'shear_heaven_onboarding_seen',
  },
} as const;
