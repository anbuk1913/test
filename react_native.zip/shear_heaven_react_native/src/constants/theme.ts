export const Colors = {
  primary: '#0F766E', // Flutter PRIMARY_COLOR
  secondary: '#14B8A6', // Flutter SECONDARY_COLOR
  accent: '#FFB800', // Flutter ACCENT_COLOR
  background: '#FFFFFF',
  surface: '#F4F6F8',
  surfaceLight: '#F9FAFB',
  surfaceCard: '#FFFFFF',
  textPrimary: '#1F2933',
  textSecondary: '#7B8794',
  textMuted: '#9CA3AF',
  border: '#E5E7EB',
  borderLight: '#F3F4F6',
  divider: '#EEF2F6',

  // Status Colors
  success: '#16A34A',
  successLight: '#DCFCE7',
  warning: '#D97706',
  warningLight: '#FEF3C7',
  danger: '#DC2626',
  dangerLight: '#FEE2E2',
  info: '#2563EB',
  infoLight: '#DBEAFE',

  // UI state
  disabled: '#CBD5E1',
  placeholder: '#9CA3AF',
  white: '#FFFFFF',
  black: '#000000',
  transparent: 'transparent',
};

export const Spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  xxxl: 32,
};

export const BorderRadius = {
  sm: 6,
  md: 10,
  lg: 14,
  xl: 18,
  pill: 999,
};

export const Typography = {
  header1: {
    fontSize: 24,
    fontWeight: '700' as const,
    color: Colors.textPrimary,
  },
  header2: {
    fontSize: 20,
    fontWeight: '700' as const,
    color: Colors.textPrimary,
  },
  title: {
    fontSize: 17,
    fontWeight: '600' as const,
    color: Colors.textPrimary,
  },
  subtitle: {
    fontSize: 15,
    fontWeight: '500' as const,
    color: Colors.textSecondary,
  },
  body: {
    fontSize: 14,
    fontWeight: '400' as const,
    color: Colors.textPrimary,
  },
  caption: {
    fontSize: 12,
    fontWeight: '400' as const,
    color: Colors.textSecondary,
  },
  badge: {
    fontSize: 11,
    fontWeight: '600' as const,
  },
};
