import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Header } from '../../components/Header';
import { contentRepository } from '../../repositories/commonRepositories';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

export const AboutUsScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const [content, setContent] = useState('');
  const [contact, setContact] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([contentRepository.getAboutUs(), contentRepository.getStoreContactInfo()]).then(
      ([about, info]) => {
        setContent(about);
        setContact(info);
        setLoading(false);
      }
    );
  }, []);

  return (
    <View style={styles.container}>
      <Header title="About Us" onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={styles.content}>
        {loading ? (
          <ActivityIndicator color={Colors.primary} size="large" />
        ) : (
          <>
            <View style={styles.card}>
              <Text style={[Typography.header2, styles.title]}>Shear Heaven Pet Spa</Text>
              <Text style={styles.body}>{content}</Text>
            </View>

            {contact && (
              <View style={styles.card}>
                <Text style={[Typography.title, styles.title]}>Location & Contact</Text>
                <Text style={styles.contactItem}>📍 {contact.address}</Text>
                <Text style={styles.contactItem}>📞 {contact.phone}</Text>
                <Text style={styles.contactItem}>✉️ {contact.email}</Text>
                <Text style={styles.contactItem}>🕒 {contact.hours}</Text>
              </View>
            )}
          </>
        )}
      </ScrollView>
    </View>
  );
};

export const HelpSupportScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const [faqs, setFaqs] = useState<Array<{ q: string; a: string }>>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    contentRepository.getHelpSupport().then((res) => {
      setFaqs(res.faq || []);
      setLoading(false);
    });
  }, []);

  return (
    <View style={styles.container}>
      <Header title="Help & Support" onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={styles.content}>
        <Text style={[Typography.header2, { marginBottom: Spacing.md }]}>Frequently Asked Questions</Text>
        {loading ? (
          <ActivityIndicator color={Colors.primary} size="large" />
        ) : (
          faqs.map((faq, idx) => (
            <View key={idx} style={styles.card}>
              <Text style={[Typography.title, styles.faqQ]}>{faq.q}</Text>
              <Text style={styles.faqA}>{faq.a}</Text>
            </View>
          ))
        )}
      </ScrollView>
    </View>
  );
};

export const PrivacyPolicyScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const [text, setText] = useState('');

  useEffect(() => {
    contentRepository.getPrivacyPolicy().then(setText);
  }, []);

  return (
    <View style={styles.container}>
      <Header title="Privacy Policy" onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.card}>
          <Text style={[Typography.header2, styles.title]}>Privacy Policy</Text>
          <Text style={styles.body}>{text}</Text>
        </View>
      </ScrollView>
    </View>
  );
};

export const TermsConditionScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const [text, setText] = useState('');

  useEffect(() => {
    contentRepository.getTermsConditions().then(setText);
  }, []);

  return (
    <View style={styles.container}>
      <Header title="Terms & Conditions" onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.card}>
          <Text style={[Typography.header2, styles.title]}>Terms of Service</Text>
          <Text style={styles.body}>{text}</Text>
        </View>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  content: {
    padding: Spacing.lg,
    gap: Spacing.md,
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  title: {
    marginBottom: Spacing.sm,
  },
  body: {
    fontSize: 14,
    color: Colors.textSecondary,
    lineHeight: 22,
  },
  contactItem: {
    fontSize: 14,
    color: Colors.textPrimary,
    marginVertical: 4,
  },
  faqQ: {
    fontSize: 15,
    marginBottom: 6,
    color: Colors.primary,
  },
  faqA: {
    fontSize: 13,
    color: Colors.textSecondary,
    lineHeight: 20,
  },
});
