import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { Header } from '../../components/Header';
import { useAuth } from '../../context/AuthContext';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

export const SettingsScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const { user, logout } = useAuth();

  const handleLogout = () => {
    Alert.alert('Log Out', 'Are you sure you want to log out from Shear Heaven Pet Spa?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Log Out',
        style: 'destructive',
        onPress: async () => {
          await logout();
          navigation.reset({ index: 0, routes: [{ name: 'Welcome' }] });
        },
      },
    ]);
  };

  const menuSections = [
    {
      title: 'Pet & Profile',
      items: [
        { icon: 'person-outline', label: 'My Profile', screen: 'Profile' },
        { icon: 'paw-outline', label: 'My Pets', screen: 'MyPets' },
        { icon: 'notifications-outline', label: 'Notifications', screen: 'Notifications' },
      ],
    },
    {
      title: 'Spa & Perks',
      items: [
        { icon: 'pricetag-outline', label: 'Exclusive Offers', screen: 'Offers' },
        { icon: 'images-outline', label: 'Pet Photo Gallery', screen: 'Gallery' },
      ],
    },
    {
      title: 'Support & Legal',
      items: [
        { icon: 'information-circle-outline', label: 'About Shear Heaven', screen: 'AboutUs' },
        { icon: 'help-circle-outline', label: 'Help & FAQ Support', screen: 'HelpSupport' },
        { icon: 'shield-checkmark-outline', label: 'Privacy Policy', screen: 'PrivacyPolicy' },
        { icon: 'document-text-outline', label: 'Terms & Conditions', screen: 'TermsCondition' },
      ],
    },
  ];

  return (
    <View style={styles.container}>
      <Header title="Settings & More" />

      <ScrollView contentContainerStyle={styles.content}>
        {/* User Card */}
        <TouchableOpacity
          style={styles.profileCard}
          onPress={() => navigation.navigate('Profile')}
          activeOpacity={0.8}
        >
          {user?.profilePictureUrl ? (
            <Image source={{ uri: user.profilePictureUrl }} style={styles.avatar} />
          ) : (
            <View style={styles.avatarPlaceholder}>
              <Ionicons name="person" size={28} color={Colors.primary} />
            </View>
          )}
          <View style={styles.profileInfo}>
            <Text style={[Typography.title, styles.profileName]}>
              {user?.name || 'Valued Customer'}
            </Text>
            <Text style={styles.profileEmail}>{user?.email || 'user@example.com'}</Text>
          </View>
          <Ionicons name="chevron-forward" size={20} color={Colors.textSecondary} />
        </TouchableOpacity>

        {/* Menu Sections */}
        {menuSections.map((sec, i) => (
          <View key={i} style={styles.section}>
            <Text style={styles.sectionTitle}>{sec.title}</Text>
            <View style={styles.card}>
              {sec.items.map((item, j) => (
                <TouchableOpacity
                  key={j}
                  onPress={() => navigation.navigate(item.screen)}
                  style={[
                    styles.menuRow,
                    j < sec.items.length - 1 ? styles.rowBorder : undefined,
                  ]}
                  activeOpacity={0.7}
                >
                  <View style={styles.iconCircle}>
                    <Ionicons name={item.icon as any} size={20} color={Colors.primary} />
                  </View>
                  <Text style={styles.menuLabel}>{item.label}</Text>
                  <Ionicons name="chevron-forward" size={18} color={Colors.border} />
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ))}

        {/* Switch to Groomer Mode */}
        <TouchableOpacity
          onPress={() => navigation.navigate('GroomerLogin')}
          style={styles.groomerPortalCard}
          activeOpacity={0.8}
        >
          <Ionicons name="cut" size={22} color={Colors.primary} />
          <View style={{ flex: 1, marginLeft: Spacing.md }}>
            <Text style={styles.groomerPortalTitle}>Groomer Staff Portal</Text>
            <Text style={styles.groomerPortalSubtitle}>
              Log in to view working schedule and appointment queue
            </Text>
          </View>
          <Ionicons name="chevron-forward" size={20} color={Colors.primary} />
        </TouchableOpacity>

        {/* Log Out */}
        <TouchableOpacity onPress={handleLogout} style={styles.logoutBtn}>
          <Ionicons name="log-out-outline" size={20} color={Colors.danger} />
          <Text style={styles.logoutText}>Log Out</Text>
        </TouchableOpacity>

        <Text style={styles.versionText}>Shear Heaven Pet Spa v7.0.0 (React Native)</Text>
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  content: {
    padding: Spacing.lg,
    paddingBottom: Spacing.xxxl,
    gap: Spacing.md,
  },
  profileCard: {
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  avatar: {
    width: 60,
    height: 60,
    borderRadius: 30,
  },
  avatarPlaceholder: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#CCFBF1',
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileInfo: {
    flex: 1,
    marginLeft: Spacing.md,
  },
  profileName: {
    fontSize: 17,
  },
  profileEmail: {
    fontSize: 13,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  section: {
    marginTop: 4,
  },
  sectionTitle: {
    fontSize: 12,
    fontWeight: '700',
    color: Colors.textSecondary,
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    marginBottom: Spacing.xs,
    marginLeft: 4,
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    overflow: 'hidden',
  },
  menuRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: Spacing.md,
  },
  rowBorder: {
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
  },
  iconCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#F0FDFA',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.md,
  },
  menuLabel: {
    fontSize: 15,
    fontWeight: '500',
    color: Colors.textPrimary,
    flex: 1,
  },
  groomerPortalCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F0FDFA',
    padding: Spacing.lg,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    borderColor: '#99F6E4',
    marginTop: Spacing.sm,
  },
  groomerPortalTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: Colors.primary,
  },
  groomerPortalSubtitle: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: Spacing.md,
    marginTop: Spacing.sm,
  },
  logoutText: {
    color: Colors.danger,
    fontSize: 15,
    fontWeight: '700',
  },
  versionText: {
    textAlign: 'center',
    fontSize: 12,
    color: Colors.textSecondary,
    marginTop: Spacing.xs,
  },
});
