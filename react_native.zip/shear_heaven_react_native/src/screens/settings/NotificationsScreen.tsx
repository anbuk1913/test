import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { Header } from '../../components/Header';
import { EmptyState } from '../../components/ServiceCard';
import { notificationRepository } from '../../repositories/commonRepositories';
import { AppNotification } from '../../models/common';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

export const NotificationsScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadNotifications();
  }, []);

  const loadNotifications = async () => {
    try {
      const data = await notificationRepository.getNotifications();
      if (data.length > 0) {
        setNotifications(data);
      } else {
        // Helpful fallback
        setNotifications([
          {
            id: 1,
            title: 'Welcome to Shear Heaven Pet Spa!',
            message: 'Your account is ready. Explore our grooming packages and book your pet’s appointment today.',
            isRead: false,
            createdAt: new Date().toISOString(),
          },
          {
            id: 2,
            title: '20% Off Promo Available',
            message: 'Use code WELCOME20 on your first appointment booking to save 20%.',
            isRead: true,
            createdAt: new Date(Date.now() - 86400000).toISOString(),
          },
        ]);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAllRead = async () => {
    await notificationRepository.markAllAsRead();
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  const handleDelete = async (id: string | number) => {
    await notificationRepository.deleteNotification(id);
    setNotifications((prev) => prev.filter((n) => n.id !== id));
  };

  return (
    <View style={styles.container}>
      <Header
        title="Notifications"
        onBack={() => navigation.goBack()}
        rightAction={
          notifications.length > 0 ? (
            <TouchableOpacity onPress={handleMarkAllRead}>
              <Text style={styles.markAllText}>Mark Read</Text>
            </TouchableOpacity>
          ) : undefined
        }
      />

      {loading ? (
        <ActivityIndicator color={Colors.primary} size="large" style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={notifications}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={styles.list}
          ListEmptyComponent={
            <EmptyState
              icon="notifications-off-outline"
              title="No Notifications"
              message="You are all caught up! Updates regarding appointments will appear here."
            />
          }
          renderItem={({ item }) => (
            <View style={[styles.itemCard, !item.isRead ? styles.unreadCard : undefined]}>
              <View style={styles.iconCircle}>
                <Ionicons
                  name={item.isRead ? 'notifications-outline' : 'notifications'}
                  size={20}
                  color={Colors.primary}
                />
              </View>

              <View style={styles.content}>
                <Text style={[Typography.title, styles.title]}>{item.title}</Text>
                <Text style={styles.message}>{item.message}</Text>
                <Text style={styles.time}>
                  {new Date(item.createdAt).toLocaleDateString()} •{' '}
                  {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </Text>
              </View>

              <TouchableOpacity onPress={() => handleDelete(item.id)} style={styles.deleteBtn}>
                <Ionicons name="close" size={18} color={Colors.textSecondary} />
              </TouchableOpacity>
            </View>
          )}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  list: {
    padding: Spacing.lg,
    gap: Spacing.sm,
  },
  markAllText: {
    fontSize: 13,
    color: Colors.primary,
    fontWeight: '600',
  },
  itemCard: {
    flexDirection: 'row',
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'flex-start',
  },
  unreadCard: {
    backgroundColor: '#F0FDFA',
    borderColor: '#99F6E4',
  },
  iconCircle: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#CCFBF1',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: Spacing.md,
  },
  content: {
    flex: 1,
  },
  title: {
    fontSize: 15,
    marginBottom: 4,
  },
  message: {
    fontSize: 13,
    color: Colors.textSecondary,
    lineHeight: 18,
    marginBottom: 6,
  },
  time: {
    fontSize: 11,
    color: Colors.textSecondary,
  },
  deleteBtn: {
    padding: Spacing.xs,
  },
});
