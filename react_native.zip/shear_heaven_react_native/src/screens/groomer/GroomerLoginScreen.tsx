import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, KeyboardAvoidingView, Platform } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { CustomInput } from '../../components/CustomInput';
import { PrimaryButton } from '../../components/PrimaryButton';
import { groomerRepository } from '../../repositories/groomerRepository';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

export const GroomerLoginScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const [loginId, setLoginId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async () => {
    if (!loginId.trim() || !password) {
      setError('Please provide your Groomer ID / Email and password.');
      return;
    }

    setError('');
    setLoading(true);

    try {
      const res = await groomerRepository.login(loginId, password);
      if (res.mustChangePassword) {
        navigation.reset({
          index: 0,
          routes: [
            {
              name: 'GroomerRegister',
              params: { tempLoginId: res.tempLoginId, tempPassword: res.tempPassword },
            },
          ],
        });
      } else {
        navigation.reset({ index: 0, routes: [{ name: 'GroomerHome' }] });
      }
    } catch (err: any) {
      setError(err?.message || 'Groomer authentication failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={{ flex: 1, backgroundColor: Colors.white }}
    >
      <ScrollView contentContainerStyle={styles.container}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>

        <View style={styles.iconCircle}>
          <Ionicons name="cut" size={40} color={Colors.primary} />
        </View>

        <Text style={[Typography.header1, styles.title]}>Groomer Portal</Text>
        <Text style={styles.subtitle}>Staff access to appointment schedule & clients</Text>

        {error ? (
          <View style={styles.errorBox}>
            <Ionicons name="alert-circle" size={18} color={Colors.danger} />
            <Text style={styles.errorText}>{error}</Text>
          </View>
        ) : null}

        <View style={styles.form}>
          <CustomInput
            label="Groomer ID or Email"
            placeholder="groomer@shearheaven.com"
            value={loginId}
            onChangeText={(t) => {
              setLoginId(t);
              setError('');
            }}
            autoCapitalize="none"
            leftIcon={<Ionicons name="person-outline" size={20} color={Colors.textSecondary} />}
          />

          <CustomInput
            label="Password"
            placeholder="Enter password"
            value={password}
            onChangeText={(t) => {
              setPassword(t);
              setError('');
            }}
            secureTextEntry={!showPassword}
            leftIcon={<Ionicons name="lock-closed-outline" size={20} color={Colors.textSecondary} />}
            rightIcon={
              <Ionicons
                name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                size={20}
                color={Colors.textSecondary}
              />
            }
            onRightIconPress={() => setShowPassword(!showPassword)}
          />

          <PrimaryButton
            title="Log In to Portal"
            onPress={handleLogin}
            loading={loading}
            style={styles.loginBtn}
          />

          <TouchableOpacity
            onPress={() => navigation.navigate('Login')}
            style={styles.customerSwitch}
          >
            <Text style={styles.customerSwitchText}>Are you a customer? Customer Login</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: Spacing.xl,
    flexGrow: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.white,
  },
  backBtn: {
    alignSelf: 'flex-start',
    marginBottom: Spacing.md,
  },
  iconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#CCFBF1',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.md,
  },
  title: {
    fontSize: 26,
    marginBottom: Spacing.xs,
  },
  subtitle: {
    fontSize: 14,
    color: Colors.textSecondary,
    marginBottom: Spacing.xl,
    textAlign: 'center',
  },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.dangerLight,
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.md,
    gap: 8,
    width: '100%',
  },
  errorText: {
    color: Colors.danger,
    fontSize: 13,
    flex: 1,
  },
  form: {
    width: '100%',
  },
  loginBtn: {
    marginTop: Spacing.md,
  },
  customerSwitch: {
    paddingVertical: Spacing.xl,
    alignItems: 'center',
  },
  customerSwitchText: {
    fontSize: 13,
    color: Colors.primary,
    fontWeight: '600',
  },
});
