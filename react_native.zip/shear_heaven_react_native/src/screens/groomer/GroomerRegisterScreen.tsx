import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Header } from '../../components/Header';
import { CustomInput } from '../../components/CustomInput';
import { PrimaryButton } from '../../components/PrimaryButton';
import { groomerRepository } from '../../repositories/groomerRepository';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

export const GroomerRegisterScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();

  const [name, setName] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSetup = async () => {
    if (!newPassword || newPassword.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }

    setError('');
    setLoading(true);

    try {
      await groomerRepository.setupAccount({
        tempLoginId: route.params?.tempLoginId,
        tempPassword: route.params?.tempPassword,
        newPassword,
        name,
      });

      Alert.alert('Account Initialized', 'Your groomer password has been updated.');
      navigation.reset({ index: 0, routes: [{ name: 'GroomerHome' }] });
    } catch (err: any) {
      setError(err?.message || 'Failed to update account.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Header title="Setup Groomer Account" onBack={() => navigation.goBack()} />

      <ScrollView contentContainerStyle={styles.content}>
        <Text style={[Typography.header2, styles.title]}>Create New Password</Text>
        <Text style={styles.subtitle}>
          Please update your temporary login credentials to secure your groomer account.
        </Text>

        {error ? (
          <View style={styles.errorBox}>
            <Text style={styles.errorText}>{error}</Text>
          </View>
        ) : null}

        <CustomInput
          label="Your Full Name (Optional)"
          placeholder="e.g. Alex Rivera"
          value={name}
          onChangeText={setName}
        />

        <CustomInput
          label="New Password *"
          placeholder="At least 6 characters"
          value={newPassword}
          onChangeText={(t) => {
            setNewPassword(t);
            setError('');
          }}
          secureTextEntry
        />

        <CustomInput
          label="Confirm New Password *"
          placeholder="Re-enter password"
          value={confirmPassword}
          onChangeText={(t) => {
            setConfirmPassword(t);
            setError('');
          }}
          secureTextEntry
        />

        <PrimaryButton
          title="Save & Proceed to Dashboard"
          onPress={handleSetup}
          loading={loading}
          style={{ marginTop: Spacing.xl }}
        />
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  content: {
    padding: Spacing.xl,
  },
  title: {
    fontSize: 22,
    marginBottom: 6,
  },
  subtitle: {
    fontSize: 14,
    color: Colors.textSecondary,
    marginBottom: Spacing.xl,
    lineHeight: 20,
  },
  errorBox: {
    backgroundColor: Colors.dangerLight,
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.md,
  },
  errorText: {
    color: Colors.danger,
    fontSize: 13,
  },
});
