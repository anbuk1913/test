import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../context/AuthContext';
import { groomerRepository } from '../../repositories/groomerRepository';
import { Booking } from '../../models/booking';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

type GroomerTab = 'upcoming' | 'pending' | 'past';

export const GroomerHomeScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const { groomer, logout } = useAuth();

  const [activeTab, setActiveTab] = useState<GroomerTab>('upcoming');
  const [upcoming, setUpcoming] = useState<Booking[]>([]);
  const [pending, setPending] = useState<Booking[]>([]);
  const [past, setPast] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [up, pend, pst] = await Promise.all([
        groomerRepository.getUpcomingBookings(),
        groomerRepository.getPendingBookings(),
        groomerRepository.getPastBookings(),
      ]);
      setUpcoming(up);
      setPending(pend);
      setPast(pst);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadData();
  };

  const handleApprove = async (id: number | string) => {
    try {
      await groomerRepository.approveBooking(id);
      Alert.alert('Approved', 'Appointment has been confirmed.');
      loadData();
    } catch (err: any) {
      Alert.alert('Error', err?.message || 'Failed to approve booking.');
    }
  };

  const handleReject = async (id: number | string) => {
    Alert.alert('Reject Booking', 'Are you sure you want to decline this booking request?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Reject',
        style: 'destructive',
        onPress: async () => {
          try {
            await groomerRepository.rejectBooking(id);
            Alert.alert('Declined', 'Booking has been rejected.');
            loadData();
          } catch (err: any) {
            Alert.alert('Error', err?.message || 'Failed to reject booking.');
          }
        },
      },
    ]);
  };

  const handleStart = async (id: number | string) => {
    try {
      await groomerRepository.startBooking(id);
      Alert.alert('Started', 'Appointment marked as In-Progress.');
      loadData();
    } catch (err: any) {
      Alert.alert('Error', err?.message || 'Failed to update status.');
    }
  };

  const handleComplete = async (id: number | string) => {
    try {
      await groomerRepository.completeBooking(id);
      Alert.alert('Completed', 'Appointment marked as Complete!');
      loadData();
    } catch (err: any) {
      Alert.alert('Error', err?.message || 'Failed to update status.');
    }
  };

  const handleLogout = () => {
    Alert.alert('Log Out', 'Log out of Groomer Portal?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Log Out',
        style: 'destructive',
        onPress: async () => {
          await logout();
          navigation.reset({ index: 0, routes: [{ name: 'Welcome' }] });
        },
      },
    ]);
  };

  const getList = (): Booking[] => {
    if (activeTab === 'upcoming') return upcoming;
    if (activeTab === 'pending') return pending;
    return past;
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.roleTag}>GROOMER DASHBOARD</Text>
          <Text style={[Typography.header2, styles.groomerName]}>
            {groomer?.name || 'Stylist'}
          </Text>
        </View>

        <TouchableOpacity onPress={handleLogout} style={styles.logoutBtn}>
          <Ionicons name="log-out-outline" size={22} color={Colors.danger} />
        </TouchableOpacity>
      </View>

      {/* Summary Stat Tiles */}
      <View style={styles.statsRow}>
        <View style={styles.statTile}>
          <Text style={styles.statNumber}>{upcoming.length}</Text>
          <Text style={styles.statLabel}>Today's Queue</Text>
        </View>
        <View style={styles.statTile}>
          <Text style={[styles.statNumber, { color: Colors.warning }]}>{pending.length}</Text>
          <Text style={styles.statLabel}>Pending Requests</Text>
        </View>
        <View style={styles.statTile}>
          <Text style={[styles.statNumber, { color: Colors.success }]}>{past.length}</Text>
          <Text style={styles.statLabel}>Completed</Text>
        </View>
      </View>

      {/* Tabs */}
      <View style={styles.tabsRow}>
        {(['upcoming', 'pending', 'past'] as GroomerTab[]).map((tab) => (
          <TouchableOpacity
            key={tab}
            onPress={() => setActiveTab(tab)}
            style={[styles.tabBtn, activeTab === tab ? styles.activeTabBtn : undefined]}
          >
            <Text style={[styles.tabBtnText, activeTab === tab ? styles.activeTabBtnText : undefined]}>
              {tab === 'upcoming' ? 'Upcoming' : tab === 'pending' ? 'Pending' : 'Completed'}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {loading ? (
        <ActivityIndicator color={Colors.primary} size="large" style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={getList()}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={styles.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[Colors.primary]} />}
          ListEmptyComponent={
            <View style={styles.emptyBox}>
              <Ionicons name="calendar-outline" size={36} color={Colors.textSecondary} />
              <Text style={styles.emptyText}>No {activeTab} bookings scheduled.</Text>
            </View>
          }
          renderItem={({ item }) => (
            <View style={styles.bookingCard}>
              <View style={styles.cardHeader}>
                <Text style={styles.bookingCode}>{item.bookingCode || `SH-${item.id}`}</Text>
                <View style={styles.statusPill}>
                  <Text style={styles.statusText}>{item.status.toUpperCase()}</Text>
                </View>
              </View>

              <Text style={styles.petLine}>
                🐾 <Text style={{ fontWeight: '700' }}>{item.petName || 'Pet'}</Text> ({item.petBreed || 'Breed'})
              </Text>

              <Text style={styles.serviceLine}>
                ✂️ {item.serviceName || item.packageName || 'Treatment'}
              </Text>

              <View style={styles.timeLine}>
                <Ionicons name="time-outline" size={14} color={Colors.textSecondary} />
                <Text style={styles.timeText}>
                  {item.bookingDate ? new Date(item.bookingDate).toDateString() : ''} at {item.startTime}
                </Text>
              </View>

              {item.instructions ? (
                <View style={styles.notesBox}>
                  <Text style={styles.notesText}>⚠️ Note: {item.instructions}</Text>
                </View>
              ) : null}

              {/* Action Buttons */}
              <View style={styles.actionRow}>
                {item.status === 'pending' && (
                  <>
                    <TouchableOpacity
                      onPress={() => handleReject(item.id)}
                      style={[styles.btn, styles.rejectBtn]}
                    >
                      <Text style={styles.rejectBtnText}>Decline</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => handleApprove(item.id)}
                      style={[styles.btn, styles.approveBtn]}
                    >
                      <Text style={styles.approveBtnText}>Approve</Text>
                    </TouchableOpacity>
                  </>
                )}

                {item.status === 'confirmed' && (
                  <TouchableOpacity
                    onPress={() => handleStart(item.id)}
                    style={[styles.btn, styles.startBtn]}
                  >
                    <Text style={styles.startBtnText}>Start Service</Text>
                  </TouchableOpacity>
                )}

                {item.status === 'in_progress' && (
                  <TouchableOpacity
                    onPress={() => handleComplete(item.id)}
                    style={[styles.btn, styles.completeBtn]}
                  >
                    <Text style={styles.completeBtnText}>Mark Completed</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>
          )}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  header: {
    backgroundColor: Colors.white,
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.xl,
    paddingBottom: Spacing.md,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
  },
  roleTag: {
    fontSize: 10,
    fontWeight: '800',
    color: Colors.primary,
    letterSpacing: 1,
  },
  groomerName: {
    fontSize: 20,
    marginTop: 2,
  },
  logoutBtn: {
    padding: Spacing.sm,
  },
  statsRow: {
    flexDirection: 'row',
    padding: Spacing.md,
    gap: Spacing.sm,
  },
  statTile: {
    flex: 1,
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.md,
    padding: Spacing.md,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  statNumber: {
    fontSize: 22,
    fontWeight: '800',
    color: Colors.primary,
  },
  statLabel: {
    fontSize: 11,
    color: Colors.textSecondary,
    fontWeight: '600',
    marginTop: 2,
    textAlign: 'center',
  },
  tabsRow: {
    flexDirection: 'row',
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  tabBtn: {
    flex: 1,
    paddingVertical: 12,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: Colors.transparent,
  },
  activeTabBtn: {
    borderBottomColor: Colors.primary,
  },
  tabBtnText: {
    fontSize: 13,
    fontWeight: '600',
    color: Colors.textSecondary,
  },
  activeTabBtnText: {
    color: Colors.primary,
  },
  list: {
    padding: Spacing.lg,
    gap: Spacing.md,
  },
  emptyBox: {
    alignItems: 'center',
    padding: Spacing.xxl,
  },
  emptyText: {
    color: Colors.textSecondary,
    fontSize: 14,
    marginTop: Spacing.sm,
  },
  bookingCard: {
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  bookingCode: {
    fontSize: 14,
    fontWeight: '700',
    color: Colors.textPrimary,
  },
  statusPill: {
    backgroundColor: '#CCFBF1',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: BorderRadius.pill,
  },
  statusText: {
    fontSize: 10,
    fontWeight: '700',
    color: Colors.primary,
  },
  petLine: {
    fontSize: 15,
    color: Colors.textPrimary,
    marginVertical: 2,
  },
  serviceLine: {
    fontSize: 13,
    color: Colors.textSecondary,
    marginBottom: 4,
  },
  timeLine: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 2,
  },
  timeText: {
    fontSize: 12,
    color: Colors.textSecondary,
  },
  notesBox: {
    backgroundColor: '#FEF3C7',
    padding: Spacing.sm,
    borderRadius: BorderRadius.sm,
    marginTop: Spacing.sm,
  },
  notesText: {
    fontSize: 12,
    color: '#B45309',
  },
  actionRow: {
    flexDirection: 'row',
    gap: Spacing.sm,
    marginTop: Spacing.md,
    paddingTop: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
  },
  btn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
  },
  approveBtn: {
    backgroundColor: Colors.primary,
  },
  approveBtnText: {
    color: Colors.white,
    fontWeight: '700',
    fontSize: 13,
  },
  rejectBtn: {
    backgroundColor: '#FEE2E2',
  },
  rejectBtnText: {
    color: Colors.danger,
    fontWeight: '700',
    fontSize: 13,
  },
  startBtn: {
    backgroundColor: '#2563EB',
  },
  startBtnText: {
    color: Colors.white,
    fontWeight: '700',
    fontSize: 13,
  },
  completeBtn: {
    backgroundColor: Colors.success,
  },
  completeBtnText: {
    color: Colors.white,
    fontWeight: '700',
    fontSize: 13,
  },
});
