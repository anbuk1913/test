import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Header } from '../../components/Header';
import { chatRepository } from '../../repositories/chatRepository';
import { ChatMessage } from '../../models/common';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

export const ChatScreen: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  const [connected, setConnected] = useState(false);
  const flatListRef = useRef<FlatList>(null);

  useEffect(() => {
    loadChat();

    // Connect Socket.IO
    chatRepository.connectSocket((newMsg) => {
      setMessages((prev) => [...prev, newMsg]);
      setConnected(true);
    });

    return () => {
      chatRepository.disconnectSocket();
    };
  }, []);

  const loadChat = async () => {
    try {
      const history = await chatRepository.getChatHistory();
      if (history.length > 0) {
        setMessages(history);
      } else {
        // Welcoming assistant message fallback
        setMessages([
          {
            id: 'welcome_1',
            message: 'Hello! Welcome to Shear Heaven Pet Spa. How can our grooming team help you and your pet today?',
            isCustomer: false,
            createdAt: new Date().toISOString(),
          },
        ]);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSend = () => {
    if (!text.trim()) return;

    const newMsg: ChatMessage = {
      id: String(Date.now()),
      message: text.trim(),
      isCustomer: true,
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, newMsg]);
    chatRepository.sendMessage(text.trim());
    setText('');

    setTimeout(() => {
      flatListRef.current?.scrollToEnd({ animated: true });
    }, 100);
  };

  const cannedResponses = [
    'Is my pet ready for pickup?',
    'Running 5 minutes late',
    'Do you provide de-shedding treatments?',
  ];

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
      style={styles.container}
    >
      <Header
        title="Salon Live Chat"
        rightAction={
          <View style={styles.onlineBadge}>
            <View style={styles.onlineDot} />
            <Text style={styles.onlineText}>Salon Staff</Text>
          </View>
        }
      />

      {loading ? (
        <ActivityIndicator color={Colors.primary} size="large" style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={styles.messageList}
          onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
          renderItem={({ item }) => (
            <View
              style={[
                styles.bubbleWrapper,
                item.isCustomer ? styles.bubbleRight : styles.bubbleLeft,
              ]}
            >
              <View
                style={[
                  styles.bubble,
                  item.isCustomer ? styles.customerBubble : styles.staffBubble,
                ]}
              >
                <Text
                  style={[
                    styles.messageText,
                    item.isCustomer ? styles.customerText : styles.staffText,
                  ]}
                >
                  {item.message}
                </Text>
                <Text
                  style={[
                    styles.timeText,
                    item.isCustomer ? styles.customerTimeText : styles.staffTimeText,
                  ]}
                >
                  {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </Text>
              </View>
            </View>
          )}
        />
      )}

      {/* Canned Prompts Bar */}
      <View style={styles.cannedBar}>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={cannedResponses}
          keyExtractor={(item) => item}
          contentContainerStyle={{ gap: 8, paddingHorizontal: Spacing.md }}
          renderItem={({ item }) => (
            <TouchableOpacity
              onPress={() => setText(item)}
              style={styles.cannedPill}
            >
              <Text style={styles.cannedPillText}>{item}</Text>
            </TouchableOpacity>
          )}
        />
      </View>

      {/* Input Bar */}
      <View style={styles.inputBar}>
        <TextInput
          placeholder="Message grooming team..."
          placeholderTextColor={Colors.placeholder}
          value={text}
          onChangeText={setText}
          style={styles.input}
          multiline
        />
        <TouchableOpacity
          onPress={handleSend}
          disabled={!text.trim()}
          style={[styles.sendBtn, !text.trim() ? styles.sendBtnDisabled : undefined]}
        >
          <Ionicons name="send" size={18} color={Colors.white} />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  onlineBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: '#DCFCE7',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: BorderRadius.pill,
  },
  onlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#16A34A',
  },
  onlineText: {
    fontSize: 11,
    color: '#166534',
    fontWeight: '700',
  },
  messageList: {
    padding: Spacing.lg,
    gap: Spacing.md,
  },
  bubbleWrapper: {
    width: '100%',
    flexDirection: 'row',
  },
  bubbleLeft: {
    justifyContent: 'flex-start',
  },
  bubbleRight: {
    justifyContent: 'flex-end',
  },
  bubble: {
    maxWidth: '78%',
    padding: Spacing.md,
    borderRadius: BorderRadius.lg,
  },
  customerBubble: {
    backgroundColor: Colors.primary,
    borderBottomRightRadius: 2,
  },
  staffBubble: {
    backgroundColor: Colors.white,
    borderBottomLeftRadius: 2,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  messageText: {
    fontSize: 14,
    lineHeight: 20,
  },
  customerText: {
    color: Colors.white,
  },
  staffText: {
    color: Colors.textPrimary,
  },
  timeText: {
    fontSize: 10,
    marginTop: 4,
    alignSelf: 'flex-end',
  },
  customerTimeText: {
    color: '#CCFBF1',
  },
  staffTimeText: {
    color: Colors.textSecondary,
  },
  cannedBar: {
    backgroundColor: Colors.white,
    paddingVertical: 8,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: Colors.border,
  },
  cannedPill: {
    backgroundColor: Colors.surface,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderRadius: BorderRadius.pill,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  cannedPillText: {
    fontSize: 12,
    color: Colors.textPrimary,
    fontWeight: '500',
  },
  inputBar: {
    backgroundColor: Colors.white,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    gap: Spacing.sm,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
  },
  input: {
    flex: 1,
    maxHeight: 100,
    minHeight: 44,
    backgroundColor: Colors.surface,
    borderRadius: BorderRadius.pill,
    paddingHorizontal: Spacing.lg,
    paddingVertical: 10,
    fontSize: 14,
    color: Colors.textPrimary,
  },
  sendBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
  },
  sendBtnDisabled: {
    backgroundColor: Colors.disabled,
  },
});
