import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { Header } from '../../components/Header';
import { offerRepository } from '../../repositories/commonRepositories';
import { OfferModel } from '../../models/common';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

export const OffersScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const [offers, setOffers] = useState<OfferModel[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOffers();
  }, []);

  const loadOffers = async () => {
    try {
      const data = await offerRepository.getOffers();
      setOffers(data);
    } finally {
      setLoading(false);
    }
  };

  const copyCode = (code: string) => {
    Alert.alert('Promo Code Copied!', `Use code "${code}" at checkout to receive your discount.`);
  };

  return (
    <View style={styles.container}>
      <Header title="Exclusive Offers" onBack={() => navigation.goBack()} />

      <FlatList
        data={offers}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => (
          <View style={styles.offerCard}>
            <View style={styles.badge}>
              <Text style={styles.badgeText}>
                {item.discountPercentage ? `${item.discountPercentage}% OFF` : `$${item.discountAmount} OFF`}
              </Text>
            </View>

            <Text style={[Typography.title, styles.title]}>{item.title}</Text>
            <Text style={styles.desc}>{item.description}</Text>

            <View style={styles.codeRow}>
              <View style={styles.codeBox}>
                <Text style={styles.codeText}>{item.code}</Text>
              </View>
              <TouchableOpacity onPress={() => copyCode(item.code)} style={styles.copyBtn}>
                <Ionicons name="copy-outline" size={16} color={Colors.white} />
                <Text style={styles.copyBtnText}>Copy</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  list: {
    padding: Spacing.lg,
    gap: Spacing.md,
  },
  offerCard: {
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    elevation: 2,
  },
  badge: {
    backgroundColor: '#DCFCE7',
    paddingHorizontal: Spacing.sm,
    paddingVertical: 4,
    borderRadius: BorderRadius.pill,
    alignSelf: 'flex-start',
    marginBottom: Spacing.sm,
  },
  badgeText: {
    color: '#166534',
    fontSize: 12,
    fontWeight: '700',
  },
  title: {
    fontSize: 18,
    marginBottom: 6,
  },
  desc: {
    fontSize: 14,
    color: Colors.textSecondary,
    marginBottom: Spacing.lg,
    lineHeight: 20,
  },
  codeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  codeBox: {
    flex: 1,
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.border,
    borderStyle: 'dashed',
    borderRadius: BorderRadius.md,
    paddingVertical: 10,
    alignItems: 'center',
  },
  codeText: {
    fontSize: 16,
    fontWeight: '800',
    color: Colors.primary,
    letterSpacing: 2,
  },
  copyBtn: {
    backgroundColor: Colors.primary,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: Spacing.lg,
    paddingVertical: 12,
    borderRadius: BorderRadius.md,
  },
  copyBtnText: {
    color: Colors.white,
    fontWeight: '600',
    fontSize: 14,
  },
});
