import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity, Modal, Dimensions } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { Header } from '../../components/Header';
import { Colors, Spacing, BorderRadius } from '../../constants/theme';

const { width } = Dimensions.get('window');
const itemSize = (width - Spacing.lg * 2 - Spacing.sm * 2) / 3;

const defaultGallery = [
  require('../../../assets/images/common/svc_spa.png'),
  require('../../../assets/images/common/svc_bath_blowdry.png'),
  require('../../../assets/images/common/svc_full_grooming.png'),
  require('../../../assets/images/common/svc_breed_style.png'),
  require('../../../assets/images/common/svc_puppy.png'),
  require('../../../assets/images/common/svc_skin_care.png'),
  require('../../../assets/images/home/promo_dog.png'),
  require('../../../assets/images/splash/welcome_dog.png'),
  require('../../../assets/images/splash/splash2_dog.png'),
];

export const GalleryScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const [selectedImage, setSelectedImage] = useState<any>(null);

  return (
    <View style={styles.container}>
      <Header title="Pet Spa Gallery" onBack={() => navigation.goBack()} />

      <FlatList
        data={defaultGallery}
        keyExtractor={(_, index) => String(index)}
        numColumns={3}
        contentContainerStyle={styles.grid}
        columnWrapperStyle={styles.row}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.imageCard}
            onPress={() => setSelectedImage(item)}
            activeOpacity={0.8}
          >
            <Image source={item} style={styles.thumb} resizeMode="cover" />
          </TouchableOpacity>
        )}
      />

      {/* Fullscreen Preview Modal */}
      <Modal visible={Boolean(selectedImage)} transparent animationType="fade">
        <View style={styles.modalBg}>
          <TouchableOpacity
            style={styles.closeBtn}
            onPress={() => setSelectedImage(null)}
          >
            <Ionicons name="close-circle" size={36} color={Colors.white} />
          </TouchableOpacity>
          {selectedImage && (
            <Image source={selectedImage} style={styles.fullImage} resizeMode="contain" />
          )}
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  grid: {
    padding: Spacing.lg,
  },
  row: {
    gap: Spacing.sm,
    marginBottom: Spacing.sm,
  },
  imageCard: {
    width: itemSize,
    height: itemSize,
    borderRadius: BorderRadius.md,
    overflow: 'hidden',
    backgroundColor: Colors.white,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  thumb: {
    width: '100%',
    height: '100%',
  },
  modalBg: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.9)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeBtn: {
    position: 'absolute',
    top: 50,
    right: 20,
    zIndex: 10,
  },
  fullImage: {
    width: width * 0.9,
    height: width * 0.9,
  },
});
