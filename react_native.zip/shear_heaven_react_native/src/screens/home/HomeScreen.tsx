import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../context/AuthContext';
import { useBooking } from '../../context/BookingContext';
import { serviceRepository } from '../../repositories/serviceRepository';
import { ServiceItem } from '../../models/service';
import { ServiceCard } from '../../components/ServiceCard';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';
import { AppConfig } from '../../constants/config';

export const HomeScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const { user } = useAuth();
  const { selectService, selectPackage } = useBooking();

  const [services, setServices] = useState<ServiceItem[]>([]);
  const [packages, setPackages] = useState<ServiceItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadContent();
  }, []);

  const loadContent = async () => {
    try {
      const res = await serviceRepository.getBookingServices();
      setServices(res.breeds.slice(0, 4));
      setPackages(res.packages.slice(0, 3));
    } catch {
      // Fallback loaded automatically
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadContent();
  };

  const handleBookService = (item: ServiceItem) => {
    if (item.isPackage) {
      selectPackage(item);
    } else {
      selectService(item);
    }
    navigation.navigate('BookingService');
  };

  return (
    <ScrollView
      style={styles.container}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[Colors.primary]} />}
    >
      {/* Top Header */}
      <View style={styles.header}>
        <View style={styles.userInfo}>
          <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
            {user?.profilePictureUrl ? (
              <Image source={{ uri: user.profilePictureUrl }} style={styles.avatar} />
            ) : (
              <View style={styles.avatarPlaceholder}>
                <Ionicons name="person" size={20} color={Colors.primary} />
              </View>
            )}
          </TouchableOpacity>
          <View style={styles.userText}>
            <Text style={styles.welcomeSubtitle}>Welcome Back</Text>
            <Text style={[Typography.title, styles.userName]}>
              {user?.name || 'Pet Parent'}
            </Text>
          </View>
        </View>

        <TouchableOpacity
          onPress={() => navigation.navigate('Notifications')}
          style={styles.notifBtn}
          activeOpacity={0.7}
        >
          <Ionicons name="notifications-outline" size={24} color={Colors.textPrimary} />
        </TouchableOpacity>
      </View>

      {/* Main Hero Card */}
      <View style={styles.heroCard}>
        <View style={styles.heroContent}>
          <Text style={styles.heroBadge}>Luxury Pet Grooming</Text>
          <Text style={styles.heroTitle}>Pamper Your Pet Today</Text>
          <Text style={styles.heroSubtitle}>
            Expert stylists, gentle handling, and complete spa therapy.
          </Text>
          <TouchableOpacity
            style={styles.heroBtn}
            onPress={() => navigation.navigate('BookingService')}
            activeOpacity={0.8}
          >
            <Text style={styles.heroBtnText}>Book Appointment</Text>
            <Ionicons name="arrow-forward" size={16} color={Colors.primary} />
          </TouchableOpacity>
        </View>
        <Image
          source={require('../../../assets/images/home/promo_dog.png')}
          style={styles.heroImage}
          resizeMode="contain"
        />
      </View>

      {/* Quick Action Grid */}
      <View style={styles.quickActions}>
        <TouchableOpacity
          style={styles.actionItem}
          onPress={() => navigation.navigate('BookingService')}
          activeOpacity={0.7}
        >
          <View style={[styles.actionIconCircle, { backgroundColor: '#CCFBF1' }]}>
            <Ionicons name="calendar" size={22} color={Colors.primary} />
          </View>
          <Text style={styles.actionLabel}>Book Now</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionItem}
          onPress={() => navigation.navigate('MyPets')}
          activeOpacity={0.7}
        >
          <View style={[styles.actionIconCircle, { backgroundColor: '#FEF3C7' }]}>
            <Ionicons name="paw" size={22} color="#D97706" />
          </View>
          <Text style={styles.actionLabel}>My Pets</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionItem}
          onPress={() => navigation.navigate('Offers')}
          activeOpacity={0.7}
        >
          <View style={[styles.actionIconCircle, { backgroundColor: '#FEE2E2' }]}>
            <Ionicons name="pricetag" size={22} color="#DC2626" />
          </View>
          <Text style={styles.actionLabel}>Offers</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.actionItem}
          onPress={() => navigation.navigate('Gallery')}
          activeOpacity={0.7}
        >
          <View style={[styles.actionIconCircle, { backgroundColor: '#DBEAFE' }]}>
            <Ionicons name="images" size={22} color="#2563EB" />
          </View>
          <Text style={styles.actionLabel}>Gallery</Text>
        </TouchableOpacity>
      </View>

      {/* Popular Services Section */}
      <View style={styles.sectionHeader}>
        <Text style={[Typography.header2, styles.sectionTitle]}>Popular Services</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Services')}>
          <Text style={styles.viewAllText}>View All</Text>
        </TouchableOpacity>
      </View>

      {loading ? (
        <ActivityIndicator color={Colors.primary} size="large" style={{ marginVertical: 20 }} />
      ) : (
        <View style={styles.servicesList}>
          {services.map((item) => (
            <ServiceCard
              key={item.id}
              item={item}
              onPress={() => navigation.navigate('ServiceDetail', { service: item })}
              onBookNow={() => handleBookService(item)}
            />
          ))}
        </View>
      )}

      {/* Packages Banner Section */}
      <View style={styles.sectionHeader}>
        <Text style={[Typography.header2, styles.sectionTitle]}>Exclusive Packages</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Packages')}>
          <Text style={styles.viewAllText}>View All</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.packagesList}>
        {packages.map((pkg) => (
          <TouchableOpacity
            key={pkg.id}
            style={styles.packageCard}
            onPress={() => navigation.navigate('PackageDetail', { package: pkg })}
            activeOpacity={0.8}
          >
            <View style={styles.pkgBadge}>
              <Text style={styles.pkgBadgeText}>BUNDLE DEAL</Text>
            </View>
            <Text style={styles.pkgTitle}>{pkg.name}</Text>
            <Text style={styles.pkgDesc} numberOfLines={2}>{pkg.description}</Text>
            <View style={styles.pkgFooter}>
              <Text style={styles.pkgPrice}>{pkg.priceDisplay}</Text>
              <TouchableOpacity
                style={styles.pkgBtn}
                onPress={() => handleBookService(pkg)}
              >
                <Text style={styles.pkgBtnText}>Select</Text>
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        ))}
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.xl,
    paddingBottom: Spacing.md,
    backgroundColor: Colors.white,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
  },
  avatarPlaceholder: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#CCFBF1',
    alignItems: 'center',
    justifyContent: 'center',
  },
  userText: {
    marginLeft: Spacing.md,
  },
  welcomeSubtitle: {
    fontSize: 12,
    color: Colors.textSecondary,
  },
  userName: {
    fontSize: 16,
    fontWeight: '700',
  },
  notifBtn: {
    padding: Spacing.sm,
  },
  heroCard: {
    margin: Spacing.lg,
    backgroundColor: Colors.primary,
    borderRadius: BorderRadius.xl,
    padding: Spacing.lg,
    flexDirection: 'row',
    alignItems: 'center',
    overflow: 'hidden',
    shadowColor: Colors.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 4,
  },
  heroContent: {
    flex: 1,
    paddingRight: Spacing.sm,
  },
  heroBadge: {
    fontSize: 11,
    color: '#CCFBF1',
    fontWeight: '700',
    letterSpacing: 0.5,
    marginBottom: 4,
  },
  heroTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: Colors.white,
    marginBottom: 6,
  },
  heroSubtitle: {
    fontSize: 12,
    color: '#E0F2FE',
    lineHeight: 16,
    marginBottom: Spacing.md,
  },
  heroBtn: {
    backgroundColor: Colors.white,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.pill,
    alignSelf: 'flex-start',
  },
  heroBtnText: {
    color: Colors.primary,
    fontSize: 13,
    fontWeight: '700',
  },
  heroImage: {
    width: 100,
    height: 120,
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.lg,
  },
  actionItem: {
    alignItems: 'center',
    width: '22%',
  },
  actionIconCircle: {
    width: 54,
    height: 54,
    borderRadius: 27,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  actionLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.lg,
    marginBottom: Spacing.md,
    marginTop: Spacing.sm,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
  },
  viewAllText: {
    color: Colors.primary,
    fontWeight: '600',
    fontSize: 14,
  },
  servicesList: {
    paddingHorizontal: Spacing.lg,
  },
  packagesList: {
    paddingHorizontal: Spacing.lg,
    gap: Spacing.md,
  },
  packageCard: {
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  pkgBadge: {
    backgroundColor: '#FEF3C7',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: BorderRadius.pill,
    alignSelf: 'flex-start',
    marginBottom: 6,
  },
  pkgBadgeText: {
    fontSize: 10,
    color: '#D97706',
    fontWeight: '700',
  },
  pkgTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: Colors.textPrimary,
    marginBottom: 4,
  },
  pkgDesc: {
    fontSize: 13,
    color: Colors.textSecondary,
    marginBottom: Spacing.md,
  },
  pkgFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  pkgPrice: {
    fontSize: 17,
    fontWeight: '700',
    color: Colors.primary,
  },
  pkgBtn: {
    backgroundColor: Colors.primary,
    paddingHorizontal: Spacing.lg,
    paddingVertical: 6,
    borderRadius: BorderRadius.pill,
  },
  pkgBtnText: {
    color: Colors.white,
    fontWeight: '600',
    fontSize: 13,
  },
});
