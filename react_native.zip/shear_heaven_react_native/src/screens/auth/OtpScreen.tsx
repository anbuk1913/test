import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../context/AuthContext';
import { CustomInput } from '../../components/CustomInput';
import { PrimaryButton } from '../../components/PrimaryButton';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';

export const OtpScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const { verifyOtp, sendOtp } = useAuth();

  const email = route.params?.email || 'your email';

  const [otp, setOtp] = useState('');
  const [timer, setTimer] = useState(60);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [resending, setResending] = useState(false);

  useEffect(() => {
    if (timer <= 0) return;
    const interval = setInterval(() => {
      setTimer((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [timer]);

  const handleVerify = async () => {
    if (!otp.trim() || otp.length < 4) {
      setError('Please enter a valid verification code.');
      return;
    }

    setError('');
    setLoading(true);

    try {
      await verifyOtp(otp.trim());
      navigation.reset({
        index: 0,
        routes: [{ name: 'AccountCreated' }],
      });
    } catch (err: any) {
      setError(err?.message || 'Verification failed. Please check the code.');
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    if (timer > 0) return;
    setResending(true);
    setError('');
    try {
      await sendOtp(email);
      setTimer(60);
    } catch (err: any) {
      setError(err?.message || 'Failed to resend code');
    } finally {
      setResending(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
        <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
      </TouchableOpacity>

      <View style={styles.iconCircle}>
        <Ionicons name="mail-unread-outline" size={40} color={Colors.primary} />
      </View>

      <Text style={[Typography.header1, styles.title]}>Verification Code</Text>
      <Text style={styles.subtitle}>
        We sent an OTP verification code to <Text style={styles.emailHighlight}>{email}</Text>
      </Text>

      {error ? (
        <View style={styles.errorBox}>
          <Ionicons name="alert-circle" size={18} color={Colors.danger} />
          <Text style={styles.errorBoxText}>{error}</Text>
        </View>
      ) : null}

      <CustomInput
        placeholder="Enter 6-digit code"
        value={otp}
        onChangeText={(t) => {
          setOtp(t);
          setError('');
        }}
        keyboardType="number-pad"
        maxLength={6}
        style={styles.otpInput}
      />

      <PrimaryButton
        title="Verify & Continue"
        onPress={handleVerify}
        loading={loading}
        style={styles.verifyBtn}
      />

      <View style={styles.resendRow}>
        <Text style={styles.resendPrompt}>Didn’t receive code? </Text>
        {timer > 0 ? (
          <Text style={styles.timerText}>Resend in {timer}s</Text>
        ) : (
          <TouchableOpacity onPress={handleResend} disabled={resending}>
            <Text style={styles.resendLink}>{resending ? 'Sending...' : 'Resend Code'}</Text>
          </TouchableOpacity>
        )}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: Spacing.xl,
    flexGrow: 1,
    backgroundColor: Colors.white,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backBtn: {
    alignSelf: 'flex-start',
    marginBottom: Spacing.xl,
  },
  iconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#CCFBF1',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.lg,
  },
  title: {
    fontSize: 26,
    marginBottom: Spacing.xs,
  },
  subtitle: {
    fontSize: 14,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: Spacing.xl,
    paddingHorizontal: Spacing.md,
  },
  emailHighlight: {
    color: Colors.textPrimary,
    fontWeight: '600',
  },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.dangerLight,
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.md,
    gap: 8,
    width: '100%',
  },
  errorBoxText: {
    color: Colors.danger,
    fontSize: 13,
    flex: 1,
  },
  otpInput: {
    textAlign: 'center',
    fontSize: 24,
    letterSpacing: 8,
    fontWeight: '700',
  },
  verifyBtn: {
    width: '100%',
    marginTop: Spacing.md,
  },
  resendRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: Spacing.xl,
  },
  resendPrompt: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  timerText: {
    fontSize: 14,
    color: Colors.textSecondary,
    fontWeight: '600',
  },
  resendLink: {
    fontSize: 14,
    color: Colors.primary,
    fontWeight: '700',
  },
});
