import React, { useEffect } from 'react';
import { View, Text, StyleSheet, Image, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../../context/AuthContext';
import { Colors, Typography, Spacing } from '../../constants/theme';
import { AppConfig } from '../../constants/config';

export const SplashScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const { isAuthenticated, isGroomer, isLoading } = useAuth();

  useEffect(() => {
    if (isLoading) return;

    const timer = setTimeout(() => {
      if (isAuthenticated) {
        if (isGroomer) {
          navigation.reset({ index: 0, routes: [{ name: 'GroomerHome' }] });
        } else {
          navigation.reset({ index: 0, routes: [{ name: 'MainTabs' }] });
        }
      } else {
        navigation.reset({ index: 0, routes: [{ name: 'Welcome' }] });
      }
    }, 1500);

    return () => clearTimeout(timer);
  }, [isLoading, isAuthenticated, isGroomer]);

  return (
    <View style={styles.container}>
      <Image
        source={require('../../../assets/images/common/app_icon.png')}
        style={styles.logo}
        resizeMode="contain"
      />
      <Text style={[Typography.header1, styles.title]}>{AppConfig.APP_TITLE}</Text>
      <Text style={styles.subtitle}>{AppConfig.APP_TAGLINE}</Text>
      <ActivityIndicator size="large" color={Colors.white} style={styles.loader} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    padding: Spacing.xl,
  },
  logo: {
    width: 120,
    height: 120,
    marginBottom: Spacing.lg,
  },
  title: {
    color: Colors.white,
    textAlign: 'center',
    marginBottom: Spacing.xs,
  },
  subtitle: {
    color: '#CCFBF1',
    fontSize: 14,
    textAlign: 'center',
    fontWeight: '500',
  },
  loader: {
    marginTop: Spacing.xxxl,
  },
});
