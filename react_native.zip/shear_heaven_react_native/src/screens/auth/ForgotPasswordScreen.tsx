import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { authRepository } from '../../repositories/authRepository';
import { CustomInput } from '../../components/CustomInput';
import { PrimaryButton } from '../../components/PrimaryButton';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';

export const ForgotPasswordScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [sent, setSent] = useState(false);

  const handleSubmit = async () => {
    if (!email.trim()) {
      setError('Please enter your email address');
      return;
    }

    setError('');
    setLoading(true);

    try {
      await authRepository.forgotPassword(email);
      setSent(true);
    } catch (err: any) {
      setError(err?.message || 'Failed to submit request');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
        <Ionicons name="arrow-back" size={24} color={Colors.textPrimary} />
      </TouchableOpacity>

      <View style={styles.iconCircle}>
        <Ionicons name="key-outline" size={40} color={Colors.primary} />
      </View>

      <Text style={[Typography.header1, styles.title]}>Forgot Password</Text>
      <Text style={styles.subtitle}>
        Enter your registered email address and we'll send you instructions to reset your password.
      </Text>

      {sent ? (
        <View style={styles.successBox}>
          <Ionicons name="checkmark-circle" size={20} color={Colors.success} />
          <Text style={styles.successText}>Password reset instructions have been sent to your email.</Text>
          <PrimaryButton
            title="Back to Login"
            onPress={() => navigation.navigate('Login')}
            style={{ marginTop: Spacing.lg, width: '100%' }}
          />
        </View>
      ) : (
        <View style={{ width: '100%' }}>
          {error ? (
            <View style={styles.errorBox}>
              <Ionicons name="alert-circle" size={18} color={Colors.danger} />
              <Text style={styles.errorBoxText}>{error}</Text>
            </View>
          ) : null}

          <CustomInput
            label="Email Address"
            placeholder="e.g. user@example.com"
            value={email}
            onChangeText={(t) => {
              setEmail(t);
              setError('');
            }}
            keyboardType="email-address"
            autoCapitalize="none"
            leftIcon={<Ionicons name="mail-outline" size={20} color={Colors.textSecondary} />}
          />

          <PrimaryButton
            title="Send Reset Instructions"
            onPress={handleSubmit}
            loading={loading}
            style={{ marginTop: Spacing.md }}
          />
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: Spacing.xl,
    flexGrow: 1,
    backgroundColor: Colors.white,
    justifyContent: 'center',
    alignItems: 'center',
  },
  backBtn: {
    alignSelf: 'flex-start',
    marginBottom: Spacing.xl,
  },
  iconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#CCFBF1',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.lg,
  },
  title: {
    fontSize: 26,
    marginBottom: Spacing.xs,
  },
  subtitle: {
    fontSize: 14,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: Spacing.xl,
    paddingHorizontal: Spacing.md,
  },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.dangerLight,
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.md,
    gap: 8,
  },
  errorBoxText: {
    color: Colors.danger,
    fontSize: 13,
    flex: 1,
  },
  successBox: {
    backgroundColor: Colors.successLight,
    padding: Spacing.xl,
    borderRadius: BorderRadius.lg,
    alignItems: 'center',
    width: '100%',
  },
  successText: {
    color: Colors.success,
    fontSize: 14,
    textAlign: 'center',
    marginTop: Spacing.sm,
    fontWeight: '500',
  },
});
