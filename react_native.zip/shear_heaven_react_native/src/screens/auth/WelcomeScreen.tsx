import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { PrimaryButton } from '../../components/PrimaryButton';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';
import { AppConfig } from '../../constants/config';

export const WelcomeScreen: React.FC = () => {
  const navigation = useNavigation<any>();

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.imageWrapper}>
        <Image
          source={require('../../../assets/images/splash/welcome_dog.png')}
          style={styles.heroImage}
          resizeMode="contain"
        />
      </View>

      <View style={styles.content}>
        <Text style={[Typography.header1, styles.title]}>{AppConfig.APP_TITLE}</Text>
        <Text style={styles.tagline}>{AppConfig.APP_TAGLINE}</Text>
        <Text style={styles.description}>
          Book premium spa treatments, gentle styling, and full grooming sessions for your loving pets in seconds.
        </Text>

        <View style={styles.actions}>
          <PrimaryButton
            title="Log In"
            onPress={() => navigation.navigate('Login')}
            style={styles.loginBtn}
          />

          <PrimaryButton
            title="Create Account"
            variant="outline"
            onPress={() => navigation.navigate('Signup')}
            style={styles.signupBtn}
          />

          <TouchableOpacity
            onPress={() => navigation.navigate('GroomerLogin')}
            style={styles.groomerLink}
          >
            <Text style={styles.groomerText}>Are you a Groomer? Access Groomer Portal</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: Colors.white,
    justifyContent: 'space-between',
  },
  imageWrapper: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#F0FDFA',
    paddingTop: Spacing.xxxl,
    paddingBottom: Spacing.xl,
  },
  heroImage: {
    width: 260,
    height: 260,
  },
  content: {
    padding: Spacing.xl,
    backgroundColor: Colors.white,
    borderTopLeftRadius: BorderRadius.xl,
    borderTopRightRadius: BorderRadius.xl,
  },
  title: {
    fontSize: 26,
    color: Colors.textPrimary,
    textAlign: 'center',
    marginBottom: Spacing.xs,
  },
  tagline: {
    fontSize: 14,
    color: Colors.primary,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: Spacing.md,
  },
  description: {
    fontSize: 14,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: Spacing.xl,
  },
  actions: {
    gap: Spacing.md,
  },
  loginBtn: {
    width: '100%',
  },
  signupBtn: {
    width: '100%',
  },
  groomerLink: {
    paddingVertical: Spacing.md,
    alignItems: 'center',
  },
  groomerText: {
    fontSize: 13,
    color: Colors.primary,
    fontWeight: '600',
    textDecorationLine: 'underline',
  },
});
