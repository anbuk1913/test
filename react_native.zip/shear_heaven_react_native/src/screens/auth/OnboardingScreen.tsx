import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, Dimensions, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { PrimaryButton } from '../../components/PrimaryButton';
import { Colors, Typography, Spacing, BorderRadius } from '../../constants/theme';

const { width } = Dimensions.get('window');

const slides = [
  {
    id: 1,
    title: 'Expert Pet Care & Styling',
    description: 'Certified pet groomers delivering stress-free styling, baths, and health care treatments.',
    image: require('../../../assets/images/splash/splash2_dog.png'),
  },
  {
    id: 2,
    title: 'Seamless Scheduling',
    description: 'Select your favorite groomer, choose real-time open slots, and confirm appointments instantly.',
    image: require('../../../assets/images/splash/splash3_dog.png'),
  },
  {
    id: 3,
    title: 'All-in-One Pet Hub',
    description: 'Track vaccination records, chat directly with salon staff, and access member-only promotions.',
    image: require('../../../assets/images/splash/welcome_dog.png'),
  },
];

export const OnboardingScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const [currentIndex, setCurrentIndex] = useState(0);

  const handleNext = () => {
    if (currentIndex < slides.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      navigation.replace('Welcome');
    }
  };

  const currentSlide = slides[currentIndex];

  return (
    <View style={styles.container}>
      <View style={styles.topBar}>
        <TouchableOpacity onPress={() => navigation.replace('Welcome')}>
          <Text style={styles.skipText}>Skip</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.content}>
        <Image source={currentSlide.image} style={styles.image} resizeMode="contain" />
        <Text style={[Typography.header2, styles.title]}>{currentSlide.title}</Text>
        <Text style={styles.description}>{currentSlide.description}</Text>

        <View style={styles.pagination}>
          {slides.map((_, i) => (
            <View
              key={i}
              style={[
                styles.dot,
                i === currentIndex ? styles.activeDot : undefined,
              ]}
            />
          ))}
        </View>
      </View>

      <View style={styles.footer}>
        <PrimaryButton
          title={currentIndex === slides.length - 1 ? 'Get Started' : 'Next'}
          onPress={handleNext}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
    justifyContent: 'space-between',
    padding: Spacing.xl,
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    paddingTop: Spacing.xl,
  },
  skipText: {
    fontSize: 14,
    color: Colors.textSecondary,
    fontWeight: '600',
  },
  content: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: Spacing.lg,
  },
  image: {
    width: width * 0.7,
    height: width * 0.7,
    marginBottom: Spacing.xxl,
  },
  title: {
    textAlign: 'center',
    marginBottom: Spacing.sm,
  },
  description: {
    textAlign: 'center',
    fontSize: 14,
    color: Colors.textSecondary,
    lineHeight: 22,
    marginBottom: Spacing.xl,
  },
  pagination: {
    flexDirection: 'row',
    gap: 8,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: Colors.border,
  },
  activeDot: {
    width: 24,
    backgroundColor: Colors.primary,
  },
  footer: {
    paddingBottom: Spacing.xl,
  },
});
