import React from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { PrimaryButton } from '../../components/PrimaryButton';
import { Colors, Typography, Spacing } from '../../constants/theme';

export const AccountCreatedScreen: React.FC = () => {
  const navigation = useNavigation<any>();

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        <Image
          source={require('../../../assets/images/auth/account_success_dog.png')}
          style={styles.image}
          resizeMode="contain"
        />
        <Text style={[Typography.header1, styles.title]}>Account Created!</Text>
        <Text style={styles.subtitle}>
          Welcome to Shear Heaven Pet Spa. Your pet grooming journey begins now!
        </Text>
      </View>

      <View style={styles.footer}>
        <PrimaryButton
          title="Go to Home"
          onPress={() => navigation.reset({ index: 0, routes: [{ name: 'MainTabs' }] })}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
    padding: Spacing.xl,
    justifyContent: 'space-between',
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: Spacing.lg,
  },
  image: {
    width: 220,
    height: 220,
    marginBottom: Spacing.xxl,
  },
  title: {
    fontSize: 26,
    textAlign: 'center',
    marginBottom: Spacing.xs,
  },
  subtitle: {
    fontSize: 14,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
  },
  footer: {
    paddingBottom: Spacing.lg,
  },
});
