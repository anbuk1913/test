import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  Switch,
  Alert,
} from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { Header } from '../../components/Header';
import { CustomInput } from '../../components/CustomInput';
import { PrimaryButton } from '../../components/PrimaryButton';
import { petRepository } from '../../repositories/petRepository';
import { Pet } from '../../models/pet';
import { useBooking } from '../../context/BookingContext';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

const weightOptions = ['0 - 15 lbs', '16 - 30 lbs', '31 - 60 lbs', '61 - 90 lbs', '90+ lbs'];

export const CreatePetScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const editingPet: Pet | undefined = route.params?.pet;

  const [petName, setPetName] = useState(editingPet?.petName || '');
  const [breed, setBreed] = useState(editingPet?.breed || '');
  const [gender, setGender] = useState<'male' | 'female'>(
    (editingPet?.gender?.toLowerCase() as 'male' | 'female') || 'male'
  );
  const [weight, setWeight] = useState(editingPet?.weight || '16 - 30 lbs');
  const [age, setAge] = useState(editingPet?.age ? String(editingPet.age) : '');
  const [notes, setNotes] = useState(editingPet?.notesAllergies || '');
  const [vaccinated, setVaccinated] = useState(Boolean(editingPet?.allVaccinatedCurrent ?? true));
  const [photoUri, setPhotoUri] = useState<string | undefined>(
    editingPet?.profilePictureUrl || editingPet?.image
  );

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const pickImage = async () => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission Denied', 'Camera roll access is needed to upload pet photos.');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ['images'],
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]) {
      setPhotoUri(result.assets[0].uri);
    }
  };

  const handleSave = async () => {
    if (!petName.trim()) {
      setError('Please provide a name for your pet.');
      return;
    }

    setError('');
    setLoading(true);

    try {
      if (editingPet?.id) {
        await petRepository.updatePet(editingPet.id, {
          petName,
          breed,
          gender,
          weight,
          age,
          notesAllergies: notes,
          allVaccinatedCurrent: vaccinated,
          photoUri,
        });
        Alert.alert('Success', 'Pet profile updated successfully.');
      } else {
        await petRepository.createPet({
          petName,
          breed,
          gender,
          weight,
          age,
          notesAllergies: notes,
          allVaccinatedCurrent: vaccinated,
          photoUri,
        });
        Alert.alert('Success', 'Pet added to your profile.');
      }
      navigation.goBack();
    } catch (err: any) {
      setError(err?.message || 'Failed to save pet profile.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Header
        title={editingPet ? 'Edit Pet Profile' : 'Add New Pet'}
        onBack={() => navigation.goBack()}
      />

      <ScrollView contentContainerStyle={styles.content}>
        {/* Photo Picker */}
        <View style={styles.avatarSection}>
          <TouchableOpacity onPress={pickImage} style={styles.avatarWrapper}>
            {photoUri ? (
              <Image source={{ uri: photoUri }} style={styles.avatar} />
            ) : (
              <View style={styles.placeholder}>
                <Ionicons name="paw" size={40} color={Colors.primary} />
              </View>
            )}
            <View style={styles.cameraBadge}>
              <Ionicons name="camera" size={16} color={Colors.white} />
            </View>
          </TouchableOpacity>
          <Text style={styles.avatarHint}>Tap to choose a photo</Text>
        </View>

        {error ? (
          <View style={styles.errorBox}>
            <Ionicons name="alert-circle" size={18} color={Colors.danger} />
            <Text style={styles.errorText}>{error}</Text>
          </View>
        ) : null}

        {/* Basic Info */}
        <CustomInput
          label="Pet Name *"
          placeholder="e.g. Milo, Bella"
          value={petName}
          onChangeText={(t) => {
            setPetName(t);
            setError('');
          }}
        />

        <CustomInput
          label="Breed"
          placeholder="e.g. Golden Retriever, Poodle, Persian Cat"
          value={breed}
          onChangeText={setBreed}
        />

        {/* Gender */}
        <Text style={styles.fieldLabel}>Gender</Text>
        <View style={styles.genderRow}>
          <TouchableOpacity
            onPress={() => setGender('male')}
            style={[styles.genderPill, gender === 'male' ? styles.activeGenderPill : undefined]}
          >
            <Ionicons
              name="male"
              size={18}
              color={gender === 'male' ? Colors.white : Colors.textSecondary}
            />
            <Text
              style={[
                styles.genderText,
                gender === 'male' ? styles.activeGenderText : undefined,
              ]}
            >
              Male
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={() => setGender('female')}
            style={[styles.genderPill, gender === 'female' ? styles.activeGenderPill : undefined]}
          >
            <Ionicons
              name="female"
              size={18}
              color={gender === 'female' ? Colors.white : Colors.textSecondary}
            />
            <Text
              style={[
                styles.genderText,
                gender === 'female' ? styles.activeGenderText : undefined,
              ]}
            >
              Female
            </Text>
          </TouchableOpacity>
        </View>

        {/* Weight Category */}
        <Text style={styles.fieldLabel}>Weight Category</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.weightsRow}>
          {weightOptions.map((w) => (
            <TouchableOpacity
              key={w}
              onPress={() => setWeight(w)}
              style={[styles.weightPill, weight === w ? styles.activeWeightPill : undefined]}
            >
              <Text
                style={[
                  styles.weightText,
                  weight === w ? styles.activeWeightText : undefined,
                ]}
              >
                {w}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <CustomInput
          label="Age (Years)"
          placeholder="e.g. 3"
          value={age}
          onChangeText={setAge}
          keyboardType="numeric"
          style={{ marginTop: Spacing.md }}
        />

        <CustomInput
          label="Allergies / Special Medical Notes"
          placeholder="e.g. Hypoallergenic shampoo required..."
          value={notes}
          onChangeText={setNotes}
          multiline
          numberOfLines={2}
        />

        {/* Vaccination Switch */}
        <View style={styles.switchRow}>
          <View style={{ flex: 1 }}>
            <Text style={styles.switchTitle}>Vaccinations Up to Date</Text>
            <Text style={styles.switchDesc}>Rabies, DHPP, and Bordetella are current</Text>
          </View>
          <Switch
            value={vaccinated}
            onValueChange={setVaccinated}
            trackColor={{ false: Colors.border, true: Colors.primary }}
          />
        </View>

        <PrimaryButton
          title={editingPet ? 'Update Pet Profile' : 'Save Pet'}
          onPress={handleSave}
          loading={loading}
          style={styles.saveBtn}
        />
      </ScrollView>
    </View>
  );
};

export const PetSelectScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const { setPet } = useBooking();
  const [pets, setPets] = useState<Pet[]>([]);
  const [loading, setLoading] = useState(true);

  React.useEffect(() => {
    petRepository.getAllPets().then((data) => {
      setPets(data);
      setLoading(false);
    });
  }, []);

  const handleSelect = (p: Pet) => {
    setPet(p);
    navigation.goBack();
  };

  return (
    <View style={styles.container}>
      <Header title="Choose Pet for Booking" onBack={() => navigation.goBack()} />
      <ScrollView contentContainerStyle={styles.content}>
        {pets.map((p) => (
          <TouchableOpacity
            key={p.id}
            onPress={() => handleSelect(p)}
            style={styles.selectPetItem}
          >
            <Ionicons name="paw" size={24} color={Colors.primary} />
            <View style={{ flex: 1, marginLeft: Spacing.md }}>
              <Text style={[Typography.title, { fontSize: 16 }]}>{p.petName}</Text>
              <Text style={{ color: Colors.textSecondary, fontSize: 13 }}>{p.breed || 'Pet'}</Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color={Colors.textSecondary} />
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  content: {
    padding: Spacing.lg,
    paddingBottom: Spacing.xxxl,
  },
  avatarSection: {
    alignItems: 'center',
    marginBottom: Spacing.xl,
  },
  avatarWrapper: {
    position: 'relative',
  },
  avatar: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  placeholder: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: '#CCFBF1',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cameraBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: Colors.primary,
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: Colors.white,
  },
  avatarHint: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginTop: 8,
  },
  errorBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.dangerLight,
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    marginBottom: Spacing.md,
    gap: 8,
  },
  errorText: {
    color: Colors.danger,
    fontSize: 13,
    flex: 1,
  },
  fieldLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: Colors.textPrimary,
    marginBottom: Spacing.xs,
  },
  genderRow: {
    flexDirection: 'row',
    gap: Spacing.md,
    marginBottom: Spacing.md,
  },
  genderPill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 48,
    borderRadius: BorderRadius.md,
    borderWidth: 1,
    borderColor: Colors.border,
    backgroundColor: Colors.white,
  },
  activeGenderPill: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  genderText: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  activeGenderText: {
    color: Colors.white,
  },
  weightsRow: {
    gap: Spacing.sm,
    paddingVertical: 4,
    marginBottom: Spacing.md,
  },
  weightPill: {
    paddingHorizontal: Spacing.md,
    paddingVertical: 10,
    borderRadius: BorderRadius.pill,
    backgroundColor: Colors.white,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  activeWeightPill: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  weightText: {
    fontSize: 13,
    color: Colors.textPrimary,
    fontWeight: '600',
  },
  activeWeightText: {
    color: Colors.white,
  },
  switchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    marginVertical: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  switchTitle: {
    fontSize: 14,
    fontWeight: '600',
  },
  switchDesc: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  saveBtn: {
    marginTop: Spacing.lg,
  },
  selectPetItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    padding: Spacing.md,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: Spacing.md,
  },
});
