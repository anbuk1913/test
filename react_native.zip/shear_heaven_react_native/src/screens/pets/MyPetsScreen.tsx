import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, ActivityIndicator, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Header } from '../../components/Header';
import { PetCard } from '../../components/PetCard';
import { PrimaryButton } from '../../components/PrimaryButton';
import { EmptyState } from '../../components/ServiceCard';
import { petRepository } from '../../repositories/petRepository';
import { Pet } from '../../models/pet';
import { Colors, Spacing } from '../../constants/theme';

export const MyPetsScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const [pets, setPets] = useState<Pet[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = navigation.addListener('focus', () => {
      loadPets();
    });
    loadPets();
    return unsub;
  }, [navigation]);

  const loadPets = async () => {
    try {
      const list = await petRepository.getAllPets();
      setPets(list);
    } finally {
      setLoading(false);
    }
  };

  const handleDeletePet = (pet: Pet) => {
    Alert.alert('Delete Pet', `Are you sure you want to remove ${pet.petName}?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await petRepository.deletePet(pet.id);
            loadPets();
          } catch (err: any) {
            Alert.alert('Error', err?.message || 'Failed to delete pet');
          }
        },
      },
    ]);
  };

  return (
    <View style={styles.container}>
      <Header
        title="My Pets"
        onBack={() => navigation.goBack()}
        rightAction={
          <PrimaryButton
            title="+ Add Pet"
            onPress={() => navigation.navigate('CreatePet')}
            style={styles.addBtn}
            textStyle={{ fontSize: 13 }}
          />
        }
      />

      {loading ? (
        <ActivityIndicator color={Colors.primary} size="large" style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={pets}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={styles.list}
          ListEmptyComponent={
            <EmptyState
              icon="paw-outline"
              title="No Pets Added Yet"
              message="Add your dog or cat profile to easily book grooming sessions and store health notes."
              actionText="Add My First Pet"
              onAction={() => navigation.navigate('CreatePet')}
            />
          }
          renderItem={({ item }) => (
            <PetCard
              pet={item}
              onPress={() => navigation.navigate('CreatePet', { pet: item })}
              onEdit={() => navigation.navigate('CreatePet', { pet: item })}
              onDelete={() => handleDeletePet(item)}
            />
          )}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  list: {
    padding: Spacing.lg,
  },
  addBtn: {
    height: 36,
    paddingHorizontal: Spacing.md,
  },
});
