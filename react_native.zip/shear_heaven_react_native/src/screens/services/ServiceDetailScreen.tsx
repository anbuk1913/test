import React from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { Header } from '../../components/Header';
import { PrimaryButton } from '../../components/PrimaryButton';
import { useBooking } from '../../context/BookingContext';
import { ServiceItem } from '../../models/service';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

export const ServiceDetailScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const { selectService } = useBooking();

  const service: ServiceItem = route.params?.service || {
    id: 1,
    name: 'Full Grooming',
    description: 'Complete bath, blow dry, thorough brush out, haircut/styling, ear cleaning, and nail trim.',
    price: 65,
    priceDisplay: '$65.00',
    durationMinutes: 90,
    includes: ['Cleansing Bath', 'Fluff Blow Dry', 'Haircut Styling', 'Ear Cleaning', 'Nail Trimming'],
  };

  const handleBook = () => {
    selectService(service);
    navigation.navigate('BookingService');
  };

  return (
    <View style={styles.container}>
      <Header title={service.name} onBack={() => navigation.goBack()} />

      <ScrollView contentContainerStyle={styles.content}>
        {/* Banner */}
        <View style={styles.banner}>
          <Image
            source={require('../../../assets/images/common/svc_full_grooming.png')}
            style={styles.bannerImage}
            resizeMode="contain"
          />
        </View>

        {/* Details Card */}
        <View style={styles.card}>
          <View style={styles.titleRow}>
            <Text style={[Typography.header2, styles.name]}>{service.name}</Text>
            <Text style={styles.price}>{service.priceDisplay}</Text>
          </View>

          <View style={styles.metaRow}>
            <View style={styles.metaBadge}>
              <Ionicons name="time-outline" size={16} color={Colors.primary} />
              <Text style={styles.metaText}>
                {service.durationMinutes > 0 ? `${service.durationMinutes} mins` : 'Flexible Duration'}
              </Text>
            </View>
            <View style={styles.metaBadge}>
              <Ionicons name="sparkles-outline" size={16} color={Colors.accent} />
              <Text style={styles.metaText}>Premium Care</Text>
            </View>
          </View>

          <Text style={styles.sectionHeader}>Description</Text>
          <Text style={styles.description}>{service.description}</Text>

          {service.includes && service.includes.length > 0 && (
            <>
              <Text style={styles.sectionHeader}>What's Included</Text>
              <View style={styles.includesList}>
                {service.includes.map((inc, i) => (
                  <View key={i} style={styles.includeRow}>
                    <Ionicons name="checkmark-circle" size={18} color={Colors.primary} />
                    <Text style={styles.includeText}>{inc}</Text>
                  </View>
                ))}
              </View>
            </>
          )}

          <View style={styles.guaranteeBox}>
            <Ionicons name="shield-checkmark-outline" size={24} color={Colors.primary} />
            <View style={{ flex: 1 }}>
              <Text style={styles.guaranteeTitle}>Stress-Free Guarantee</Text>
              <Text style={styles.guaranteeDesc}>
                We prioritize pet comfort with positive reinforcement and gentle handling techniques.
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>

      {/* Floating Bottom Bar */}
      <View style={styles.bottomBar}>
        <View>
          <Text style={styles.barTotalLabel}>Estimated Total</Text>
          <Text style={styles.barTotalPrice}>{service.priceDisplay}</Text>
        </View>
        <PrimaryButton
          title="Book This Service"
          onPress={handleBook}
          style={styles.bookBtn}
        />
      </View>
    </View>
  );
};

export const PackageDetailScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const { selectPackage } = useBooking();

  const pkg: ServiceItem = route.params?.package || {
    id: 101,
    name: 'Spa Package',
    description: 'Full Service Pet Grooming with coat conditioning, nail buffing, and blueberry facial.',
    price: 85,
    priceDisplay: '$85.00',
    durationMinutes: 120,
    includes: ['Full Grooming', 'Deep Coat Conditioning', 'Nail Buffing', 'Blueberry Facial', 'Finishing Mist'],
  };

  const handleBook = () => {
    selectPackage(pkg);
    navigation.navigate('BookingService');
  };

  return (
    <View style={styles.container}>
      <Header title={pkg.name} onBack={() => navigation.goBack()} />

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.banner}>
          <Image
            source={require('../../../assets/images/common/svc_spa.png')}
            style={styles.bannerImage}
            resizeMode="contain"
          />
        </View>

        <View style={styles.card}>
          <View style={styles.pkgBadge}>
            <Text style={styles.pkgBadgeText}>EXCLUSIVE SPA BUNDLE</Text>
          </View>

          <View style={styles.titleRow}>
            <Text style={[Typography.header2, styles.name]}>{pkg.name}</Text>
            <Text style={styles.price}>{pkg.priceDisplay}</Text>
          </View>

          <View style={styles.metaRow}>
            <View style={styles.metaBadge}>
              <Ionicons name="time-outline" size={16} color={Colors.primary} />
              <Text style={styles.metaText}>{pkg.durationMinutes} mins</Text>
            </View>
          </View>

          <Text style={styles.sectionHeader}>Package Details</Text>
          <Text style={styles.description}>{pkg.description}</Text>

          {pkg.includes && (
            <>
              <Text style={styles.sectionHeader}>All Included Treatments</Text>
              <View style={styles.includesList}>
                {pkg.includes.map((inc, i) => (
                  <View key={i} style={styles.includeRow}>
                    <Ionicons name="checkmark-done-circle" size={18} color={Colors.secondary} />
                    <Text style={styles.includeText}>{inc}</Text>
                  </View>
                ))}
              </View>
            </>
          )}
        </View>
      </ScrollView>

      <View style={styles.bottomBar}>
        <View>
          <Text style={styles.barTotalLabel}>Package Price</Text>
          <Text style={styles.barTotalPrice}>{pkg.priceDisplay}</Text>
        </View>
        <PrimaryButton
          title="Select Package"
          onPress={handleBook}
          style={styles.bookBtn}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  content: {
    paddingBottom: 100,
  },
  banner: {
    height: 180,
    backgroundColor: '#F0FDFA',
    alignItems: 'center',
    justifyContent: 'center',
  },
  bannerImage: {
    width: 140,
    height: 140,
  },
  card: {
    backgroundColor: Colors.white,
    padding: Spacing.xl,
    borderTopLeftRadius: BorderRadius.xl,
    borderTopRightRadius: BorderRadius.xl,
    marginTop: -20,
  },
  titleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  name: {
    fontSize: 22,
    flex: 1,
  },
  price: {
    fontSize: 22,
    fontWeight: '800',
    color: Colors.primary,
  },
  metaRow: {
    flexDirection: 'row',
    gap: Spacing.md,
    marginBottom: Spacing.lg,
  },
  metaBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: Colors.surface,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderRadius: BorderRadius.pill,
  },
  metaText: {
    fontSize: 13,
    color: Colors.textPrimary,
    fontWeight: '500',
  },
  pkgBadge: {
    backgroundColor: '#FEF3C7',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: BorderRadius.pill,
    alignSelf: 'flex-start',
    marginBottom: Spacing.sm,
  },
  pkgBadgeText: {
    color: '#D97706',
    fontWeight: '700',
    fontSize: 11,
  },
  sectionHeader: {
    fontSize: 16,
    fontWeight: '700',
    marginTop: Spacing.lg,
    marginBottom: Spacing.sm,
  },
  description: {
    fontSize: 14,
    color: Colors.textSecondary,
    lineHeight: 22,
  },
  includesList: {
    gap: Spacing.sm,
  },
  includeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
  },
  includeText: {
    fontSize: 14,
    color: Colors.textPrimary,
  },
  guaranteeBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    backgroundColor: '#CCFBF1',
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
    marginTop: Spacing.xl,
  },
  guaranteeTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: Colors.primary,
  },
  guaranteeDesc: {
    fontSize: 12,
    color: Colors.textSecondary,
    lineHeight: 16,
    marginTop: 2,
  },
  bottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 84,
    backgroundColor: Colors.white,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.xl,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    elevation: 8,
  },
  barTotalLabel: {
    fontSize: 12,
    color: Colors.textSecondary,
  },
  barTotalPrice: {
    fontSize: 20,
    fontWeight: '800',
    color: Colors.primary,
  },
  bookBtn: {
    paddingHorizontal: Spacing.xl,
    height: 48,
  },
});
