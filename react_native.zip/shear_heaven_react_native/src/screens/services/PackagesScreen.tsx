import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { Header } from '../../components/Header';
import { serviceRepository } from '../../repositories/serviceRepository';
import { useBooking } from '../../context/BookingContext';
import { ServiceItem } from '../../models/service';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

export const PackagesScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const { selectPackage } = useBooking();
  const [packages, setPackages] = useState<ServiceItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPackages();
  }, []);

  const loadPackages = async () => {
    try {
      const res = await serviceRepository.getBookingServices();
      setPackages(res.packages);
    } finally {
      setLoading(false);
    }
  };

  const handleSelectPackage = (pkg: ServiceItem) => {
    selectPackage(pkg);
    navigation.navigate('BookingService');
  };

  return (
    <View style={styles.container}>
      <Header title="All Packages" onBack={() => navigation.goBack()} />

      {loading ? (
        <ActivityIndicator color={Colors.primary} size="large" style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={packages}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.card}
              onPress={() => navigation.navigate('PackageDetail', { package: item })}
              activeOpacity={0.8}
            >
              <View style={styles.badge}>
                <Text style={styles.badgeText}>SPECIAL SPA BUNDLE</Text>
              </View>

              <View style={styles.titleRow}>
                <Text style={[Typography.title, styles.title]}>{item.name}</Text>
                <Text style={styles.price}>{item.priceDisplay}</Text>
              </View>

              <Text style={styles.description}>{item.description}</Text>

              {item.includes && item.includes.length > 0 && (
                <View style={styles.inclusions}>
                  {item.includes.slice(0, 3).map((inc, i) => (
                    <View key={i} style={styles.incRow}>
                      <Ionicons name="checkmark-circle" size={14} color={Colors.secondary} />
                      <Text style={styles.incText}>{inc}</Text>
                    </View>
                  ))}
                  {item.includes.length > 3 && (
                    <Text style={styles.moreText}>+ {item.includes.length - 3} more treatments</Text>
                  )}
                </View>
              )}

              <View style={styles.footer}>
                <View style={styles.duration}>
                  <Ionicons name="time-outline" size={14} color={Colors.textSecondary} />
                  <Text style={styles.durationText}>{item.durationMinutes} mins</Text>
                </View>
                <TouchableOpacity
                  style={styles.selectBtn}
                  onPress={() => handleSelectPackage(item)}
                >
                  <Text style={styles.selectBtnText}>Select Package</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  list: {
    padding: Spacing.lg,
    gap: Spacing.md,
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    elevation: 2,
  },
  badge: {
    backgroundColor: '#FEF3C7',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: BorderRadius.pill,
    alignSelf: 'flex-start',
    marginBottom: Spacing.sm,
  },
  badgeText: {
    color: '#D97706',
    fontWeight: '700',
    fontSize: 10,
  },
  titleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  title: {
    fontSize: 18,
    flex: 1,
  },
  price: {
    fontSize: 18,
    fontWeight: '800',
    color: Colors.primary,
  },
  description: {
    fontSize: 13,
    color: Colors.textSecondary,
    lineHeight: 18,
    marginBottom: Spacing.md,
  },
  inclusions: {
    gap: 4,
    marginBottom: Spacing.md,
    backgroundColor: Colors.surface,
    padding: Spacing.sm,
    borderRadius: BorderRadius.md,
  },
  incRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  incText: {
    fontSize: 12,
    color: Colors.textPrimary,
  },
  moreText: {
    fontSize: 11,
    color: Colors.textSecondary,
    fontStyle: 'italic',
    marginTop: 2,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 4,
  },
  duration: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  durationText: {
    fontSize: 12,
    color: Colors.textSecondary,
  },
  selectBtn: {
    backgroundColor: Colors.primary,
    paddingHorizontal: Spacing.lg,
    paddingVertical: 8,
    borderRadius: BorderRadius.pill,
  },
  selectBtnText: {
    color: Colors.white,
    fontSize: 13,
    fontWeight: '600',
  },
});
