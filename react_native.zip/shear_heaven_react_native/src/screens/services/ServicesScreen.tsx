import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  TextInput,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { useBooking } from '../../context/BookingContext';
import { serviceRepository } from '../../repositories/serviceRepository';
import { ServiceItem } from '../../models/service';
import { ServiceCard } from '../../components/ServiceCard';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

type TabKey = 'all' | 'breeds' | 'packages' | 'addons' | 'walkin';

export const ServicesScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const { selectService, selectPackage, toggleAddOn } = useBooking();

  const [activeTab, setActiveTab] = useState<TabKey>('all');
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  const [breeds, setBreeds] = useState<ServiceItem[]>([]);
  const [packages, setPackages] = useState<ServiceItem[]>([]);
  const [addOns, setAddOns] = useState<ServiceItem[]>([]);
  const [walkIn, setWalkIn] = useState<ServiceItem[]>([]);

  useEffect(() => {
    loadServices();
  }, []);

  const loadServices = async () => {
    try {
      const res = await serviceRepository.getBookingServices();
      setBreeds(res.breeds);
      setPackages(res.packages);
      setAddOns(res.addOns);
      setWalkIn(res.walkIn);
    } finally {
      setLoading(false);
    }
  };

  const getFilteredList = (): ServiceItem[] => {
    let list: ServiceItem[] = [];
    switch (activeTab) {
      case 'breeds':
        list = breeds;
        break;
      case 'packages':
        list = packages;
        break;
      case 'addons':
        list = addOns;
        break;
      case 'walkin':
        list = walkIn;
        break;
      case 'all':
      default:
        list = [...breeds, ...packages, ...addOns, ...walkIn];
        break;
    }

    if (!search.trim()) return list;
    const q = search.toLowerCase();
    return list.filter(
      (item) => item.name.toLowerCase().includes(q) || item.description.toLowerCase().includes(q)
    );
  };

  const handleBookItem = (item: ServiceItem) => {
    if (item.isPackage) {
      selectPackage(item);
    } else if (item.isAddOn) {
      toggleAddOn(item);
    } else {
      selectService(item);
    }
    navigation.navigate('BookingService');
  };

  const tabs: Array<{ key: TabKey; label: string }> = [
    { key: 'all', label: 'All' },
    { key: 'breeds', label: 'Services' },
    { key: 'packages', label: 'Packages' },
    { key: 'addons', label: 'Add-Ons' },
    { key: 'walkin', label: 'Walk-In' },
  ];

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={[Typography.header1, styles.headerTitle]}>Services & Packages</Text>
        <Text style={styles.headerSubtitle}>Choose treatments tailored to your pet</Text>

        {/* Search */}
        <View style={styles.searchBar}>
          <Ionicons name="search-outline" size={18} color={Colors.textSecondary} />
          <TextInput
            placeholder="Search treatments or packages..."
            placeholderTextColor={Colors.placeholder}
            value={search}
            onChangeText={setSearch}
            style={styles.searchInput}
          />
          {search ? (
            <TouchableOpacity onPress={() => setSearch('')}>
              <Ionicons name="close-circle" size={18} color={Colors.textSecondary} />
            </TouchableOpacity>
          ) : null}
        </View>

        {/* Filter Pills */}
        <View style={styles.tabRow}>
          {tabs.map((tab) => (
            <TouchableOpacity
              key={tab.key}
              onPress={() => setActiveTab(tab.key)}
              style={[styles.tabPill, activeTab === tab.key ? styles.activeTabPill : undefined]}
            >
              <Text
                style={[
                  styles.tabPillText,
                  activeTab === tab.key ? styles.activeTabPillText : undefined,
                ]}
              >
                {tab.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* List */}
      {loading ? (
        <ActivityIndicator color={Colors.primary} size="large" style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={getFilteredList()}
          keyExtractor={(item) => `${item.isPackage ? 'pkg' : 'svc'}_${item.id}`}
          contentContainerStyle={styles.list}
          renderItem={({ item }) => (
            <ServiceCard
              item={item}
              onPress={() => {
                if (item.isPackage) {
                  navigation.navigate('PackageDetail', { package: item });
                } else {
                  navigation.navigate('ServiceDetail', { service: item });
                }
              }}
              onBookNow={() => handleBookItem(item)}
            />
          )}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  header: {
    backgroundColor: Colors.white,
    paddingHorizontal: Spacing.lg,
    paddingTop: Spacing.xl,
    paddingBottom: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
  },
  headerTitle: {
    fontSize: 24,
    marginBottom: 4,
  },
  headerSubtitle: {
    fontSize: 13,
    color: Colors.textSecondary,
    marginBottom: Spacing.md,
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    paddingHorizontal: Spacing.md,
    borderRadius: BorderRadius.md,
    height: 44,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: Spacing.md,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: Colors.textPrimary,
    marginLeft: Spacing.sm,
  },
  tabRow: {
    flexDirection: 'row',
    gap: 8,
  },
  tabPill: {
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderRadius: BorderRadius.pill,
    backgroundColor: Colors.surface,
  },
  activeTabPill: {
    backgroundColor: Colors.primary,
  },
  tabPillText: {
    fontSize: 13,
    fontWeight: '600',
    color: Colors.textSecondary,
  },
  activeTabPillText: {
    color: Colors.white,
  },
  list: {
    padding: Spacing.lg,
  },
});
