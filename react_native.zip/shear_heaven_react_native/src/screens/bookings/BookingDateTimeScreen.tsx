import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { Header } from '../../components/Header';
import { PrimaryButton } from '../../components/PrimaryButton';
import { useBooking } from '../../context/BookingContext';
import { storeRepository } from '../../repositories/storeRepository';
import { bookingRepository } from '../../repositories/bookingRepository';
import { BookingGroomer, BookingSlot } from '../../models/booking';
import { GroomerStaff } from '../../models/common';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

export const BookingDateTimeScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const { draft, setBookingDate, setSlot, setGroomer, calculatePricingAndDuration } = useBooking();

  const [dates, setDates] = useState<Array<{ dateStr: string; day: string; dayNum: string; isAvailable: boolean }>>([]);
  const [groomers, setGroomers] = useState<GroomerStaff[]>([]);
  const [slots, setSlots] = useState<BookingSlot[]>([]);
  const [loadingSlots, setLoadingSlots] = useState(false);

  useEffect(() => {
    generateDates();
    loadGroomers();
  }, []);

  const generateDates = () => {
    const list = [];
    const today = new Date();

    // 14-day window matching Flutter app BookingDateUtils
    for (let i = 0; i < 14; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() + i);

      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const dd = String(d.getDate()).padStart(2, '0');
      const dateStr = `${yyyy}-${mm}-${dd}`;

      const day = d.toLocaleDateString('en-US', { weekday: 'short' });
      const dayNum = String(d.getDate());
      // Sunday closed by default
      const isAvailable = d.getDay() !== 0;

      list.push({ dateStr, day, dayNum, isAvailable });
    }

    setDates(list);
    if (!draft.bookingDate && list.length > 0) {
      const firstOpen = list.find((item) => item.isAvailable) || list[0];
      setBookingDate(firstOpen.dateStr);
    }
  };

  const loadGroomers = async () => {
    try {
      const staff = await storeRepository.getGroomers();
      setGroomers(staff);
    } catch {
      // Fallback
    }
  };

  useEffect(() => {
    if (draft.bookingDate) {
      fetchAvailableSlots();
      calculatePricingAndDuration();
    }
  }, [draft.bookingDate, draft.groomer]);

  const fetchAvailableSlots = async () => {
    setLoadingSlots(true);
    try {
      const res = await bookingRepository.getGroomerAvailability({
        date: draft.bookingDate,
        durationMinutes: draft.totalDurationMinutes || 60,
        groomerId: draft.groomer?.id,
      });

      const serverSlots = res?.availableSlots || res?.slots || [];
      if (Array.isArray(serverSlots) && serverSlots.length > 0) {
        setSlots(
          serverSlots.map((s: any) => ({
            time: typeof s === 'string' ? s : s.startTime || s.time,
            startTime: typeof s === 'string' ? s : s.startTime || s.time,
            endTime: s.endTime || '',
            available: true,
          }))
        );
      } else {
        // Standard schedule fallback slots
        setSlots([
          { time: '09:00 AM', startTime: '09:00', endTime: '10:30', available: true },
          { time: '10:30 AM', startTime: '10:30', endTime: '12:00', available: true },
          { time: '11:45 AM', startTime: '11:45', endTime: '01:15', available: true },
          { time: '01:30 PM', startTime: '13:30', endTime: '15:00', available: true },
          { time: '03:00 PM', startTime: '15:00', endTime: '16:30', available: true },
          { time: '04:15 PM', startTime: '16:15', endTime: '17:45', available: true },
        ]);
      }
    } catch {
      setSlots([
        { time: '09:00 AM', startTime: '09:00', endTime: '10:30', available: true },
        { time: '10:30 AM', startTime: '10:30', endTime: '12:00', available: true },
        { time: '01:30 PM', startTime: '13:30', endTime: '15:00', available: true },
        { time: '03:00 PM', startTime: '15:00', endTime: '16:30', available: true },
      ]);
    } finally {
      setLoadingSlots(false);
    }
  };

  const handleNext = () => {
    if (!draft.bookingDate) {
      Alert.alert('Date Required', 'Please select an appointment date.');
      return;
    }
    if (!draft.slot) {
      Alert.alert('Time Slot Required', 'Please choose an available appointment time slot.');
      return;
    }
    navigation.navigate('BookingReview');
  };

  return (
    <View style={styles.container}>
      <Header title="Date & Time - Step 2 of 3" onBack={() => navigation.goBack()} />

      <ScrollView contentContainerStyle={styles.content}>
        {/* Step Indicator */}
        <View style={styles.stepper}>
          <View style={styles.stepDot} />
          <View style={styles.stepLine} />
          <View style={[styles.stepDot, styles.activeStepDot]} />
          <View style={styles.stepLine} />
          <View style={styles.stepDot} />
        </View>

        {/* Calendar Horizontal Bar */}
        <Text style={[Typography.title, styles.sectionTitle]}>Select Appointment Date</Text>
        <Text style={styles.sectionSubtitle}>14-day advance booking window</Text>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.dateList}>
          {dates.map((d) => {
            const isSelected = draft.bookingDate === d.dateStr;
            return (
              <TouchableOpacity
                key={d.dateStr}
                disabled={!d.isAvailable}
                onPress={() => setBookingDate(d.dateStr)}
                style={[
                  styles.datePill,
                  isSelected ? styles.activeDatePill : undefined,
                  !d.isAvailable ? styles.disabledDatePill : undefined,
                ]}
                activeOpacity={0.8}
              >
                <Text style={[styles.dayText, isSelected ? styles.activeDayText : undefined]}>
                  {d.day}
                </Text>
                <Text style={[styles.dayNum, isSelected ? styles.activeDayNum : undefined]}>
                  {d.dayNum}
                </Text>
                {!d.isAvailable && <Text style={styles.closedTag}>Closed</Text>}
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Groomer Selector */}
        <Text style={[Typography.title, styles.sectionTitle, { marginTop: Spacing.xl }]}>
          Groomer Preference
        </Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.groomersList}>
          {/* Any Groomer option */}
          <TouchableOpacity
            onPress={() => setGroomer(null)}
            style={[styles.groomerCard, !draft.groomer ? styles.activeGroomerCard : undefined]}
            activeOpacity={0.8}
          >
            <View style={[styles.avatarCircle, !draft.groomer ? styles.activeAvatarCircle : undefined]}>
              <Ionicons name="people" size={20} color={!draft.groomer ? Colors.white : Colors.primary} />
            </View>
            <Text style={[styles.groomerName, !draft.groomer ? styles.activeGroomerText : undefined]}>
              Any Groomer
            </Text>
            <Text style={styles.groomerRole}>First available</Text>
          </TouchableOpacity>

          {/* Specific staff */}
          {groomers.map((g) => {
            const isSelected = draft.groomer?.id === g.id;
            return (
              <TouchableOpacity
                key={g.id}
                onPress={() => setGroomer({ id: g.id, name: g.name, experience: g.specialization })}
                style={[styles.groomerCard, isSelected ? styles.activeGroomerCard : undefined]}
                activeOpacity={0.8}
              >
                <View style={[styles.avatarCircle, isSelected ? styles.activeAvatarCircle : undefined]}>
                  <Ionicons name="person" size={20} color={isSelected ? Colors.white : Colors.primary} />
                </View>
                <Text style={[styles.groomerName, isSelected ? styles.activeGroomerText : undefined]}>
                  {g.name}
                </Text>
                <Text style={styles.groomerRole}>{g.specialization || g.role}</Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>

        {/* Time Slots Section */}
        <Text style={[Typography.title, styles.sectionTitle, { marginTop: Spacing.xl }]}>
          Available Time Slots
        </Text>
        <Text style={styles.sectionSubtitle}>
          Appointment duration: {draft.totalDurationMinutes} mins
        </Text>

        {loadingSlots ? (
          <ActivityIndicator color={Colors.primary} size="large" style={{ marginVertical: 20 }} />
        ) : (
          <View style={styles.slotsGrid}>
            {slots.map((s, idx) => {
              const isSelected = draft.slot?.startTime === s.startTime || draft.slot?.time === s.time;
              return (
                <TouchableOpacity
                  key={idx}
                  onPress={() => setSlot(s)}
                  style={[styles.slotPill, isSelected ? styles.activeSlotPill : undefined]}
                  activeOpacity={0.8}
                >
                  <Ionicons
                    name="time-outline"
                    size={14}
                    color={isSelected ? Colors.white : Colors.textPrimary}
                  />
                  <Text style={[styles.slotText, isSelected ? styles.activeSlotText : undefined]}>
                    {s.time}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>
        )}
      </ScrollView>

      {/* Bottom Floating Bar */}
      <View style={styles.bottomBar}>
        <View>
          <Text style={styles.barDate}>
            {draft.bookingDate ? new Date(draft.bookingDate).toDateString() : 'Select date'}
          </Text>
          <Text style={styles.barSlot}>
            {draft.slot ? draft.slot.time : 'Select a slot'}
          </Text>
        </View>

        <PrimaryButton
          title="Review Booking"
          onPress={handleNext}
          style={styles.reviewBtn}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  content: {
    padding: Spacing.lg,
    paddingBottom: 110,
  },
  stepper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.lg,
  },
  stepDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: Colors.disabled,
  },
  activeStepDot: {
    backgroundColor: Colors.primary,
    width: 14,
    height: 14,
    borderRadius: 7,
  },
  stepLine: {
    width: 40,
    height: 2,
    backgroundColor: Colors.border,
    marginHorizontal: 4,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
  },
  sectionSubtitle: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginBottom: Spacing.md,
  },
  dateList: {
    gap: Spacing.sm,
    paddingVertical: 4,
  },
  datePill: {
    width: 60,
    height: 74,
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeDatePill: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  disabledDatePill: {
    backgroundColor: Colors.surfaceLight,
    opacity: 0.5,
  },
  dayText: {
    fontSize: 11,
    color: Colors.textSecondary,
    fontWeight: '600',
  },
  activeDayText: {
    color: '#CCFBF1',
  },
  dayNum: {
    fontSize: 18,
    fontWeight: '800',
    color: Colors.textPrimary,
    marginTop: 2,
  },
  activeDayNum: {
    color: Colors.white,
  },
  closedTag: {
    fontSize: 9,
    color: Colors.danger,
    marginTop: 2,
  },
  groomersList: {
    gap: Spacing.sm,
    paddingVertical: 4,
  },
  groomerCard: {
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
    width: 120,
  },
  activeGroomerCard: {
    borderColor: Colors.primary,
    backgroundColor: '#F0FDFA',
    borderWidth: 1.5,
  },
  avatarCircle: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#CCFBF1',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  activeAvatarCircle: {
    backgroundColor: Colors.primary,
  },
  groomerName: {
    fontSize: 13,
    fontWeight: '700',
    textAlign: 'center',
  },
  activeGroomerText: {
    color: Colors.primary,
  },
  groomerRole: {
    fontSize: 10,
    color: Colors.textSecondary,
    textAlign: 'center',
    marginTop: 2,
  },
  slotsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.sm,
  },
  slotPill: {
    width: '31%',
    backgroundColor: Colors.white,
    paddingVertical: 12,
    borderRadius: BorderRadius.md,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 4,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  activeSlotPill: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  slotText: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  activeSlotText: {
    color: Colors.white,
  },
  bottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 84,
    backgroundColor: Colors.white,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.xl,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    elevation: 8,
  },
  barDate: {
    fontSize: 13,
    fontWeight: '700',
    color: Colors.textPrimary,
  },
  barSlot: {
    fontSize: 12,
    color: Colors.primary,
    fontWeight: '600',
    marginTop: 2,
  },
  reviewBtn: {
    paddingHorizontal: Spacing.xl,
    height: 48,
  },
});
