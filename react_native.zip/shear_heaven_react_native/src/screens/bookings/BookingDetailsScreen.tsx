import React from 'react';
import { View, Text, StyleSheet, ScrollView, Alert, TouchableOpacity } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { Header } from '../../components/Header';
import { PrimaryButton } from '../../components/PrimaryButton';
import { bookingRepository } from '../../repositories/bookingRepository';
import { Booking } from '../../models/booking';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

export const BookingDetailsScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const booking: Booking = route.params?.booking || {
    id: 1,
    bookingCode: 'SH-8492',
    status: 'confirmed',
    bookingDate: new Date().toISOString(),
    startTime: '10:00 AM',
    endTime: '11:30 AM',
    totalPrice: 65,
    totalDurationMinutes: 90,
    petName: 'Milo',
    serviceName: 'Full Grooming',
  };

  const handleCancel = () => {
    Alert.alert(
      'Cancel Appointment',
      'Are you sure you want to cancel this booking?',
      [
        { text: 'Keep', style: 'cancel' },
        {
          text: 'Cancel Appointment',
          style: 'destructive',
          onPress: async () => {
            try {
              await bookingRepository.cancelBooking(booking.id);
              Alert.alert('Cancelled', 'Your appointment has been cancelled.');
              navigation.goBack();
            } catch (err: any) {
              Alert.alert('Error', err?.message || 'Failed to cancel appointment');
            }
          },
        },
      ]
    );
  };

  return (
    <View style={styles.container}>
      <Header title="Appointment Details" onBack={() => navigation.goBack()} />

      <ScrollView contentContainerStyle={styles.content}>
        {/* Status Card */}
        <View style={styles.card}>
          <View style={styles.statusHeader}>
            <Text style={styles.codeText}>{booking.bookingCode || `SH-${booking.id}`}</Text>
            <View style={styles.statusPill}>
              <Text style={styles.statusPillText}>{booking.status.toUpperCase()}</Text>
            </View>
          </View>

          <Text style={[Typography.header2, styles.serviceTitle]}>
            {booking.serviceName || booking.packageName || 'Pet Grooming Treatment'}
          </Text>

          <View style={styles.divider} />

          <View style={styles.row}>
            <Ionicons name="paw" size={18} color={Colors.primary} />
            <Text style={styles.rowLabel}>Pet Name</Text>
            <Text style={styles.rowVal}>{booking.petName || 'Pet'}</Text>
          </View>

          <View style={styles.row}>
            <Ionicons name="calendar" size={18} color={Colors.primary} />
            <Text style={styles.rowLabel}>Date</Text>
            <Text style={styles.rowVal}>
              {booking.bookingDate ? new Date(booking.bookingDate).toDateString() : ''}
            </Text>
          </View>

          <View style={styles.row}>
            <Ionicons name="time" size={18} color={Colors.primary} />
            <Text style={styles.rowLabel}>Time</Text>
            <Text style={styles.rowVal}>{booking.startTime}</Text>
          </View>

          <View style={styles.row}>
            <Ionicons name="person" size={18} color={Colors.primary} />
            <Text style={styles.rowLabel}>Groomer</Text>
            <Text style={styles.rowVal}>{booking.groomerName || 'Staff Specialist'}</Text>
          </View>
        </View>

        {/* Salon Location Card */}
        <View style={styles.card}>
          <Text style={[Typography.title, styles.cardTitle]}>Salon Location</Text>
          <View style={styles.salonInfo}>
            <Ionicons name="location" size={24} color={Colors.primary} />
            <View style={{ flex: 1 }}>
              <Text style={styles.salonName}>Shear Heaven Pet Spa</Text>
              <Text style={styles.salonAddress}>123 Meadow Lane, Arlington, TX 76010</Text>
              <Text style={styles.salonContact}>Phone: (817) 555-0199</Text>
            </View>
          </View>
        </View>

        {/* Receipt Breakdown Card */}
        <View style={styles.card}>
          <Text style={[Typography.title, styles.cardTitle]}>Payment Receipt</Text>
          <View style={styles.priceRow}>
            <Text style={styles.priceLabel}>Treatment Fee</Text>
            <Text style={styles.priceVal}>${booking.totalPrice.toFixed(2)}</Text>
          </View>
          <View style={styles.priceRow}>
            <Text style={styles.priceLabel}>Taxes & Fees</Text>
            <Text style={styles.priceVal}>Included</Text>
          </View>
          <View style={styles.divider} />
          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>Total Paid / Due</Text>
            <Text style={styles.totalVal}>${booking.totalPrice.toFixed(2)}</Text>
          </View>
        </View>

        {/* Cancel Button */}
        {booking.status === 'confirmed' || booking.status === 'pending' ? (
          <TouchableOpacity onPress={handleCancel} style={styles.cancelBtn}>
            <Text style={styles.cancelBtnText}>Cancel This Appointment</Text>
          </TouchableOpacity>
        ) : null}
      </ScrollView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  content: {
    padding: Spacing.lg,
    gap: Spacing.md,
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  statusHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.xs,
  },
  codeText: {
    fontSize: 14,
    color: Colors.textSecondary,
    fontWeight: '700',
  },
  statusPill: {
    backgroundColor: Colors.successLight,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: BorderRadius.pill,
  },
  statusPillText: {
    color: Colors.success,
    fontSize: 11,
    fontWeight: '700',
  },
  serviceTitle: {
    fontSize: 20,
    marginTop: 4,
  },
  divider: {
    height: 1,
    backgroundColor: Colors.border,
    marginVertical: Spacing.md,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
  },
  rowLabel: {
    fontSize: 14,
    color: Colors.textSecondary,
    marginLeft: Spacing.sm,
    flex: 1,
  },
  rowVal: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  cardTitle: {
    fontSize: 16,
    marginBottom: Spacing.md,
  },
  salonInfo: {
    flexDirection: 'row',
    gap: Spacing.md,
  },
  salonName: {
    fontSize: 15,
    fontWeight: '700',
    color: Colors.textPrimary,
  },
  salonAddress: {
    fontSize: 13,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  salonContact: {
    fontSize: 13,
    color: Colors.primary,
    marginTop: 4,
    fontWeight: '600',
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 4,
  },
  priceLabel: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  priceVal: {
    fontSize: 14,
    fontWeight: '600',
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  totalLabel: {
    fontSize: 16,
    fontWeight: '700',
  },
  totalVal: {
    fontSize: 18,
    fontWeight: '800',
    color: Colors.primary,
  },
  cancelBtn: {
    padding: Spacing.md,
    alignItems: 'center',
    marginTop: Spacing.sm,
  },
  cancelBtnText: {
    color: Colors.danger,
    fontSize: 14,
    fontWeight: '700',
  },
});
