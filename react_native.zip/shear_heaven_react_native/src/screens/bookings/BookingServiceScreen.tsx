import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { Header } from '../../components/Header';
import { PrimaryButton } from '../../components/PrimaryButton';
import { useBooking } from '../../context/BookingContext';
import { petRepository } from '../../repositories/petRepository';
import { serviceRepository } from '../../repositories/serviceRepository';
import { Pet } from '../../models/pet';
import { ServiceItem } from '../../models/service';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

export const BookingServiceScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const {
    draft,
    setPet,
    selectService,
    selectPackage,
    toggleAddOn,
  } = useBooking();

  const [pets, setPets] = useState<Pet[]>([]);
  const [breeds, setBreeds] = useState<ServiceItem[]>([]);
  const [packages, setPackages] = useState<ServiceItem[]>([]);
  const [addOns, setAddOns] = useState<ServiceItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [allPets, svcResult] = await Promise.all([
        petRepository.getAllPets(),
        serviceRepository.getBookingServices(),
      ]);

      setPets(allPets);
      if (allPets.length > 0 && !draft.pet) {
        setPet(allPets[0]);
      }

      setBreeds(svcResult.breeds);
      setPackages(svcResult.packages);
      setAddOns(svcResult.addOns);

      // Default select first service if none selected
      if (!draft.selectedService && !draft.selectedPackage && svcResult.breeds.length > 0) {
        selectService(svcResult.breeds[0]);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleContinue = () => {
    if (!draft.pet) {
      Alert.alert('Pet Required', 'Please select or add a pet for this booking.', [
        { text: 'Add Pet', onPress: () => navigation.navigate('CreatePet') },
        { text: 'Cancel', style: 'cancel' },
      ]);
      return;
    }

    if (!draft.selectedService && !draft.selectedPackage) {
      Alert.alert('Service Required', 'Please select a primary service or package.');
      return;
    }

    navigation.navigate('BookingDateTime');
  };

  return (
    <View style={styles.container}>
      <Header title="Book Appointment - Step 1 of 3" onBack={() => navigation.goBack()} />

      <ScrollView contentContainerStyle={styles.content}>
        {/* Step Indicator */}
        <View style={styles.stepper}>
          <View style={[styles.stepDot, styles.activeStepDot]} />
          <View style={styles.stepLine} />
          <View style={styles.stepDot} />
          <View style={styles.stepLine} />
          <View style={styles.stepDot} />
        </View>

        {/* Pet Selection Section */}
        <View style={styles.sectionHeader}>
          <Text style={[Typography.title, styles.sectionTitle]}>Select Pet</Text>
          <TouchableOpacity onPress={() => navigation.navigate('CreatePet')}>
            <Text style={styles.actionText}>+ Add New</Text>
          </TouchableOpacity>
        </View>

        {pets.length === 0 ? (
          <TouchableOpacity
            style={styles.noPetCard}
            onPress={() => navigation.navigate('CreatePet')}
          >
            <Ionicons name="add-circle-outline" size={24} color={Colors.primary} />
            <Text style={styles.noPetText}>No pets found. Tap here to add your pet!</Text>
          </TouchableOpacity>
        ) : (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.petsRow}>
            {pets.map((p) => {
              const isSelected = draft.pet?.id === p.id;
              return (
                <TouchableOpacity
                  key={p.id}
                  onPress={() => setPet(p)}
                  style={[styles.petPill, isSelected ? styles.activePetPill : undefined]}
                  activeOpacity={0.8}
                >
                  <Ionicons
                    name="paw"
                    size={16}
                    color={isSelected ? Colors.white : Colors.primary}
                  />
                  <Text style={[styles.petPillText, isSelected ? styles.activePetPillText : undefined]}>
                    {p.petName}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        )}

        {/* Primary Services Section */}
        <Text style={[Typography.title, styles.sectionTitle, { marginTop: Spacing.xl }]}>
          Primary Services
        </Text>
        <View style={styles.serviceOptions}>
          {breeds.map((item) => {
            const isSelected = draft.selectedService?.id === item.id;
            return (
              <TouchableOpacity
                key={item.id}
                onPress={() => selectService(item)}
                style={[styles.optionCard, isSelected ? styles.activeOptionCard : undefined]}
                activeOpacity={0.8}
              >
                <View style={styles.optionHeader}>
                  <Text style={[Typography.title, styles.optionName]}>{item.name}</Text>
                  <Text style={styles.optionPrice}>{item.priceDisplay}</Text>
                </View>
                <Text style={styles.optionDesc}>{item.description}</Text>
                <View style={styles.optionFooter}>
                  <Text style={styles.optionDuration}>⏱ {item.durationMinutes} mins</Text>
                  <View style={[styles.radio, isSelected ? styles.radioActive : undefined]}>
                    {isSelected && <View style={styles.radioInner} />}
                  </View>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Packages Section */}
        <Text style={[Typography.title, styles.sectionTitle, { marginTop: Spacing.xl }]}>
          Or Choose a Package
        </Text>
        <View style={styles.serviceOptions}>
          {packages.map((pkg) => {
            const isSelected = draft.selectedPackage?.id === pkg.id;
            return (
              <TouchableOpacity
                key={pkg.id}
                onPress={() => selectPackage(pkg)}
                style={[styles.optionCard, isSelected ? styles.activeOptionCard : undefined]}
                activeOpacity={0.8}
              >
                <View style={styles.pkgTag}>
                  <Text style={styles.pkgTagText}>SPA PACKAGE</Text>
                </View>
                <View style={styles.optionHeader}>
                  <Text style={[Typography.title, styles.optionName]}>{pkg.name}</Text>
                  <Text style={styles.optionPrice}>{pkg.priceDisplay}</Text>
                </View>
                <Text style={styles.optionDesc}>{pkg.description}</Text>
                <View style={styles.optionFooter}>
                  <Text style={styles.optionDuration}>⏱ {pkg.durationMinutes} mins</Text>
                  <View style={[styles.radio, isSelected ? styles.radioActive : undefined]}>
                    {isSelected && <View style={styles.radioInner} />}
                  </View>
                </View>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Add-On Treatments Section */}
        <Text style={[Typography.title, styles.sectionTitle, { marginTop: Spacing.xl }]}>
          Enhance with Add-Ons
        </Text>
        <View style={styles.addOnsGrid}>
          {addOns.map((add) => {
            const isSelected = draft.addOns.some((a) => a.id === add.id);
            return (
              <TouchableOpacity
                key={add.id}
                onPress={() => toggleAddOn(add)}
                style={[styles.addOnCard, isSelected ? styles.activeAddOnCard : undefined]}
                activeOpacity={0.8}
              >
                <View style={{ flex: 1 }}>
                  <Text style={styles.addOnName}>{add.name}</Text>
                  <Text style={styles.addOnPrice}>+${add.price.toFixed(2)}</Text>
                </View>
                <View style={[styles.checkbox, isSelected ? styles.checkboxActive : undefined]}>
                  {isSelected && <Ionicons name="checkmark" size={14} color={Colors.white} />}
                </View>
              </TouchableOpacity>
            );
          })}
        </View>
      </ScrollView>

      {/* Bottom Summary Bar */}
      <View style={styles.bottomBar}>
        <View>
          <Text style={styles.totalLabel}>Estimated Total</Text>
          <Text style={styles.totalPrice}>${draft.totalPrice.toFixed(2)}</Text>
          <Text style={styles.totalDuration}>Duration: ~{draft.totalDurationMinutes} mins</Text>
        </View>

        <PrimaryButton
          title="Next: Date & Time"
          onPress={handleContinue}
          style={styles.continueBtn}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  content: {
    padding: Spacing.lg,
    paddingBottom: 110,
  },
  stepper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.lg,
  },
  stepDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: Colors.disabled,
  },
  activeStepDot: {
    backgroundColor: Colors.primary,
    width: 14,
    height: 14,
    borderRadius: 7,
  },
  stepLine: {
    width: 40,
    height: 2,
    backgroundColor: Colors.border,
    marginHorizontal: 4,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '700',
  },
  actionText: {
    fontSize: 13,
    color: Colors.primary,
    fontWeight: '600',
  },
  noPetCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    backgroundColor: '#CCFBF1',
    padding: Spacing.md,
    borderRadius: BorderRadius.md,
  },
  noPetText: {
    fontSize: 13,
    color: Colors.primary,
    fontWeight: '600',
  },
  petsRow: {
    gap: Spacing.sm,
    paddingVertical: 4,
  },
  petPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: Colors.white,
    paddingHorizontal: Spacing.md,
    paddingVertical: 10,
    borderRadius: BorderRadius.pill,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  activePetPill: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  petPillText: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  activePetPillText: {
    color: Colors.white,
  },
  serviceOptions: {
    gap: Spacing.sm,
    marginTop: Spacing.xs,
  },
  optionCard: {
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  activeOptionCard: {
    borderColor: Colors.primary,
    backgroundColor: '#F0FDFA',
    borderWidth: 1.5,
  },
  pkgTag: {
    backgroundColor: '#FEF3C7',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: BorderRadius.pill,
    alignSelf: 'flex-start',
    marginBottom: 4,
  },
  pkgTagText: {
    fontSize: 9,
    fontWeight: '700',
    color: '#D97706',
  },
  optionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  optionName: {
    fontSize: 16,
    flex: 1,
  },
  optionPrice: {
    fontSize: 16,
    fontWeight: '800',
    color: Colors.primary,
  },
  optionDesc: {
    fontSize: 13,
    color: Colors.textSecondary,
    marginVertical: 4,
  },
  optionFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 6,
  },
  optionDuration: {
    fontSize: 12,
    color: Colors.textSecondary,
  },
  radio: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 2,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioActive: {
    borderColor: Colors.primary,
  },
  radioInner: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: Colors.primary,
  },
  addOnsGrid: {
    gap: Spacing.sm,
    marginTop: Spacing.xs,
  },
  addOnCard: {
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.md,
    padding: Spacing.md,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.border,
  },
  activeAddOnCard: {
    borderColor: Colors.primary,
    backgroundColor: '#F0FDFA',
  },
  addOnName: {
    fontSize: 14,
    fontWeight: '600',
  },
  addOnPrice: {
    fontSize: 13,
    color: Colors.primary,
    fontWeight: '700',
    marginTop: 2,
  },
  checkbox: {
    width: 20,
    height: 20,
    borderRadius: 4,
    borderWidth: 1.5,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
  },
  checkboxActive: {
    backgroundColor: Colors.primary,
    borderColor: Colors.primary,
  },
  bottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 90,
    backgroundColor: Colors.white,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.xl,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    elevation: 8,
  },
  totalLabel: {
    fontSize: 12,
    color: Colors.textSecondary,
  },
  totalPrice: {
    fontSize: 20,
    fontWeight: '800',
    color: Colors.primary,
  },
  totalDuration: {
    fontSize: 11,
    color: Colors.textSecondary,
  },
  continueBtn: {
    paddingHorizontal: Spacing.xl,
    height: 48,
  },
});
