import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { Header } from '../../components/Header';
import { EmptyState } from '../../components/ServiceCard';
import { bookingRepository } from '../../repositories/bookingRepository';
import { Booking } from '../../models/booking';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

type BookingTab = 'upcoming' | 'past' | 'cancelled';

export const MyBookingsScreen: React.FC = () => {
  const navigation = useNavigation<any>();

  const [activeTab, setActiveTab] = useState<BookingTab>('upcoming');
  const [upcoming, setUpcoming] = useState<Booking[]>([]);
  const [past, setPast] = useState<Booking[]>([]);
  const [cancelled, setCancelled] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadBookings();
  }, []);

  const loadBookings = async () => {
    try {
      const [up, pst, canc] = await Promise.all([
        bookingRepository.getUpcomingBookings(),
        bookingRepository.getPastBookings(),
        bookingRepository.getCancelledBookings(),
      ]);
      setUpcoming(up);
      setPast(pst);
      setCancelled(canc);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadBookings();
  };

  const handleCancelBooking = (booking: Booking) => {
    Alert.alert(
      'Cancel Appointment',
      `Are you sure you want to cancel appointment ${booking.bookingCode || '#' + booking.id}?`,
      [
        { text: 'Keep Appointment', style: 'cancel' },
        {
          text: 'Yes, Cancel',
          style: 'destructive',
          onPress: async () => {
            try {
              await bookingRepository.cancelBooking(booking.id);
              Alert.alert('Appointment Cancelled', 'Your booking has been cancelled.');
              loadBookings();
            } catch (err: any) {
              Alert.alert('Error', err?.message || 'Failed to cancel appointment.');
            }
          },
        },
      ]
    );
  };

  const getActiveList = (): Booking[] => {
    if (activeTab === 'upcoming') return upcoming;
    if (activeTab === 'past') return past;
    return cancelled;
  };

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'confirmed':
        return { bg: Colors.successLight, text: Colors.success };
      case 'pending':
        return { bg: Colors.warningLight, text: Colors.warning };
      case 'cancelled':
      case 'rejected':
        return { bg: Colors.dangerLight, text: Colors.danger };
      case 'completed':
        return { bg: Colors.infoLight, text: Colors.info };
      default:
        return { bg: Colors.surface, text: Colors.textSecondary };
    }
  };

  return (
    <View style={styles.container}>
      <Header title="My Bookings" />

      {/* Tabs */}
      <View style={styles.tabBar}>
        {(['upcoming', 'past', 'cancelled'] as BookingTab[]).map((tab) => (
          <TouchableOpacity
            key={tab}
            onPress={() => setActiveTab(tab)}
            style={[styles.tabItem, activeTab === tab ? styles.activeTabItem : undefined]}
          >
            <Text style={[styles.tabText, activeTab === tab ? styles.activeTabText : undefined]}>
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {loading ? (
        <ActivityIndicator color={Colors.primary} size="large" style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={getActiveList()}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={styles.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} colors={[Colors.primary]} />}
          ListEmptyComponent={
            <EmptyState
              icon="calendar-outline"
              title={`No ${activeTab} appointments`}
              message={
                activeTab === 'upcoming'
                  ? 'Ready to pamper your pet? Book your appointment now.'
                  : `You have no ${activeTab} appointments at this time.`
              }
              actionText={activeTab === 'upcoming' ? 'Book Appointment' : undefined}
              onAction={() => navigation.navigate('BookingService')}
            />
          }
          renderItem={({ item }) => {
            const statusStyle = getStatusColor(item.status);
            return (
              <TouchableOpacity
                style={styles.card}
                onPress={() => navigation.navigate('BookingDetails', { booking: item })}
                activeOpacity={0.8}
              >
                <View style={styles.cardHeader}>
                  <Text style={styles.codeText}>{item.bookingCode || `SH-${item.id}`}</Text>
                  <View style={[styles.statusBadge, { backgroundColor: statusStyle.bg }]}>
                    <Text style={[styles.statusBadgeText, { color: statusStyle.text }]}>
                      {item.status.toUpperCase()}
                    </Text>
                  </View>
                </View>

                <View style={styles.infoRow}>
                  <Ionicons name="paw" size={16} color={Colors.primary} />
                  <Text style={styles.infoTitle}>
                    {item.petName || 'Pet'} • {item.serviceName || item.packageName || 'Grooming Service'}
                  </Text>
                </View>

                <View style={styles.detailsRow}>
                  <View style={styles.detailItem}>
                    <Ionicons name="calendar-outline" size={14} color={Colors.textSecondary} />
                    <Text style={styles.detailText}>
                      {item.bookingDate ? new Date(item.bookingDate).toLocaleDateString() : ''}
                    </Text>
                  </View>

                  <View style={styles.detailItem}>
                    <Ionicons name="time-outline" size={14} color={Colors.textSecondary} />
                    <Text style={styles.detailText}>{item.startTime}</Text>
                  </View>

                  {item.groomerName ? (
                    <View style={styles.detailItem}>
                      <Ionicons name="person-outline" size={14} color={Colors.textSecondary} />
                      <Text style={styles.detailText}>{item.groomerName}</Text>
                    </View>
                  ) : null}
                </View>

                <View style={styles.cardFooter}>
                  <Text style={styles.priceText}>${item.totalPrice.toFixed(2)}</Text>
                  {activeTab === 'upcoming' && (
                    <TouchableOpacity
                      onPress={() => handleCancelBooking(item)}
                      style={styles.cancelBtn}
                    >
                      <Text style={styles.cancelBtnText}>Cancel</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </TouchableOpacity>
            );
          }}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: Colors.white,
    borderBottomWidth: 1,
    borderBottomColor: Colors.border,
  },
  tabItem: {
    flex: 1,
    paddingVertical: 14,
    alignItems: 'center',
    borderBottomWidth: 2,
    borderBottomColor: Colors.transparent,
  },
  activeTabItem: {
    borderBottomColor: Colors.primary,
  },
  tabText: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.textSecondary,
  },
  activeTabText: {
    color: Colors.primary,
  },
  list: {
    padding: Spacing.lg,
    gap: Spacing.md,
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  codeText: {
    fontSize: 14,
    fontWeight: '700',
    color: Colors.textPrimary,
  },
  statusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: BorderRadius.pill,
  },
  statusBadgeText: {
    fontSize: 10,
    fontWeight: '700',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: Spacing.sm,
  },
  infoTitle: {
    fontSize: 15,
    fontWeight: '700',
    color: Colors.textPrimary,
  },
  detailsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: Spacing.md,
    marginVertical: 4,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  detailText: {
    fontSize: 13,
    color: Colors.textSecondary,
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: Spacing.md,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
    paddingTop: Spacing.sm,
  },
  priceText: {
    fontSize: 16,
    fontWeight: '800',
    color: Colors.primary,
  },
  cancelBtn: {
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderRadius: BorderRadius.pill,
    borderWidth: 1,
    borderColor: Colors.danger,
  },
  cancelBtnText: {
    color: Colors.danger,
    fontSize: 12,
    fontWeight: '600',
  },
});
