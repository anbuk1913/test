import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, Alert, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { Header } from '../../components/Header';
import { PrimaryButton } from '../../components/PrimaryButton';
import { useBooking } from '../../context/BookingContext';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

export const BookingReviewScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const { draft, setInstructions, submitBooking, resetDraft } = useBooking();

  const [loading, setLoading] = useState(false);
  const [promoCode, setPromoCode] = useState('');
  const [discount, setDiscount] = useState(0);

  const primaryItem = draft.selectedService || draft.selectedPackage;
  const finalPrice = Math.max(0, draft.totalPrice - discount);

  const applyPromo = () => {
    if (promoCode.trim().toUpperCase() === 'WELCOME20') {
      const disc = draft.totalPrice * 0.2;
      setDiscount(disc);
      Alert.alert('Promo Applied!', `You saved $${disc.toFixed(2)} with WELCOME20.`);
    } else {
      Alert.alert('Invalid Code', 'The promo code entered is invalid or expired.');
    }
  };

  const handleConfirm = async () => {
    setLoading(true);
    try {
      const res = await submitBooking();
      resetDraft();
      navigation.reset({
        index: 0,
        routes: [
          {
            name: 'BookingConfirmed',
            params: { booking: res || { bookingCode: 'SH-' + Math.floor(1000 + Math.random() * 9000) } },
          },
        ],
      });
    } catch (err: any) {
      Alert.alert('Booking Error', err?.message || 'Failed to complete appointment booking.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Header title="Review Appointment - Step 3 of 3" onBack={() => navigation.goBack()} />

      <ScrollView contentContainerStyle={styles.content}>
        {/* Step Indicator */}
        <View style={styles.stepper}>
          <View style={styles.stepDot} />
          <View style={styles.stepLine} />
          <View style={styles.stepDot} />
          <View style={styles.stepLine} />
          <View style={[styles.stepDot, styles.activeStepDot]} />
        </View>

        {/* Pet & Appointment Info Card */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Ionicons name="paw" size={20} color={Colors.primary} />
            <Text style={[Typography.title, styles.cardTitle]}>Pet & Schedule Details</Text>
          </View>

          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Pet</Text>
            <Text style={styles.detailValue}>
              {draft.pet?.petName} ({draft.pet?.breed || 'Pet'})
            </Text>
          </View>

          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Date</Text>
            <Text style={styles.detailValue}>
              {draft.bookingDate ? new Date(draft.bookingDate).toDateString() : ''}
            </Text>
          </View>

          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Time Slot</Text>
            <Text style={styles.detailValue}>{draft.slot?.time}</Text>
          </View>

          <View style={styles.detailRow}>
            <Text style={styles.detailLabel}>Groomer</Text>
            <Text style={styles.detailValue}>
              {draft.groomer ? draft.groomer.name : 'First Available Groomer'}
            </Text>
          </View>
        </View>

        {/* Selected Treatments */}
        <View style={styles.card}>
          <View style={styles.cardHeader}>
            <Ionicons name="cut-outline" size={20} color={Colors.primary} />
            <Text style={[Typography.title, styles.cardTitle]}>Services Breakdown</Text>
          </View>

          <View style={styles.priceRow}>
            <Text style={styles.priceLabel}>{primaryItem?.name || 'Grooming Service'}</Text>
            <Text style={styles.priceValue}>${(primaryItem?.price || 0).toFixed(2)}</Text>
          </View>

          {draft.addOns.map((add) => (
            <View key={add.id} style={styles.priceRow}>
              <Text style={styles.priceLabel}>+ {add.name}</Text>
              <Text style={styles.priceValue}>${add.price.toFixed(2)}</Text>
            </View>
          ))}

          {discount > 0 && (
            <View style={styles.priceRow}>
              <Text style={[styles.priceLabel, { color: Colors.success }]}>Promo Discount</Text>
              <Text style={[styles.priceValue, { color: Colors.success }]}>
                -${discount.toFixed(2)}
              </Text>
            </View>
          )}

          <View style={styles.divider} />

          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>Total Estimated Price</Text>
            <Text style={styles.totalValue}>${finalPrice.toFixed(2)}</Text>
          </View>
        </View>

        {/* Promo Code Input */}
        <View style={styles.card}>
          <Text style={[Typography.title, styles.cardTitle, { marginBottom: Spacing.sm }]}>
            Promo Code
          </Text>
          <View style={styles.promoInputRow}>
            <TextInput
              placeholder="e.g. WELCOME20"
              placeholderTextColor={Colors.placeholder}
              value={promoCode}
              onChangeText={setPromoCode}
              autoCapitalize="characters"
              style={styles.promoInput}
            />
            <TouchableOpacity onPress={applyPromo} style={styles.applyBtn}>
              <Text style={styles.applyBtnText}>Apply</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Care Instructions Note */}
        <View style={styles.card}>
          <Text style={[Typography.title, styles.cardTitle, { marginBottom: Spacing.xs }]}>
            Special Care / Behavioral Notes
          </Text>
          <Text style={styles.noteSubtitle}>
            Any allergies, sensitive skin, or behavioral notes for our staff?
          </Text>
          <TextInput
            placeholder="e.g. Sensitive ears, nervous around blow dryer..."
            placeholderTextColor={Colors.placeholder}
            value={draft.instructions}
            onChangeText={setInstructions}
            multiline
            numberOfLines={3}
            style={styles.noteInput}
          />
        </View>
      </ScrollView>

      {/* Floating Confirm Button */}
      <View style={styles.bottomBar}>
        <View>
          <Text style={styles.bottomTotalLabel}>Total Due</Text>
          <Text style={styles.bottomTotalValue}>${finalPrice.toFixed(2)}</Text>
        </View>
        <PrimaryButton
          title="Confirm & Book Now"
          onPress={handleConfirm}
          loading={loading}
          style={styles.confirmBtn}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.surface,
  },
  content: {
    padding: Spacing.lg,
    paddingBottom: 110,
    gap: Spacing.md,
  },
  stepper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.sm,
  },
  stepDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: Colors.disabled,
  },
  activeStepDot: {
    backgroundColor: Colors.primary,
    width: 14,
    height: 14,
    borderRadius: 7,
  },
  stepLine: {
    width: 40,
    height: 2,
    backgroundColor: Colors.border,
    marginHorizontal: 4,
  },
  card: {
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    marginBottom: Spacing.md,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '700',
  },
  detailRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
  },
  detailLabel: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  detailValue: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  priceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 4,
  },
  priceLabel: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  priceValue: {
    fontSize: 14,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  divider: {
    height: 1,
    backgroundColor: Colors.border,
    marginVertical: Spacing.md,
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  totalLabel: {
    fontSize: 15,
    fontWeight: '700',
  },
  totalValue: {
    fontSize: 18,
    fontWeight: '800',
    color: Colors.primary,
  },
  promoInputRow: {
    flexDirection: 'row',
    gap: Spacing.sm,
  },
  promoInput: {
    flex: 1,
    height: 46,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: BorderRadius.md,
    paddingHorizontal: Spacing.md,
    fontSize: 14,
    backgroundColor: Colors.surface,
  },
  applyBtn: {
    backgroundColor: Colors.primary,
    paddingHorizontal: Spacing.xl,
    justifyContent: 'center',
    borderRadius: BorderRadius.md,
  },
  applyBtnText: {
    color: Colors.white,
    fontWeight: '600',
    fontSize: 14,
  },
  noteSubtitle: {
    fontSize: 12,
    color: Colors.textSecondary,
    marginBottom: Spacing.sm,
  },
  noteInput: {
    backgroundColor: Colors.surface,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: BorderRadius.md,
    padding: Spacing.md,
    fontSize: 14,
    height: 80,
    textAlignVertical: 'top',
  },
  bottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 84,
    backgroundColor: Colors.white,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.xl,
    borderTopWidth: 1,
    borderTopColor: Colors.border,
    elevation: 8,
  },
  bottomTotalLabel: {
    fontSize: 12,
    color: Colors.textSecondary,
  },
  bottomTotalValue: {
    fontSize: 20,
    fontWeight: '800',
    color: Colors.primary,
  },
  confirmBtn: {
    paddingHorizontal: Spacing.xl,
    height: 48,
  },
});
