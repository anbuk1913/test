import React from 'react';
import { View, Text, StyleSheet, ScrollView, Alert } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { PrimaryButton } from '../../components/PrimaryButton';
import { Colors, BorderRadius, Spacing, Typography } from '../../constants/theme';

export const BookingConfirmedScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const booking = route.params?.booking || {
    bookingCode: 'SH-8492',
    bookingDate: new Date().toISOString(),
    startTime: '10:00 AM',
    totalPrice: 65,
  };

  const handleAddToCalendar = () => {
    Alert.alert('Added to Calendar', 'Appointment has been saved to your device calendar.');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.successCircle}>
        <Ionicons name="checkmark-sharp" size={48} color={Colors.white} />
      </View>

      <Text style={[Typography.header1, styles.title]}>Booking Confirmed!</Text>
      <Text style={styles.subtitle}>
        We look forward to pampering your pet at Shear Heaven Pet Spa.
      </Text>

      {/* Confirmation Card */}
      <View style={styles.card}>
        <View style={styles.codeRow}>
          <Text style={styles.codeLabel}>Appointment Code</Text>
          <Text style={styles.codeVal}>{booking.bookingCode || 'SH-8492'}</Text>
        </View>

        <View style={styles.divider} />

        <View style={styles.infoRow}>
          <Ionicons name="calendar-outline" size={18} color={Colors.primary} />
          <Text style={styles.infoText}>
            {booking.bookingDate ? new Date(booking.bookingDate).toDateString() : 'Confirmed Date'}
          </Text>
        </View>

        <View style={styles.infoRow}>
          <Ionicons name="time-outline" size={18} color={Colors.primary} />
          <Text style={styles.infoText}>{booking.startTime || 'Scheduled Time'}</Text>
        </View>

        <View style={styles.infoRow}>
          <Ionicons name="location-outline" size={18} color={Colors.primary} />
          <Text style={styles.infoText}>123 Meadow Lane, Arlington, TX 76010</Text>
        </View>
      </View>

      {/* Actions */}
      <View style={styles.actions}>
        <PrimaryButton
          title="Add to Device Calendar"
          variant="outline"
          onPress={handleAddToCalendar}
          icon={<Ionicons name="calendar-outline" size={18} color={Colors.primary} style={{ marginRight: 6 }} />}
        />

        <PrimaryButton
          title="View My Bookings"
          onPress={() => {
            navigation.reset({
              index: 0,
              routes: [{ name: 'MainTabs', state: { routes: [{ name: 'MyBookings' }] } }],
            });
          }}
        />

        <PrimaryButton
          title="Return to Home"
          variant="ghost"
          onPress={() => navigation.reset({ index: 0, routes: [{ name: 'MainTabs' }] })}
        />
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    padding: Spacing.xl,
    flexGrow: 1,
    backgroundColor: Colors.white,
    alignItems: 'center',
    justifyContent: 'center',
  },
  successCircle: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: Colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.lg,
    elevation: 4,
  },
  title: {
    fontSize: 26,
    marginBottom: Spacing.xs,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 14,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: Spacing.xl,
    paddingHorizontal: Spacing.md,
  },
  card: {
    width: '100%',
    backgroundColor: Colors.surface,
    borderRadius: BorderRadius.lg,
    padding: Spacing.lg,
    borderWidth: 1,
    borderColor: Colors.border,
    marginBottom: Spacing.xxl,
  },
  codeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  codeLabel: {
    fontSize: 13,
    color: Colors.textSecondary,
  },
  codeVal: {
    fontSize: 16,
    fontWeight: '800',
    color: Colors.primary,
  },
  divider: {
    height: 1,
    backgroundColor: Colors.border,
    marginVertical: Spacing.md,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.sm,
    paddingVertical: 4,
  },
  infoText: {
    fontSize: 14,
    color: Colors.textPrimary,
  },
  actions: {
    width: '100%',
    gap: Spacing.md,
  },
});
