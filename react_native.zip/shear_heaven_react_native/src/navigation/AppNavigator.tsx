import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { RootStackParamList } from './types';
import { MainTabNavigator } from './MainTabNavigator';

// Auth Screens
import { SplashScreen } from '../screens/auth/SplashScreen';
import { WelcomeScreen } from '../screens/auth/WelcomeScreen';
import { OnboardingScreen } from '../screens/auth/OnboardingScreen';
import { LoginScreen } from '../screens/auth/LoginScreen';
import { SignupScreen } from '../screens/auth/SignupScreen';
import { OtpScreen } from '../screens/auth/OtpScreen';
import { ForgotPasswordScreen } from '../screens/auth/ForgotPasswordScreen';
import { AccountCreatedScreen } from '../screens/auth/AccountCreatedScreen';

// Services Screens
import { ServiceDetailScreen, PackageDetailScreen } from '../screens/services/ServiceDetailScreen';
import { PackagesScreen } from '../screens/services/PackagesScreen';

// Booking Screens
import { BookingServiceScreen } from '../screens/bookings/BookingServiceScreen';
import { BookingDateTimeScreen } from '../screens/bookings/BookingDateTimeScreen';
import { BookingReviewScreen } from '../screens/bookings/BookingReviewScreen';
import { BookingConfirmedScreen } from '../screens/bookings/BookingConfirmedScreen';
import { BookingDetailsScreen } from '../screens/bookings/BookingDetailsScreen';

// Pet Screens
import { MyPetsScreen } from '../screens/pets/MyPetsScreen';
import { CreatePetScreen, PetSelectScreen } from '../screens/pets/CreatePetScreen';

// Settings & CMS Screens
import { ProfileScreen } from '../screens/settings/ProfileScreen';
import { NotificationsScreen } from '../screens/settings/NotificationsScreen';
import { OffersScreen } from '../screens/home/OffersScreen';
import { GalleryScreen } from '../screens/home/GalleryScreen';
import {
  AboutUsScreen,
  HelpSupportScreen,
  PrivacyPolicyScreen,
  TermsConditionScreen,
} from '../screens/settings/ContentScreens';

// Groomer Screens
import { GroomerLoginScreen } from '../screens/groomer/GroomerLoginScreen';
import { GroomerRegisterScreen } from '../screens/groomer/GroomerRegisterScreen';
import { GroomerHomeScreen } from '../screens/groomer/GroomerHomeScreen';

const Stack = createNativeStackNavigator<RootStackParamList>();

export const AppNavigator: React.FC = () => {
  return (
    <Stack.Navigator
      initialRouteName="Splash"
      screenOptions={{
        headerShown: false,
        animation: 'slide_from_right',
      }}
    >
      {/* Auth */}
      <Stack.Screen name="Splash" component={SplashScreen} />
      <Stack.Screen name="Welcome" component={WelcomeScreen} />
      <Stack.Screen name="Onboarding" component={OnboardingScreen} />
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Signup" component={SignupScreen} />
      <Stack.Screen name="Otp" component={OtpScreen} />
      <Stack.Screen name="ForgotPassword" component={ForgotPasswordScreen} />
      <Stack.Screen name="AccountCreated" component={AccountCreatedScreen} />

      {/* Main Tabs */}
      <Stack.Screen name="MainTabs" component={MainTabNavigator} />

      {/* Services & Packages */}
      <Stack.Screen name="ServiceDetail" component={ServiceDetailScreen} />
      <Stack.Screen name="Packages" component={PackagesScreen} />
      <Stack.Screen name="PackageDetail" component={PackageDetailScreen} />

      {/* Booking Flow */}
      <Stack.Screen name="BookingService" component={BookingServiceScreen} />
      <Stack.Screen name="BookingDateTime" component={BookingDateTimeScreen} />
      <Stack.Screen name="BookingReview" component={BookingReviewScreen} />
      <Stack.Screen name="BookingConfirmed" component={BookingConfirmedScreen} />
      <Stack.Screen name="BookingDetails" component={BookingDetailsScreen} />

      {/* Pets */}
      <Stack.Screen name="MyPets" component={MyPetsScreen} />
      <Stack.Screen name="CreatePet" component={CreatePetScreen} />
      <Stack.Screen name="PetSelect" component={PetSelectScreen} />

      {/* Settings & Extra Pages */}
      <Stack.Screen name="Profile" component={ProfileScreen} />
      <Stack.Screen name="Notifications" component={NotificationsScreen} />
      <Stack.Screen name="Offers" component={OffersScreen} />
      <Stack.Screen name="Gallery" component={GalleryScreen} />
      <Stack.Screen name="AboutUs" component={AboutUsScreen} />
      <Stack.Screen name="HelpSupport" component={HelpSupportScreen} />
      <Stack.Screen name="PrivacyPolicy" component={PrivacyPolicyScreen} />
      <Stack.Screen name="TermsCondition" component={TermsConditionScreen} />

      {/* Groomer Portal */}
      <Stack.Screen name="GroomerLogin" component={GroomerLoginScreen} />
      <Stack.Screen name="GroomerRegister" component={GroomerRegisterScreen} />
      <Stack.Screen name="GroomerHome" component={GroomerHomeScreen} />
    </Stack.Navigator>
  );
};
