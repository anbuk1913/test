import { Pet } from '../models/pet';
import { ServiceItem } from '../models/service';
import { Booking } from '../models/booking';

export type RootStackParamList = {
  Splash: undefined;
  Welcome: undefined;
  Onboarding: undefined;
  Login: undefined;
  Signup: undefined;
  Otp: { email: string };
  ForgotPassword: undefined;
  AccountCreated: undefined;
  MainTabs: { screen?: string } | undefined;
  ServiceDetail: { service: ServiceItem };
  Packages: undefined;
  PackageDetail: { package: ServiceItem };
  PetSelect: undefined;
  MyPets: undefined;
  CreatePet: { pet?: Pet } | undefined;
  BookingService: undefined;
  BookingDateTime: undefined;
  BookingReview: undefined;
  BookingConfirmed: { booking?: Partial<Booking> } | undefined;
  BookingDetails: { booking: Booking };
  Profile: undefined;
  Notifications: undefined;
  Offers: undefined;
  Gallery: undefined;
  AboutUs: undefined;
  HelpSupport: undefined;
  PrivacyPolicy: undefined;
  TermsCondition: undefined;
  GroomerLogin: undefined;
  GroomerRegister: { tempLoginId?: string; tempPassword?: string } | undefined;
  GroomerHome: undefined;
};

export type MainTabParamList = {
  Home: undefined;
  Services: undefined;
  Chat: undefined;
  MyBookings: undefined;
  Settings: undefined;
};
