import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppConfig } from '../constants/config';
import { User, GroomerUser } from '../models/user';

class StorageService {
  async getAccessToken(): Promise<string | null> {
    return AsyncStorage.getItem(AppConfig.STORAGE_KEYS.ACCESS_TOKEN);
  }

  async getRefreshToken(): Promise<string | null> {
    return AsyncStorage.getItem(AppConfig.STORAGE_KEYS.REFRESH_TOKEN);
  }

  async saveTokens(accessToken: string, refreshToken: string): Promise<void> {
    await AsyncStorage.multiSet([
      [AppConfig.STORAGE_KEYS.ACCESS_TOKEN, accessToken],
      [AppConfig.STORAGE_KEYS.REFRESH_TOKEN, refreshToken],
    ]);
  }

  async clearTokens(): Promise<void> {
    await AsyncStorage.multiRemove([
      AppConfig.STORAGE_KEYS.ACCESS_TOKEN,
      AppConfig.STORAGE_KEYS.REFRESH_TOKEN,
    ]);
  }

  async getCustomerUser(): Promise<User | null> {
    const raw = await AsyncStorage.getItem(AppConfig.STORAGE_KEYS.CUSTOMER_USER);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as User;
    } catch {
      return null;
    }
  }

  async saveCustomerUser(user: User): Promise<void> {
    await AsyncStorage.setItem(AppConfig.STORAGE_KEYS.CUSTOMER_USER, JSON.stringify(user));
  }

  async getGroomerUser(): Promise<GroomerUser | null> {
    const raw = await AsyncStorage.getItem(AppConfig.STORAGE_KEYS.GROOMER_USER);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as GroomerUser;
    } catch {
      return null;
    }
  }

  async saveGroomerUser(user: GroomerUser): Promise<void> {
    await AsyncStorage.setItem(AppConfig.STORAGE_KEYS.GROOMER_USER, JSON.stringify(user));
  }

  async isGroomerRole(): Promise<boolean> {
    const val = await AsyncStorage.getItem(AppConfig.STORAGE_KEYS.IS_GROOMER);
    return val === 'true';
  }

  async setIsGroomerRole(isGroomer: boolean): Promise<void> {
    await AsyncStorage.setItem(AppConfig.STORAGE_KEYS.IS_GROOMER, isGroomer ? 'true' : 'false');
  }

  async getDeviceId(): Promise<string> {
    let id = await AsyncStorage.getItem(AppConfig.STORAGE_KEYS.DEVICE_ID);
    if (!id) {
      id = 'device_' + Math.random().toString(36).substring(2, 12) + Date.now().toString(36);
      await AsyncStorage.setItem(AppConfig.STORAGE_KEYS.DEVICE_ID, id);
    }
    return id;
  }

  async getPendingEmail(): Promise<string | null> {
    return AsyncStorage.getItem(AppConfig.STORAGE_KEYS.PENDING_EMAIL);
  }

  async savePendingEmail(email: string): Promise<void> {
    await AsyncStorage.setItem(AppConfig.STORAGE_KEYS.PENDING_EMAIL, email.trim().toLowerCase());
  }

  async clearPendingEmail(): Promise<void> {
    await AsyncStorage.removeItem(AppConfig.STORAGE_KEYS.PENDING_EMAIL);
  }

  async clearAllSession(): Promise<void> {
    await AsyncStorage.multiRemove([
      AppConfig.STORAGE_KEYS.ACCESS_TOKEN,
      AppConfig.STORAGE_KEYS.REFRESH_TOKEN,
      AppConfig.STORAGE_KEYS.CUSTOMER_USER,
      AppConfig.STORAGE_KEYS.GROOMER_USER,
      AppConfig.STORAGE_KEYS.IS_GROOMER,
      AppConfig.STORAGE_KEYS.PENDING_EMAIL,
    ]);
  }
}

export const storageService = new StorageService();
