import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, GroomerUser } from '../models/user';
import { authRepository } from '../repositories/authRepository';
import { storageService } from '../services/storageService';

interface AuthContextType {
  user: User | null;
  groomer: GroomerUser | null;
  isGroomer: boolean;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, pass: string) => Promise<{ userType: 'customer' | 'groomer'; mustChangePassword?: boolean }>;
  register: (data: { name: string; email: string; phone: string; password: string }) => Promise<void>;
  sendOtp: (email: string) => Promise<void>;
  verifyOtp: (code: string) => Promise<User>;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [groomer, setGroomer] = useState<GroomerUser | null>(null);
  const [isGroomer, setIsGroomer] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    checkSession();
  }, []);

  const checkSession = async () => {
    try {
      const token = await storageService.getAccessToken();
      const roleIsGroomer = await storageService.isGroomerRole();
      setIsGroomer(roleIsGroomer);

      if (token) {
        if (roleIsGroomer) {
          const savedGroomer = await storageService.getGroomerUser();
          setGroomer(savedGroomer);
        } else {
          const savedUser = await storageService.getCustomerUser();
          setUser(savedUser);
        }
      }
    } catch {
      // Session restore fallback
    } finally {
      setIsLoading(false);
    }
  };

  const login = async (
    email: string,
    pass: string
  ): Promise<{ userType: 'customer' | 'groomer'; mustChangePassword?: boolean }> => {
    const res = await authRepository.login(email, pass);
    if (res.userType === 'groomer') {
      setIsGroomer(true);
      setGroomer(res.groomer);
      setUser(null);
      return { userType: 'groomer', mustChangePassword: res.mustChangePassword };
    } else {
      setIsGroomer(false);
      setUser(res.user);
      setGroomer(null);
      return { userType: 'customer' };
    }
  };

  const register = async (data: { name: string; email: string; phone: string; password: string }) => {
    await authRepository.register(data);
  };

  const sendOtp = async (email: string) => {
    await authRepository.sendOtp(email);
  };

  const verifyOtp = async (code: string): Promise<User> => {
    const u = await authRepository.verifyOtp(code);
    setUser(u);
    setIsGroomer(false);
    return u;
  };

  const logout = async () => {
    await authRepository.logout();
    setUser(null);
    setGroomer(null);
    setIsGroomer(false);
  };

  const refreshProfile = async () => {
    if (isGroomer) {
      // Groomer profile refresh
    } else {
      const u = await authRepository.getProfile();
      setUser(u);
    }
  };

  const isAuthenticated = Boolean(isGroomer ? groomer : user);

  return (
    <AuthContext.Provider
      value={{
        user,
        groomer,
        isGroomer,
        isLoading,
        isAuthenticated,
        login,
        register,
        sendOtp,
        verifyOtp,
        logout,
        refreshProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
