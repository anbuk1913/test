import React, { createContext, useContext, useState } from 'react';
import { Pet } from '../models/pet';
import { ServiceItem } from '../models/service';
import { BookingGroomer, BookingSlot } from '../models/booking';
import { bookingRepository } from '../repositories/bookingRepository';

interface BookingDraftState {
  pet: Pet | null;
  selectedService: ServiceItem | null;
  selectedPackage: ServiceItem | null;
  addOns: ServiceItem[];
  bookingDate: string;
  slot: BookingSlot | null;
  groomer: BookingGroomer | null;
  instructions: string;
  totalPrice: number;
  totalDurationMinutes: number;
}

interface BookingContextType {
  draft: BookingDraftState;
  setPet: (pet: Pet | null) => void;
  selectService: (service: ServiceItem | null) => void;
  selectPackage: (pkg: ServiceItem | null) => void;
  toggleAddOn: (addOn: ServiceItem) => void;
  setBookingDate: (date: string) => void;
  setSlot: (slot: BookingSlot | null) => void;
  setGroomer: (groomer: BookingGroomer | null) => void;
  setInstructions: (text: string) => void;
  calculatePricingAndDuration: () => Promise<void>;
  submitBooking: () => Promise<any>;
  resetDraft: () => void;
}

const initialDraft: BookingDraftState = {
  pet: null,
  selectedService: null,
  selectedPackage: null,
  addOns: [],
  bookingDate: '',
  slot: null,
  groomer: null,
  instructions: '',
  totalPrice: 0,
  totalDurationMinutes: 0,
};

const BookingContext = createContext<BookingContextType>({} as BookingContextType);

export const BookingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [draft, setDraft] = useState<BookingDraftState>(initialDraft);

  const setPet = (pet: Pet | null) => setDraft((prev) => ({ ...prev, pet }));

  const selectService = (service: ServiceItem | null) => {
    setDraft((prev) => {
      const basePrice = service ? service.price : 0;
      const baseDuration = service ? service.durationMinutes : 0;
      const addOnsPrice = prev.addOns.reduce((sum, a) => sum + a.price, 0);
      const addOnsDuration = prev.addOns.reduce((sum, a) => sum + a.durationMinutes, 0);

      return {
        ...prev,
        selectedService: service,
        selectedPackage: null, // Only one primary service/package
        totalPrice: basePrice + addOnsPrice,
        totalDurationMinutes: baseDuration + addOnsDuration,
      };
    });
  };

  const selectPackage = (pkg: ServiceItem | null) => {
    setDraft((prev) => {
      const basePrice = pkg ? pkg.price : 0;
      const baseDuration = pkg ? pkg.durationMinutes : 0;
      const addOnsPrice = prev.addOns.reduce((sum, a) => sum + a.price, 0);
      const addOnsDuration = prev.addOns.reduce((sum, a) => sum + a.durationMinutes, 0);

      return {
        ...prev,
        selectedPackage: pkg,
        selectedService: null,
        totalPrice: basePrice + addOnsPrice,
        totalDurationMinutes: baseDuration + addOnsDuration,
      };
    });
  };

  const toggleAddOn = (addOn: ServiceItem) => {
    setDraft((prev) => {
      const exists = prev.addOns.some((a) => a.id === addOn.id);
      const newAddOns = exists
        ? prev.addOns.filter((a) => a.id !== addOn.id)
        : [...prev.addOns, addOn];

      const basePrice = prev.selectedService?.price || prev.selectedPackage?.price || 0;
      const baseDuration = prev.selectedService?.durationMinutes || prev.selectedPackage?.durationMinutes || 0;
      const addOnsPrice = newAddOns.reduce((sum, a) => sum + a.price, 0);
      const addOnsDuration = newAddOns.reduce((sum, a) => sum + a.durationMinutes, 0);

      return {
        ...prev,
        addOns: newAddOns,
        totalPrice: basePrice + addOnsPrice,
        totalDurationMinutes: baseDuration + addOnsDuration,
      };
    });
  };

  const setBookingDate = (date: string) => setDraft((prev) => ({ ...prev, bookingDate: date, slot: null }));

  const setSlot = (slot: BookingSlot | null) => setDraft((prev) => ({ ...prev, slot }));

  const setGroomer = (groomer: BookingGroomer | null) => setDraft((prev) => ({ ...prev, groomer, slot: null }));

  const setInstructions = (instructions: string) => setDraft((prev) => ({ ...prev, instructions }));

  const calculatePricingAndDuration = async () => {
    if (!draft.bookingDate) return;
    try {
      const res = await bookingRepository.getAvailability({
        date: draft.bookingDate,
        serviceId: draft.selectedService?.id,
        packageId: draft.selectedPackage?.id,
        addOnIds: draft.addOns.map((a) => a.id),
        groomerId: draft.groomer?.id,
      });

      if (res) {
        setDraft((prev) => ({
          ...prev,
          totalPrice: res.totalPrice ?? prev.totalPrice,
          totalDurationMinutes: res.totalDurationMinutes ?? prev.totalDurationMinutes,
        }));
      }
    } catch {
      // Retain local client calculation
    }
  };

  const submitBooking = async () => {
    if (!draft.pet || !draft.bookingDate || !draft.slot) {
      throw new Error('Please complete all booking selections.');
    }

    const payload = {
      ClientId: 'SHEAR-001',
      RegionId: 'DWG-001',
      StoreId: 'SHEAR-001',
      petId: draft.pet.id,
      serviceId: draft.selectedService?.id,
      packageId: draft.selectedPackage?.id,
      addOnIds: draft.addOns.map((a) => a.id),
      groomerId: draft.groomer?.id || 0,
      bookingDate: draft.bookingDate,
      startTime: draft.slot.startTime || draft.slot.time,
      endTime: draft.slot.endTime,
      notes: draft.instructions,
    };

    const res = await bookingRepository.createBooking(payload);
    return res;
  };

  const resetDraft = () => setDraft(initialDraft);

  return (
    <BookingContext.Provider
      value={{
        draft,
        setPet,
        selectService,
        selectPackage,
        toggleAddOn,
        setBookingDate,
        setSlot,
        setGroomer,
        setInstructions,
        calculatePricingAndDuration,
        submitBooking,
        resetDraft,
      }}
    >
      {children}
    </BookingContext.Provider>
  );
};

export const useBooking = () => useContext(BookingContext);
