export const DateUtils = {
  formatDate: (date: Date | string): string => {
    const d = typeof date === 'string' ? new Date(date) : date;
    return d.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  },

  formatTime: (timeString: string): string => {
    return timeString;
  },

  isSunday: (date: Date): boolean => {
    return date.getDay() === 0;
  },

  isValidAdvanceDate: (date: Date): boolean => {
    const now = new Date();
    const diff = (date.getTime() - now.getTime()) / (1000 * 60 * 60 * 24);
    return diff >= 0 && diff <= 14;
  },
};
