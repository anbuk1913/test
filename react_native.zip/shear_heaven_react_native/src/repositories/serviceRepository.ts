import { api } from '../api/apiClient';
import { AppConfig } from '../constants/config';
import { BookingServicesResult, ServiceItem } from '../models/service';

export class ServiceRepository {
  private static parseDouble(v: any): number {
    if (v == null) return 0;
    if (typeof v === 'number') return v;
    const s = String(v).replace(/[^0-9.]/g, '');
    const num = parseFloat(s);
    return isNaN(num) ? 0 : num;
  }

  private static priceDisplay(rawPrice: any): string {
    if (rawPrice == null) return '';
    const s = String(rawPrice).trim();
    if (s === '' || s === '0' || s === '0.0') return '';
    if (s.startsWith('$')) return s;
    const num = ServiceRepository.parseDouble(s);
    return num > 0 ? `$${num.toFixed(2)}` : '';
  }

  static resolveImageUrl(rawUrl?: string | null): string | undefined {
    if (!rawUrl) return undefined;
    const s = String(rawUrl).trim();
    if (!s || s === 'null' || s === 'undefined') return undefined;

    if (s.startsWith('http://') || s.startsWith('https://')) {
      return s;
    }

    const clean = s.startsWith('/') ? s : `/${s}`;
    return `${AppConfig.BASE_URL}${clean}`;
  }

  async getBookingServices(): Promise<BookingServicesResult> {
    try {
      const res = await api.get('/api/service-packages');
      const data = res?.data || res || {};

      const parseItems = (rawList: any[], isPackage: boolean, isAddOn: boolean): ServiceItem[] => {
        if (!Array.isArray(rawList)) return [];
        return rawList.map((item, idx) => {
          const id = item.id || item.serviceId || item.packageId || idx + 1;
          const price = ServiceRepository.parseDouble(item.price || item.estimatedPrice || item.rate);
          const priceDisplay = ServiceRepository.priceDisplay(item.price || item.estimatedPrice) || `$${price.toFixed(2)}`;
          const durationMinutes = parseInt(String(item.durationMinutes || item.duration_min || item.duration || 60), 10) || 60;

          return {
            id,
            isPackage,
            isAddOn,
            name: item.name || item.service_name || item.packageName || item.title || 'Service',
            description: item.description || item.short_description || '',
            price,
            priceDisplay,
            durationMinutes,
            imageUrl: ServiceRepository.resolveImageUrl(item.imageUrl || item.image_url || item.photoUrl),
            includes: Array.isArray(item.includes) ? item.includes : [],
            code: item.code || item.package_id,
            category: item.category,
          };
        });
      };

      const breeds = parseItems(data.breeds || data.services || [], false, false);
      const packages = parseItems(data.packages || [], true, false);
      const addOns = parseItems(data.addOns || data.addons || [], false, true);
      const walkIn = parseItems(data.walkIn || data.walkInServices || [], false, false);

      if (breeds.length === 0 && packages.length === 0) {
        return this.getFallbackServices();
      }

      return { breeds, packages, addOns, walkIn };
    } catch {
      return this.getFallbackServices();
    }
  }

  getFallbackServices(): BookingServicesResult {
    return {
      breeds: [
        {
          id: 1,
          isPackage: false,
          isAddOn: false,
          name: 'Full Grooming',
          description: 'Bath, brush out, haircut/styling, ear cleaning, and nail trim.',
          price: 65,
          priceDisplay: '$65.00',
          durationMinutes: 90,
          imageUrl: undefined,
          includes: ['Bath & Blow Dry', 'Haircut Styling', 'Ear Cleaning', 'Nail Trim'],
        },
        {
          id: 2,
          isPackage: false,
          isAddOn: false,
          name: 'Bath & Brush Out',
          description: 'Deep cleansing shampoo, blow dry, thorough brush out, and ear care.',
          price: 45,
          priceDisplay: '$45.00',
          durationMinutes: 60,
          imageUrl: undefined,
          includes: ['Shampoo & Conditioner', 'Blow Dry', 'Brush Out', 'Ear Cleaning'],
        },
      ],
      packages: [
        {
          id: 101,
          isPackage: true,
          isAddOn: false,
          name: 'Spa Package',
          description: 'Full Service Pet Grooming with coat conditioning, nail buffing, and blueberry facial.',
          price: 85,
          priceDisplay: '$85.00',
          durationMinutes: 120,
          includes: ['Full Grooming', 'Deep Coat Conditioning', 'Nail Buffing', 'Blueberry Facial', 'Finishing Mist'],
        },
        {
          id: 102,
          isPackage: true,
          isAddOn: false,
          name: 'Deluxe Puppy Spa',
          description: 'Gentle intro styling, mild shampoo, gentle paw balm, and brush out.',
          price: 55,
          priceDisplay: '$55.00',
          durationMinutes: 60,
          includes: ['Puppy Friendly Bath', 'Gentle Brush Out', 'Sanitary Trim', 'Paw Balm'],
        },
      ],
      addOns: [
        {
          id: 201,
          isPackage: false,
          isAddOn: true,
          name: 'Teeth Brushing',
          description: 'Enzymatic toothpaste application and breath freshening.',
          price: 15,
          priceDisplay: '$15.00',
          durationMinutes: 15,
        },
        {
          id: 202,
          isPackage: false,
          isAddOn: true,
          name: 'De-Shedding Treatment',
          description: 'Undercoat removal shampoo and specialized blow out.',
          price: 25,
          priceDisplay: '$25.00',
          durationMinutes: 20,
        },
        {
          id: 203,
          isPackage: false,
          isAddOn: true,
          name: 'Flea & Tick Treatment',
          description: 'Medicated bath to eliminate fleas and ticks safely.',
          price: 20,
          priceDisplay: '$20.00',
          durationMinutes: 20,
        },
      ],
      walkIn: [
        {
          id: 301,
          isPackage: false,
          isAddOn: false,
          name: 'Nail Trim Only',
          description: 'Quick clipping and filing of nails.',
          price: 18,
          priceDisplay: '$18.00',
          durationMinutes: 15,
        },
      ],
    };
  }
}

export const serviceRepository = new ServiceRepository();
