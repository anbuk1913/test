import { api } from '../api/apiClient';
import { GroomerStaff, StoreHours, Holiday } from '../models/common';

export class StoreRepository {
  async getGroomers(): Promise<GroomerStaff[]> {
    try {
      const res = await api.get('/api/groomers');
      const list = Array.isArray(res.data) ? res.data : Array.isArray(res) ? res : [];
      return list.map((g: any, idx: number) => ({
        id: g.id || g.groomerId || idx + 1,
        name: g.name || g.groomerName || 'Staff Groomer',
        role: g.role || 'Professional Groomer',
        specialization: g.specialization || 'All Breeds',
        avatarUrl: g.avatar || g.avatarUrl || g.profilePictureUrl,
        isAvailable: g.isAvailable ?? true,
      }));
    } catch {
      return [
        { id: 1, name: 'Sarah Jenkins', role: 'Master Stylist', specialization: 'Large Breeds & Doodles', isAvailable: true },
        { id: 2, name: 'Michael Chen', role: 'Pet Groomer', specialization: 'Small Breeds & Cats', isAvailable: true },
        { id: 3, name: 'Emily Taylor', role: 'Gentle Care Specialist', specialization: 'Puppies & Senior Pets', isAvailable: true },
      ];
    }
  }

  async getStoreSchedule(): Promise<StoreHours[]> {
    try {
      const res = await api.get('/api/service-hours');
      const list = res.data?.schedule || res.data || res;
      if (Array.isArray(list)) {
        return list.map((item: any) => ({
          dayOfWeek: item.dayOfWeek || item.day || '',
          openTime: item.openTime || '09:00',
          closeTime: item.closeTime || '18:00',
          isClosed: item.isClosed || false,
        }));
      }
      return this.defaultSchedule();
    } catch {
      return this.defaultSchedule();
    }
  }

  async getHolidays(): Promise<Holiday[]> {
    try {
      const res = await api.get('/api/holidays');
      const list = res.data?.holidays || res.data || res;
      if (Array.isArray(list)) {
        return list.map((item: any, idx: number) => ({
          id: item.id || idx + 1,
          date: item.date || item.holidayDate,
          name: item.name || item.holidayName || 'Holiday',
          description: item.description,
        }));
      }
      return [];
    } catch {
      return [];
    }
  }

  async getPetWeights(): Promise<string[]> {
    try {
      const res = await api.get('/api/pet-weights');
      const list = res.data?.weights || res.data || res;
      if (Array.isArray(list)) {
        return list.map((item: any) => (typeof item === 'string' ? item : item.weight || item.name));
      }
      return ['0 - 15 lbs', '16 - 30 lbs', '31 - 60 lbs', '61 - 90 lbs', '90+ lbs'];
    } catch {
      return ['0 - 15 lbs', '16 - 30 lbs', '31 - 60 lbs', '61 - 90 lbs', '90+ lbs'];
    }
  }

  private defaultSchedule(): StoreHours[] {
    return [
      { dayOfWeek: 'Monday', openTime: '08:30', closeTime: '18:00', isClosed: false },
      { dayOfWeek: 'Tuesday', openTime: '08:30', closeTime: '18:00', isClosed: false },
      { dayOfWeek: 'Wednesday', openTime: '08:30', closeTime: '18:00', isClosed: false },
      { dayOfWeek: 'Thursday', openTime: '08:30', closeTime: '18:00', isClosed: false },
      { dayOfWeek: 'Friday', openTime: '08:30', closeTime: '18:00', isClosed: false },
      { dayOfWeek: 'Saturday', openTime: '09:00', closeTime: '17:00', isClosed: false },
      { dayOfWeek: 'Sunday', openTime: '10:00', closeTime: '16:00', isClosed: true },
    ];
  }
}

export const storeRepository = new StoreRepository();
