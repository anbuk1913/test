import { api } from '../api/apiClient';
import { Booking, CreateBookingPayload } from '../models/booking';

export class BookingRepository {
  private extractList(res: any): any[] {
    if (!res) return [];
    if (Array.isArray(res.data?.bookings)) return res.data.bookings;
    if (Array.isArray(res.data)) return res.data;
    if (Array.isArray(res.bookings)) return res.bookings;
    if (Array.isArray(res)) return res;
    return [];
  }

  private mapBooking(item: any): Booking {
    const id = item.id || item.bookingId || item._id;
    return {
      id,
      bookingId: id,
      bookingCode: item.bookingCode || `SH-${id}`,
      status: item.status || 'confirmed',
      bookingDate: item.bookingDate || item.date || '',
      startTime: item.startTime || item.slotTime || '',
      endTime: item.endTime || '',
      totalPrice: typeof item.totalPrice === 'number' ? item.totalPrice : parseFloat(item.totalPrice || '0') || 0,
      totalDurationMinutes: item.totalDurationMinutes || item.durationMinutes || 60,
      pet: item.pet || (item.petName ? { petName: item.petName, breed: item.petBreed, id: item.petId } : undefined),
      petName: item.petName || item.pet?.petName,
      petBreed: item.petBreed || item.pet?.breed,
      serviceName: item.serviceName || item.service?.name,
      packageName: item.packageName || item.package?.name,
      groomerName: item.groomerName || item.groomer?.name,
      instructions: item.instructions || item.notes,
      cancellationReason: item.cancellationReason,
      createdAt: item.createdAt,
    };
  }

  async getGroomerAvailability(params: {
    date: string;
    durationMinutes: number;
    groomerId?: number;
    groomerIds?: number[];
  }) {
    const query: Record<string, any> = {
      date: params.date,
      ClientID: 'SHEAR-001', // Postman-verified casing
      RegionId: 'DWG-001',
      StoreId: 'SHEAR-001',
      durationMinutes: params.durationMinutes,
    };

    if (params.groomerId && params.groomerId > 0) {
      query.groomerId = params.groomerId;
    } else if (params.groomerIds && params.groomerIds.length > 0) {
      query.groomerIds = params.groomerIds.join(',');
    }

    const res = await api.get('/api/groomer-availability', query);
    return res?.data || res;
  }

  async getAvailability(params: {
    date: string;
    serviceId?: number;
    packageId?: number;
    addOnIds?: number[];
    groomerId?: number;
  }) {
    const effectiveServiceId =
      params.serviceId && params.serviceId > 0
        ? params.serviceId
        : params.packageId && params.packageId > 0
        ? params.packageId
        : undefined;

    const payload: Record<string, any> = {
      ClientId: 'SHEAR-001',
      RegionId: 'DWG-001',
      StoreId: 'SHEAR-001',
      date: params.date,
    };

    if (effectiveServiceId) payload.serviceId = effectiveServiceId;
    if (params.packageId && params.packageId !== effectiveServiceId) {
      payload.packageId = params.packageId;
    }
    if (params.addOnIds && params.addOnIds.length > 0) payload.addOnIds = params.addOnIds;
    if (params.groomerId && params.groomerId > 0) payload.groomerId = params.groomerId;

    const res = await api.post('/api/availability', payload);
    return res?.data || res;
  }

  async createBooking(payload: CreateBookingPayload): Promise<Booking> {
    const res = await api.post('/api/bookings', payload);
    if (!res || res.success === false) {
      throw new Error(res?.message || 'Failed to create booking');
    }
    const data = res.data || res;
    return this.mapBooking(data);
  }

  async getUpcomingBookings(): Promise<Booking[]> {
    try {
      const res = await api.get('/api/bookings/upcoming');
      return this.extractList(res).map((item) => this.mapBooking(item));
    } catch {
      return [];
    }
  }

  async getPastBookings(): Promise<Booking[]> {
    try {
      const res = await api.get('/api/bookings/past');
      return this.extractList(res).map((item) => this.mapBooking(item));
    } catch {
      return [];
    }
  }

  async getCancelledBookings(): Promise<Booking[]> {
    try {
      const res = await api.get('/api/bookings/cancelled');
      return this.extractList(res).map((item) => this.mapBooking(item));
    } catch {
      return [];
    }
  }

  async cancelBooking(id: number | string): Promise<boolean> {
    const res = await api.post(`/api/bookings/${id}/cancel`, {});
    return res && res.success !== false;
  }
}

export const bookingRepository = new BookingRepository();
