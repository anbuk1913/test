import { api } from '../api/apiClient';
import { OfferModel, AppNotification } from '../models/common';

export class ContentRepository {
  async getStoreContactInfo() {
    try {
      const res = await api.get('/api/store/contact-info');
      return res.data || res;
    } catch {
      return {
        address: '123 Meadow Lane, Arlington, TX 76010',
        phone: '(817) 555-0199',
        email: 'support@shearheavenpetspa.com',
        hours: 'Mon-Sat: 8:30 AM - 6:00 PM',
      };
    }
  }

  async getAboutUs(): Promise<string> {
    try {
      const res = await api.get('/api/content/about-us');
      return res.data?.content || res.content || '';
    } catch {
      return 'Shear Heaven Pet Spa is Arlington’s premier luxury pet grooming facility, providing stress-free styling, coat therapy, and compassionate care for your furry family members.';
    }
  }

  async getHelpSupport(): Promise<{ faq: Array<{ q: string; a: string }> }> {
    try {
      const res = await api.get('/api/content/help-support');
      return res.data || res;
    } catch {
      return {
        faq: [
          { q: 'How early should I arrive?', a: 'Please arrive 10 minutes prior to your scheduled appointment time.' },
          { q: 'Are vaccinations required?', a: 'Yes, Rabies and DHPP/Bordetella vaccinations must be up to date.' },
          { q: 'Can I cancel or reschedule?', a: 'You may cancel or reschedule up to 24 hours prior without fee.' },
        ],
      };
    }
  }

  async getPrivacyPolicy(): Promise<string> {
    try {
      const res = await api.get('/api/content/privacy-policy');
      return res.data?.content || res.content || '';
    } catch {
      return 'We take your privacy seriously. All personal contact info, booking history, and pet records are securely encrypted and never sold to third parties.';
    }
  }

  async getTermsConditions(): Promise<string> {
    try {
      const res = await api.get('/api/content/terms-conditions');
      return res.data?.content || res.content || '';
    } catch {
      return 'By using Shear Heaven Pet Spa app, you agree to timely pick-ups and to disclose any pre-existing pet health or behavioral conditions.';
    }
  }
}

export class OfferRepository {
  async getOffers(): Promise<OfferModel[]> {
    try {
      const res = await api.get('/api/offers');
      const list = res.data?.offers || res.data || res;
      if (Array.isArray(list)) {
        return list.map((item: any, idx: number) => ({
          id: item.id || idx + 1,
          title: item.title || 'Special Promotion',
          description: item.description || '',
          code: item.code || 'SPA20',
          discountPercentage: item.discountPercentage || 20,
          discountAmount: item.discountAmount,
          validUntil: item.validUntil,
          bannerUrl: item.bannerUrl,
        }));
      }
      return this.defaultOffers();
    } catch {
      return this.defaultOffers();
    }
  }

  async validatePromo(code: string, amount: number) {
    const res = await api.post('/api/offers/validate-promo', { code, amount });
    return res.data || res;
  }

  private defaultOffers(): OfferModel[] {
    return [
      {
        id: 1,
        title: 'New Client Special',
        description: 'Get 20% off your pet’s first full grooming session.',
        code: 'WELCOME20',
        discountPercentage: 20,
      },
      {
        id: 2,
        title: 'Spa Day Bundle',
        description: 'Complimentary teeth brushing and blueberry facial with any Deluxe Package.',
        code: 'SPAPAMPER',
        discountAmount: 15,
      },
    ];
  }
}

export class NotificationRepository {
  async getNotifications(): Promise<AppNotification[]> {
    try {
      const res = await api.get('/api/notifications');
      const list = res.data?.notifications || res.data || res;
      if (Array.isArray(list)) {
        return list.map((item: any, idx: number) => ({
          id: item.id || idx + 1,
          title: item.title || 'Notification',
          message: item.message || '',
          type: item.type,
          isRead: item.isRead ?? false,
          createdAt: item.createdAt || new Date().toISOString(),
          data: item.data,
        }));
      }
      return [];
    } catch {
      return [];
    }
  }

  async markAsRead(id: string | number): Promise<boolean> {
    const res = await api.put(`/api/notifications/${id}/read`, {});
    return res && res.success !== false;
  }

  async markAllAsRead(): Promise<boolean> {
    const res = await api.put('/api/notifications/read-all', {});
    return res && res.success !== false;
  }

  async deleteNotification(id: string | number): Promise<boolean> {
    const res = await api.delete(`/api/notifications/${id}`);
    return res && res.success !== false;
  }
}

export const contentRepository = new ContentRepository();
export const offerRepository = new OfferRepository();
export const notificationRepository = new NotificationRepository();
