import { api } from '../api/apiClient';
import { Pet, CreatePetDTO } from '../models/pet';

export class PetRepository {
  private mapFromApi(raw: any): Pet {
    const p = raw.pet || raw;
    const photoUrl =
      p.profilePictureUrl ||
      p.profilePicture ||
      p.profile_picture ||
      p.photo_url ||
      p.photoUrl ||
      p.image ||
      p.avatar;

    return {
      id: p.id || p._id,
      _id: p._id,
      petName: p.petName || p.name || 'Unnamed Pet',
      name: p.petName || p.name,
      breed: p.breed || '',
      weight: p.weight || '',
      age: p.age ? String(p.age) : '',
      gender: p.gender || 'male',
      dateOfBirth: p.dateOfBirth || p.birthDate,
      birthDate: p.dateOfBirth || p.birthDate,
      notesAllergies: p.notesAllergies || p.notes || '',
      notes: p.notesAllergies || p.notes || '',
      behaviorNotes: p.behaviorNotes || '',
      allVaccinatedCurrent: p.allVaccinatedCurrent ?? true,
      lastVaccinatedDate: p.lastVaccinatedDate,
      profilePictureUrl: photoUrl,
      profilePicture: photoUrl,
      image: photoUrl,
    };
  }

  async getAllPets(): Promise<Pet[]> {
    try {
      const res = await api.get('/api/pets');
      if (!res) return [];

      let list: any[] = [];
      if (Array.isArray(res.data)) {
        list = res.data;
      } else if (res.data?.pets && Array.isArray(res.data.pets)) {
        list = res.data.pets;
      } else if (res.data?.pet && Array.isArray(res.data.pet)) {
        list = res.data.pet;
      } else if (Array.isArray(res.pets)) {
        list = res.pets;
      } else if (Array.isArray(res)) {
        list = res;
      }

      return list.map((item) => this.mapFromApi(item));
    } catch {
      return [];
    }
  }

  async getPetById(id: string | number): Promise<Pet | null> {
    const res = await api.get(`/api/pets/${id}`);
    if (!res) return null;
    return this.mapFromApi(res.data || res);
  }

  async createPet(dto: CreatePetDTO): Promise<Pet> {
    const formData = new FormData();
    formData.append('petName', dto.petName);
    if (dto.breed) formData.append('breed', dto.breed);
    if (dto.weight) formData.append('weight', dto.weight);
    if (dto.age) formData.append('age', dto.age);
    if (dto.gender) formData.append('gender', dto.gender);
    if (dto.notesAllergies) formData.append('notesAllergies', dto.notesAllergies);
    if (dto.behaviorNotes) formData.append('behaviorNotes', dto.behaviorNotes);
    if (dto.dateOfBirth) formData.append('dateOfBirth', dto.dateOfBirth);
    if (dto.lastVaccinatedDate) formData.append('lastVaccinatedDate', dto.lastVaccinatedDate);
    formData.append('allVaccinatedCurrent', String(dto.allVaccinatedCurrent ?? true));

    if (dto.photoUri) {
      const filename = dto.photoUri.split('/').pop() || 'photo.jpg';
      const match = /\.(\w+)$/.exec(filename);
      const type = match ? `image/${match[1]}` : 'image/jpeg';
      formData.append('profilePicture', {
        uri: dto.photoUri,
        name: filename,
        type,
      } as any);
    }

    const res = await api.postMultipart('/api/pets', formData);
    if (!res || res.success === false) {
      throw new Error(res?.message || 'Failed to create pet');
    }
    return this.mapFromApi(res.data || res);
  }

  async updatePet(id: string | number, dto: Partial<CreatePetDTO>): Promise<Pet> {
    const formData = new FormData();
    if (dto.petName) formData.append('petName', dto.petName);
    if (dto.breed) formData.append('breed', dto.breed);
    if (dto.weight) formData.append('weight', dto.weight);
    if (dto.age) formData.append('age', dto.age);
    if (dto.gender) formData.append('gender', dto.gender);
    if (dto.notesAllergies !== undefined) formData.append('notesAllergies', dto.notesAllergies);
    if (dto.behaviorNotes !== undefined) formData.append('behaviorNotes', dto.behaviorNotes);
    if (dto.dateOfBirth) formData.append('dateOfBirth', dto.dateOfBirth);
    if (dto.lastVaccinatedDate) formData.append('lastVaccinatedDate', dto.lastVaccinatedDate);
    if (dto.allVaccinatedCurrent !== undefined) {
      formData.append('allVaccinatedCurrent', String(dto.allVaccinatedCurrent));
    }

    if (dto.photoUri && !dto.photoUri.startsWith('http')) {
      const filename = dto.photoUri.split('/').pop() || 'photo.jpg';
      const match = /\.(\w+)$/.exec(filename);
      const type = match ? `image/${match[1]}` : 'image/jpeg';
      formData.append('profilePicture', {
        uri: dto.photoUri,
        name: filename,
        type,
      } as any);
    }

    const res = await api.putMultipart(`/api/pets/${id}`, formData);
    if (!res || res.success === false) {
      throw new Error(res?.message || 'Failed to update pet');
    }
    return this.mapFromApi(res.data || res);
  }

  async deletePet(id: string | number): Promise<boolean> {
    const res = await api.delete(`/api/pets/${id}`);
    return res && res.success !== false;
  }
}

export const petRepository = new PetRepository();
