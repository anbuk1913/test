import { api } from '../api/apiClient';
import { storageService } from '../services/storageService';
import { User, GroomerUser } from '../models/user';

export class AuthRepository {
  async register(data: { name: string; email: string; phone: string; password: string }) {
    const deviceId = await storageService.getDeviceId();
    const payload = {
      name: data.name,
      email: data.email.toLowerCase().trim(),
      mobile: data.phone.replace(/[^0-9]/g, ''),
      password: data.password,
      confirmPassword: data.password,
      deviceId,
      clientId: 'SHEAR-001',
      regionId: 'DWG-001',
      storeId: 'SHEAR-001',
    };

    const res = await api.post('/api/auth/signup', payload);
    if (!res || res.success === false) {
      const msg = res?.message || (Array.isArray(res?.errors) ? res.errors.join(', ') : 'Failed to register');
      throw new Error(msg);
    }

    await storageService.savePendingEmail(data.email);
    return { email: data.email, name: data.name };
  }

  async sendOtp(email: string) {
    const deviceId = await storageService.getDeviceId();
    const res = await api.post('/api/auth/send-otp', {
      email: email.toLowerCase().trim(),
      deviceId,
      clientId: 'SHEAR-001',
      regionId: 'DWG-001',
      storeId: 'SHEAR-001',
    });

    if (!res || res.success === false) {
      throw new Error(res?.message || 'Failed to send OTP');
    }

    await storageService.savePendingEmail(email);
    return true;
  }

  async verifyOtp(code: string) {
    const pendingEmail = await storageService.getPendingEmail();
    if (!pendingEmail) {
      throw new Error('No pending email found to verify');
    }

    const res = await api.post('/api/auth/verify-otp', {
      email: pendingEmail,
      otp: code,
    });

    if (!res || res.success === false) {
      throw new Error(res?.message || 'Invalid OTP');
    }

    const data = res.data || res;
    const accessToken = data.accessToken;
    const refreshToken = data.refreshToken;
    const user = data.user || data;

    if (accessToken && refreshToken) {
      await storageService.saveTokens(accessToken, refreshToken);
      await storageService.saveCustomerUser(user as User);
      await storageService.setIsGroomerRole(false);
      await storageService.clearPendingEmail();
    }

    return user as User;
  }

  async login(email: string, password: string) {
    const deviceId = await storageService.getDeviceId();
    const payload = {
      email: email.toLowerCase().trim(),
      password,
      deviceId,
    };

    const res = await api.post('/api/auth/login', payload);
    if (!res || res.success === false) {
      let errMsg = res?.message || 'Invalid email or password.';
      if (res?.code === 'DEVICE_LIMIT_REACHED' || errMsg.toLowerCase().includes('device')) {
        errMsg = 'Maximum registered device limit reached (5 devices). Please log out from another device.';
      }
      throw new Error(errMsg);
    }

    const data = res.data || res;
    const userType = (data.userType || (data.groomer ? 'groomer' : 'customer')).toLowerCase();
    const accessToken = data.accessToken;
    const refreshToken = data.refreshToken;

    if (accessToken && refreshToken) {
      await storageService.saveTokens(accessToken, refreshToken);
    }

    if (userType === 'groomer') {
      const groomer = (data.groomer || {}) as GroomerUser;
      await storageService.saveGroomerUser(groomer);
      await storageService.setIsGroomerRole(true);
      return {
        userType: 'groomer' as const,
        groomer,
        mustChangePassword: data.mustChangePassword || groomer.mustChangePassword,
      };
    } else {
      const user = (data.user || data) as User;
      await storageService.saveCustomerUser(user);
      await storageService.setIsGroomerRole(false);
      return {
        userType: 'customer' as const,
        user,
      };
    }
  }

  async getProfile(): Promise<User> {
    const res = await api.get('/api/auth/profile');
    const user = res.data?.user || res.data || res.user || res;
    await storageService.saveCustomerUser(user);
    return user;
  }

  async updateProfile(formData: FormData): Promise<User> {
    const res = await api.putMultipart('/api/auth/profile', formData);
    const user = res.data?.user || res.data || res.user || res;
    await storageService.saveCustomerUser(user);
    return user;
  }

  async logout(): Promise<void> {
    try {
      const isGroomer = await storageService.isGroomerRole();
      const endpoint = isGroomer ? '/api/groomer-auth/logout' : '/api/auth/logout';
      await api.post(endpoint, {});
    } catch {
      // Proceed with local logout regardless of network error
    } finally {
      await storageService.clearAllSession();
    }
  }

  async forgotPassword(email: string) {
    const res = await api.post('/api/auth/forgot-password', {
      email: email.toLowerCase().trim(),
    });
    if (!res || res.success === false) {
      throw new Error(res?.message || 'Failed to send reset instructions');
    }
    return res;
  }
}

export const authRepository = new AuthRepository();
