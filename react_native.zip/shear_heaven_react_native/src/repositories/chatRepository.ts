import { io, Socket } from 'socket.io-client';
import { api } from '../api/apiClient';
import { AppConfig } from '../constants/config';
import { storageService } from '../services/storageService';
import { ChatMessage } from '../models/common';

export class ChatRepository {
  private socket: Socket | null = null;
  private messageListeners: Array<(msg: ChatMessage) => void> = [];

  async connectSocket(onMessage?: (msg: ChatMessage) => void) {
    if (onMessage) {
      this.messageListeners.push(onMessage);
    }

    if (this.socket?.connected) return;

    const token = await storageService.getAccessToken();

    this.socket = io(AppConfig.SOCKET_URL, {
      transports: ['websocket'],
      auth: { token },
      extraHeaders: {
        Authorization: `Bearer ${token}`,
      },
    });

    this.socket.on('connect', () => {
      // Auto join user room
    });

    const handleIncoming = (raw: any) => {
      const msg: ChatMessage = {
        id: raw.id || raw._id || Math.random().toString(),
        message: raw.message || raw.text || '',
        isCustomer: raw.isCustomer ?? (raw.senderRole === 'customer'),
        createdAt: raw.createdAt || new Date().toISOString(),
        senderId: raw.senderId,
      };
      this.messageListeners.forEach((l) => l(msg));
    };

    ['chat_message', 'chatMessage', 'new_message'].forEach((evt) => {
      this.socket?.on(evt, handleIncoming);
    });
  }

  disconnectSocket() {
    this.socket?.disconnect();
    this.socket = null;
    this.messageListeners = [];
  }

  async getChatHistory(): Promise<ChatMessage[]> {
    try {
      const res = await api.get('/api/chat/history');
      const list = res.data?.messages || res.data?.history || res.data || res;
      if (Array.isArray(list)) {
        return list.map((item: any) => ({
          id: item.id || item._id || Math.random().toString(),
          message: item.message || item.text || '',
          isCustomer: item.isCustomer ?? (item.senderRole === 'customer'),
          createdAt: item.createdAt || new Date().toISOString(),
          senderId: item.senderId,
        }));
      }
      return [];
    } catch {
      return [];
    }
  }

  sendMessage(message: string, extraData?: Record<string, any>) {
    if (this.socket && this.socket.connected) {
      this.socket.emit('chat_message', { message, ...extraData });
    }
  }
}

export const chatRepository = new ChatRepository();
