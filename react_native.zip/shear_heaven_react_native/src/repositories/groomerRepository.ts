import { api } from '../api/apiClient';
import { storageService } from '../services/storageService';
import { GroomerUser } from '../models/user';
import { Booking } from '../models/booking';

export class GroomerRepository {
  async login(loginId: string, password: string) {
    const deviceId = await storageService.getDeviceId();
    const res = await api.post('/api/groomer-auth/login', {
      email: loginId.trim(),
      password,
      deviceId,
    });

    if (!res || res.success === false) {
      throw new Error(res?.message || 'Groomer login failed');
    }

    const data = res.data || res;
    if (data.accessToken && data.refreshToken) {
      await storageService.saveTokens(data.accessToken, data.refreshToken);
    }
    const groomer = (data.groomer || data.user || data) as GroomerUser;
    await storageService.saveGroomerUser(groomer);
    await storageService.setIsGroomerRole(true);

    return {
      groomer,
      mustChangePassword: data.mustChangePassword ?? false,
      tempLoginId: data.tempLoginId,
      tempPassword: data.tempPassword,
    };
  }

  async setupAccount(data: { tempLoginId?: string; tempPassword?: string; newPassword: string; name?: string }) {
    const res = await api.post('/api/groomer-auth/setup-account', data);
    if (!res || res.success === false) {
      throw new Error(res?.message || 'Failed to setup groomer account');
    }
    return res;
  }

  async getProfile(): Promise<GroomerUser> {
    const res = await api.get('/api/groomer-auth/profile');
    const groomer = res.data?.groomer || res.data || res;
    await storageService.saveGroomerUser(groomer);
    return groomer;
  }

  async getUpcomingBookings(): Promise<Booking[]> {
    try {
      const res = await api.get('/api/groomer-auth/bookings/upcoming');
      const list = res.data?.bookings || res.data || res;
      return Array.isArray(list) ? list : [];
    } catch {
      return [];
    }
  }

  async getPendingBookings(): Promise<Booking[]> {
    try {
      const res = await api.get('/api/groomer-auth/bookings/pending');
      const list = res.data?.bookings || res.data || res;
      return Array.isArray(list) ? list : [];
    } catch {
      return [];
    }
  }

  async getPastBookings(): Promise<Booking[]> {
    try {
      const res = await api.get('/api/groomer-auth/bookings/past');
      const list = res.data?.bookings || res.data || res;
      return Array.isArray(list) ? list : [];
    } catch {
      return [];
    }
  }

  async approveBooking(id: number | string): Promise<boolean> {
    const res = await api.post(`/api/groomer-auth/bookings/${id}/approve`, {});
    return res && res.success !== false;
  }

  async rejectBooking(id: number | string, reason?: string): Promise<boolean> {
    const res = await api.post(`/api/groomer-auth/bookings/${id}/reject`, { reason });
    return res && res.success !== false;
  }

  async startBooking(id: number | string): Promise<boolean> {
    const res = await api.post(`/api/groomer-auth/bookings/${id}/start`, {});
    return res && res.success !== false;
  }

  async completeBooking(id: number | string): Promise<boolean> {
    const res = await api.post(`/api/groomer-auth/bookings/${id}/complete`, {});
    return res && res.success !== false;
  }

  async getCustomers(search = '') {
    const res = await api.get('/api/groomer-auth/customers', { search, limit: 50, offset: 0 });
    return res.data?.customers || res.data || [];
  }

  async getCustomerPets(userId: number | string) {
    const res = await api.get(`/api/groomer-auth/customers/${userId}/pets`);
    return res.data?.pets || res.data || [];
  }
}

export const groomerRepository = new GroomerRepository();
