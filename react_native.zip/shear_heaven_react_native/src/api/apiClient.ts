import axios, { AxiosError, AxiosInstance, InternalAxiosRequestConfig } from 'axios';
import { AppConfig } from '../constants/config';
import { storageService } from '../services/storageService';

let isRefreshing = false;
let failedQueue: Array<{
  resolve: (value?: any) => void;
  reject: (reason?: any) => void;
}> = [];

const processQueue = (error: any, token: string | null = null) => {
  failedQueue.forEach((prom) => {
    if (error) {
      prom.reject(error);
    } else {
      prom.resolve(token);
    }
  });
  failedQueue = [];
};

export const apiClient: AxiosInstance = axios.create({
  baseURL: AppConfig.BASE_URL,
  timeout: 25000,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    ClientId: AppConfig.DEFAULT_CLIENT_ID,
    RegionId: AppConfig.DEFAULT_REGION_ID,
    StoreId: AppConfig.DEFAULT_STORE_ID,
  },
});

// Request interceptor: attach bearer token
apiClient.interceptors.request.use(
  async (config: InternalAxiosRequestConfig) => {
    const isExcluded = [
      '/api/auth/login',
      '/api/auth/signup',
      '/api/auth/send-otp',
      '/api/auth/verify-otp',
      '/api/auth/forgot-password',
      '/api/auth/reset-password',
      '/api/auth/refresh-token',
      '/api/groomer-auth/login',
      '/api/groomer-auth/register',
      '/api/groomer-auth/setup-account',
      '/api/groomer-auth/refresh-token',
    ].some((path) => config.url?.includes(path));

    if (!isExcluded) {
      const token = await storageService.getAccessToken();
      if (token && config.headers) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    }

    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor: handle 401 with Token Refresh Mutex
apiClient.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config as InternalAxiosRequestConfig & { _retry?: boolean };

    if (!error.response || error.response.status !== 401 || originalRequest._retry) {
      return Promise.reject(error);
    }

    // Exclude auth routes from refresh loop
    const url = originalRequest.url || '';
    if (
      url.includes('/api/auth/login') ||
      url.includes('/api/auth/refresh-token') ||
      url.includes('/api/groomer-auth/refresh-token')
    ) {
      return Promise.reject(error);
    }

    if (isRefreshing) {
      return new Promise((resolve, reject) => {
        failedQueue.push({ resolve, reject });
      })
        .then((token) => {
          if (originalRequest.headers) {
            originalRequest.headers.Authorization = `Bearer ${token}`;
          }
          return apiClient(originalRequest);
        })
        .catch((err) => Promise.reject(err));
    }

    originalRequest._retry = true;
    isRefreshing = true;

    try {
      const refreshToken = await storageService.getRefreshToken();
      const isGroomer = await storageService.isGroomerRole();
      const deviceId = await storageService.getDeviceId();

      if (!refreshToken) {
        throw new Error('No refresh token available');
      }

      const refreshUrl = isGroomer
        ? '/api/groomer-auth/refresh-token'
        : '/api/auth/refresh-token';

      const refreshResponse = await axios.post(
        `${AppConfig.BASE_URL}${refreshUrl}`,
        { refreshToken, deviceId },
        {
          headers: {
            'Content-Type': 'application/json',
            ClientId: AppConfig.DEFAULT_CLIENT_ID,
            RegionId: AppConfig.DEFAULT_REGION_ID,
            StoreId: AppConfig.DEFAULT_STORE_ID,
          },
        }
      );

      const data = refreshResponse.data?.data || refreshResponse.data;
      const newAccessToken = data?.accessToken;
      const newRefreshToken = data?.refreshToken || refreshToken;

      if (!newAccessToken) {
        throw new Error('Failed to obtain new access token');
      }

      await storageService.saveTokens(newAccessToken, newRefreshToken);

      if (originalRequest.headers) {
        originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
      }

      processQueue(null, newAccessToken);
      return apiClient(originalRequest);
    } catch (refreshErr) {
      processQueue(refreshErr, null);
      await storageService.clearAllSession();
      return Promise.reject(refreshErr);
    } finally {
      isRefreshing = false;
    }
  }
);

// Wrapper API Methods matching Flutter ApiRepository
export const api = {
  get: async <T = any>(endpoint: string, params?: Record<string, any>): Promise<T> => {
    const res = await apiClient.get<T>(endpoint, { params });
    return res.data;
  },

  post: async <T = any>(endpoint: string, data?: any): Promise<T> => {
    const res = await apiClient.post<T>(endpoint, data);
    return res.data;
  },

  put: async <T = any>(endpoint: string, data?: any): Promise<T> => {
    const res = await apiClient.put<T>(endpoint, data);
    return res.data;
  },

  delete: async <T = any>(endpoint: string): Promise<T> => {
    const res = await apiClient.delete<T>(endpoint);
    return res.data;
  },

  postMultipart: async <T = any>(endpoint: string, formData: FormData): Promise<T> => {
    const token = await storageService.getAccessToken();
    const headers: Record<string, string> = {
      'Content-Type': 'multipart/form-data',
      ClientId: AppConfig.DEFAULT_CLIENT_ID,
      RegionId: AppConfig.DEFAULT_REGION_ID,
      StoreId: AppConfig.DEFAULT_STORE_ID,
    };
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    const res = await axios.post<T>(`${AppConfig.BASE_URL}${endpoint}`, formData, {
      headers,
    });
    return res.data;
  },

  putMultipart: async <T = any>(endpoint: string, formData: FormData): Promise<T> => {
    const token = await storageService.getAccessToken();
    const headers: Record<string, string> = {
      'Content-Type': 'multipart/form-data',
      ClientId: AppConfig.DEFAULT_CLIENT_ID,
      RegionId: AppConfig.DEFAULT_REGION_ID,
      StoreId: AppConfig.DEFAULT_STORE_ID,
    };
    if (token) {
      headers.Authorization = `Bearer ${token}`;
    }

    const res = await axios.put<T>(`${AppConfig.BASE_URL}${endpoint}`, formData, {
      headers,
    });
    return res.data;
  },
};
