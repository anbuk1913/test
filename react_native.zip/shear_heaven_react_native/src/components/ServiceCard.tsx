import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ServiceItem } from '../models/service';
import { Colors, BorderRadius, Spacing, Typography } from '../constants/theme';

interface ServiceCardProps {
  item: ServiceItem;
  selected?: boolean;
  onPress: () => void;
  onBookNow?: () => void;
  showBookButton?: boolean;
}

export const ServiceCard: React.FC<ServiceCardProps> = ({
  item,
  selected,
  onPress,
  onBookNow,
  showBookButton = true,
}) => {
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.8}
      style={[styles.card, selected ? styles.selectedCard : undefined]}
    >
      <View style={styles.content}>
        <View style={styles.header}>
          <Text style={[Typography.title, styles.title]}>{item.name}</Text>
          <Text style={styles.price}>{item.priceDisplay}</Text>
        </View>

        <Text style={styles.description} numberOfLines={2}>
          {item.description}
        </Text>

        <View style={styles.footer}>
          <View style={styles.duration}>
            <Ionicons name="time-outline" size={14} color={Colors.textSecondary} />
            <Text style={styles.durationText}>
              {item.durationMinutes > 0 ? `${item.durationMinutes} mins` : 'Flexible'}
            </Text>
          </View>

          {showBookButton && onBookNow && (
            <TouchableOpacity
              onPress={onBookNow}
              style={[styles.bookBtn, selected ? styles.bookBtnSelected : undefined]}
            >
              <Text style={[styles.bookBtnText, selected ? styles.bookBtnTextSelected : undefined]}>
                {selected ? 'Selected' : 'Book'}
              </Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </TouchableOpacity>
  );
};

interface EmptyStateProps {
  icon?: keyof typeof Ionicons.glyphMap;
  title: string;
  message?: string;
  actionText?: string;
  onAction?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon = 'paw-outline',
  title,
  message,
  actionText,
  onAction,
}) => {
  return (
    <View style={emptyStyles.container}>
      <View style={emptyStyles.iconCircle}>
        <Ionicons name={icon} size={40} color={Colors.primary} />
      </View>
      <Text style={[Typography.title, emptyStyles.title]}>{title}</Text>
      {message && <Text style={emptyStyles.message}>{message}</Text>}
      {actionText && onAction && (
        <TouchableOpacity onPress={onAction} style={emptyStyles.btn}>
          <Text style={emptyStyles.btnText}>{actionText}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    marginBottom: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  selectedCard: {
    borderColor: Colors.primary,
    backgroundColor: '#F0FDFA',
    borderWidth: 1.5,
  },
  content: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.xs,
  },
  title: {
    fontSize: 16,
    fontWeight: '700',
    flex: 1,
    marginRight: Spacing.sm,
  },
  price: {
    fontSize: 16,
    fontWeight: '700',
    color: Colors.primary,
  },
  description: {
    fontSize: 13,
    color: Colors.textSecondary,
    lineHeight: 18,
    marginBottom: Spacing.sm,
  },
  footer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 4,
  },
  duration: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  durationText: {
    fontSize: 12,
    color: Colors.textSecondary,
  },
  bookBtn: {
    backgroundColor: Colors.primary,
    paddingHorizontal: Spacing.md,
    paddingVertical: 6,
    borderRadius: BorderRadius.pill,
  },
  bookBtnSelected: {
    backgroundColor: Colors.secondary,
  },
  bookBtnText: {
    color: Colors.white,
    fontSize: 12,
    fontWeight: '600',
  },
  bookBtnTextSelected: {
    color: Colors.white,
  },
});

const emptyStyles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: Spacing.xxl,
  },
  iconCircle: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#CCFBF1',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: Spacing.md,
  },
  title: {
    fontSize: 18,
    textAlign: 'center',
    marginBottom: Spacing.xs,
  },
  message: {
    fontSize: 14,
    color: Colors.textSecondary,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: Spacing.lg,
  },
  btn: {
    backgroundColor: Colors.primary,
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.sm,
    borderRadius: BorderRadius.pill,
  },
  btnText: {
    color: Colors.white,
    fontWeight: '600',
    fontSize: 14,
  },
});
