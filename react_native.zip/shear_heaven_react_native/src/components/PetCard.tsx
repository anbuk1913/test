import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { Pet } from '../models/pet';
import { Colors, BorderRadius, Spacing, Typography } from '../constants/theme';

interface PetCardProps {
  pet: Pet;
  selected?: boolean;
  onPress?: () => void;
  onEdit?: () => void;
  onDelete?: () => void;
}

export const PetCard: React.FC<PetCardProps> = ({ pet, selected, onPress, onEdit, onDelete }) => {
  const photo = pet.profilePictureUrl || pet.image;

  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.8}
      style={[styles.card, selected ? styles.selectedCard : undefined]}
    >
      <View style={styles.imageContainer}>
        {photo ? (
          <Image source={{ uri: photo }} style={styles.avatar} />
        ) : (
          <View style={styles.placeholderAvatar}>
            <Ionicons name="paw" size={28} color={Colors.primary} />
          </View>
        )}
      </View>

      <View style={styles.info}>
        <View style={styles.nameRow}>
          <Text style={[Typography.title, styles.name]}>{pet.petName}</Text>
          {pet.gender && (
            <Ionicons
              name={pet.gender.toLowerCase() === 'female' ? 'female' : 'male'}
              size={16}
              color={pet.gender.toLowerCase() === 'female' ? '#EC4899' : '#3B82F6'}
              style={{ marginLeft: 6 }}
            />
          )}
        </View>
        <Text style={styles.subtitle}>{pet.breed || 'Breed Not Specified'}</Text>
        <View style={styles.tagRow}>
          {pet.weight ? (
            <View style={styles.tag}>
              <Text style={styles.tagText}>{pet.weight}</Text>
            </View>
          ) : null}
          {pet.age ? (
            <View style={styles.tag}>
              <Text style={styles.tagText}>{pet.age} yrs</Text>
            </View>
          ) : null}
        </View>
      </View>

      {selected !== undefined ? (
        <View style={[styles.radio, selected ? styles.radioSelected : undefined]}>
          {selected && <View style={styles.radioInner} />}
        </View>
      ) : (
        <View style={styles.actions}>
          {onEdit && (
            <TouchableOpacity onPress={onEdit} style={styles.actionBtn}>
              <Ionicons name="create-outline" size={20} color={Colors.textSecondary} />
            </TouchableOpacity>
          )}
          {onDelete && (
            <TouchableOpacity onPress={onDelete} style={styles.actionBtn}>
              <Ionicons name="trash-outline" size={20} color={Colors.danger} />
            </TouchableOpacity>
          )}
        </View>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.white,
    borderRadius: BorderRadius.lg,
    padding: Spacing.md,
    marginBottom: Spacing.md,
    borderWidth: 1,
    borderColor: Colors.border,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  selectedCard: {
    borderColor: Colors.primary,
    backgroundColor: '#F0FDFA',
    borderWidth: 1.5,
  },
  imageContainer: {
    marginRight: Spacing.md,
  },
  avatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: Colors.surface,
  },
  placeholderAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#CCFBF1',
    alignItems: 'center',
    justifyContent: 'center',
  },
  info: {
    flex: 1,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  name: {
    fontSize: 16,
    fontWeight: '700',
    color: Colors.textPrimary,
  },
  subtitle: {
    fontSize: 13,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  tagRow: {
    flexDirection: 'row',
    marginTop: 6,
    gap: 6,
  },
  tag: {
    backgroundColor: Colors.surface,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: BorderRadius.pill,
  },
  tagText: {
    fontSize: 11,
    color: Colors.textSecondary,
    fontWeight: '500',
  },
  radio: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: Spacing.sm,
  },
  radioSelected: {
    borderColor: Colors.primary,
  },
  radioInner: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: Colors.primary,
  },
  actions: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  actionBtn: {
    padding: Spacing.xs,
    marginLeft: Spacing.xs,
  },
});
